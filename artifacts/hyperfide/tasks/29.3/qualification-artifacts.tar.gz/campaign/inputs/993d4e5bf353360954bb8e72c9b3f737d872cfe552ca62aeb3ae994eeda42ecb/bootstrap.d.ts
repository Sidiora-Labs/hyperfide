import type pg from 'pg';
import type { TransactionGateway } from '../storage/transactions.js';
import type { SpecScope } from './import.js';
export interface BootstrapMetadata {
    organisation: {
        id: string;
        name: string;
    };
    project: {
        id: string;
        name: string;
    };
    repositories: {
        id: string;
        name: string;
        url: string;
        object_format: 'sha1' | 'sha256';
        checkout_root: string;
        source_objects: {
            object_id: string;
            object_type: 'commit' | 'tree';
        }[];
    }[];
}
export declare function validateBootstrapMetadata(value: unknown, scope: SpecScope): BootstrapMetadata;
export declare function bootstrapAcceptedIntent(pool: pg.Pool, scope: SpecScope, rawMetadata: unknown, input: unknown): Promise<unknown>;
export interface BootstrapQuery {
    query(text: string, values?: unknown[]): Promise<{
        rows: Record<string, any>[];
        rowCount: number | null;
    }>;
}
export interface AcceptedBootstrapPins {
    organisation_id: string;
    run_id: string;
    authority_epoch: string;
    accepted_revision_digest: string;
}
export declare function assertAcceptedBootstrap(tx: BootstrapQuery, pins: AcceptedBootstrapPins): Promise<{
    organisation_id: string;
    run_id: string;
    project_id: string;
    authority_epoch: string;
    spec_revision_id: string;
    spec_generation: string;
    state_version: string;
    revision_digest: string;
    source_digest: string;
    task_count: number;
    allowed_actions: readonly string[];
}>;
export declare function bootstrapAcceptedIntentWithGateway(gateway: TransactionGateway, scope: SpecScope, rawMetadata: unknown, input: unknown, deployment_id: string): Promise<unknown>;
