import type { PrimaryTransaction } from '../storage/transactions.js';
import type { InvocationContext } from '../transport/protocol.js';
export declare const RUNNER_CONTROL_ACTIONS: readonly ["runner.pause", "runner.drain", "runner.cancel", "runner.stop", "runner.resume"];
export type RunnerControlAction = typeof RUNNER_CONTROL_ACTIONS[number];
export declare const OUTPUT_NAME: RegExp;
export interface RunnerControlPolicy {
    grace_ms: number;
    drain_deadline_ms: number;
    on_drain_deadline: 'STOP' | 'REPORT';
}
export declare function commandView(row: Record<string, any>): Record<string, unknown>;
/** Coordinator-issued control. Cancel/stop raise the publication fence and revoke
 * the attempt's compute leases and worker credentials in this same transaction,
 * so no replacement attempt can be admitted to publish before the fence exists. */
export declare function issueRunnerControl(tx: PrimaryTransaction, i: InvocationContext, v: unknown): Promise<Record<string, unknown>>;
/** Exported publication guard: an attempt generation at or below a raised fence never publishes. */
export declare function assertRunnerPublicationAllowed(tx: PrimaryTransaction, input: {
    organisation_id: string;
    run_id: string;
    attempt_id: string;
    attempt_generation: string;
}): Promise<{
    fenced_generation: string | null;
}>;
/** The bound runner fetches current coordinator authority over the 12.1 transport. */
export declare function authorizeRunnerControl(tx: PrimaryTransaction, i: InvocationContext, v: unknown): Promise<Record<string, unknown>>;
/** Runner-reported outcome. Final outcomes are immutable except for a later proof
 * that cleanup completed; stop/cancel never claim completion without captures. */
export declare function reportRunnerControl(tx: PrimaryTransaction, i: InvocationContext, v: unknown): Promise<Record<string, unknown>>;
export declare function inspectRunnerControl(tx: PrimaryTransaction, i: InvocationContext, v: unknown): Promise<Record<string, unknown>>;
export declare function registerRunnerWorkspace(tx: PrimaryTransaction, i: InvocationContext, v: unknown): Promise<Record<string, unknown>>;
export declare function leaseRunnerWorkspace(tx: PrimaryTransaction, i: InvocationContext, v: unknown): Promise<Record<string, unknown>>;
export declare function releaseRunnerWorkspace(tx: PrimaryTransaction, i: InvocationContext, v: unknown): Promise<Record<string, unknown>>;
export declare function inspectRunnerWorkspace(tx: PrimaryTransaction, i: InvocationContext, v: unknown): Promise<Record<string, unknown>>;
