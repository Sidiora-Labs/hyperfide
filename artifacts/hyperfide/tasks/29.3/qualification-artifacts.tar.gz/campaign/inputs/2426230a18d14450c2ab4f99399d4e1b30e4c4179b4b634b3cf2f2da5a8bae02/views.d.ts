import type pg from 'pg';
import type { Component, ComponentContext } from '../components/registry.js';
export interface Session {
    query<R extends pg.QueryResultRow = pg.QueryResultRow>(text: string, values?: readonly unknown[]): Promise<pg.QueryResult<R>>;
}
export interface Principal {
    organisation_id: string;
    run_id: string;
    actor_id: string;
    credential_id: string;
    role: string;
    attempt_id?: string;
    attempt_generation?: string;
    sandbox_id?: string;
    boot_generation?: string;
}
export declare const MIGRATION = "services/hyperfide/migrations/0023-observability.sql";
export declare const UUID: RegExp;
export declare const DIGEST: RegExp;
export declare function fail(code: string, message: string): never;
export declare function object(value: unknown, keys: readonly string[]): Record<string, unknown>;
export declare function text(value: unknown, max?: number): string;
export declare function uuid(value: unknown): string;
export declare function digest(value: unknown): string;
export declare function integer(value: unknown, min?: number, max?: number): number;
export declare function generation(value: unknown, zero?: boolean): string;
export declare function timestamp(value: unknown): string;
export declare function hash(value: unknown): string;
export declare function principal(context: ComponentContext, operation: string): Principal;
export declare function authority<T>(context: ComponentContext, operation: string, fn: (tx: Session, scope: Principal) => Promise<T>): Promise<T>;
export declare function requireArtifact(tx: Session, p: Principal, id: string): Promise<void>;
export declare function lockRun(tx: Session, p: Principal, namespace?: string): Promise<void>;
export declare function numbers(value: unknown): unknown;
export interface IntegratedProof {
    current_task_ids: string[];
    status: 'CURRENT' | 'HELD';
    count: string | null;
    proof_level: 'TASK_CURRENT_INTEGRATED';
    proof_digest: string | null;
    as_of: string;
    programme_outcome: 'PASS' | 'HELD';
    reasons: string[];
}
export declare function integratedProof(tx: Session, p: Principal): Promise<IntegratedProof>;
interface TaskNode {
    id: string;
    task_key: string;
    state: string;
}
interface Dependency {
    task_id: string;
    predecessor_task_id: string;
    predecessor_run_id: string;
    milestone: string;
    predecessor_state: string | null;
}
export declare function criticalPath(tasks: TaskNode[], dependencies: Dependency[], runId: string, currentTaskIds?: readonly string[], proofStatus?: string): unknown;
export declare function snapshot(tx: Session, p: Principal, input: unknown): Promise<unknown>;
export declare function requireCollector(p: Principal, subjectId?: string): void;
export declare function observe(tx: Session, p: Principal, input: unknown): Promise<unknown>;
export declare function entityPage(tx: Session, p: Principal, input: unknown): Promise<unknown>;
export declare function createComponent(_startup: ComponentContext): Component;
export {};
