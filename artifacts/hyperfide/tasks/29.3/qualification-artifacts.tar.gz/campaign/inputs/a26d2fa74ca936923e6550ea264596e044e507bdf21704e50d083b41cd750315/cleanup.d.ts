import type { DB, IntegrationConfig, Scope } from './candidates.js';
/** Idempotent cleanup for terminal or abandoned integration candidates/jobs.
 * Only leftovers this service can observe and remove are reported as removed;
 * anything it cannot reach or must not touch yet is explicit debt, never success. */
export interface CleanupDebt {
    kind: string;
    resource: string;
    reason: string;
}
/** Reservations held only by terminal integration jobs return to the resource
 * authority (RELEASE_PENDING; the resource reconciler confirms quiescence). */
export declare function releaseTerminalReservations(db: DB, s: Scope, jobId?: string): Promise<string[]>;
export declare function cleanupIntegration(pool: DB, cfg: IntegrationConfig, input: unknown): Promise<unknown>;
