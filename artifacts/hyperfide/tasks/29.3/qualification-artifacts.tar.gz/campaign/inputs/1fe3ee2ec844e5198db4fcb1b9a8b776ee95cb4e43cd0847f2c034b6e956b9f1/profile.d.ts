import type { CreateOptions } from 'railway';
import type { Component, ComponentContext } from '../../components/registry.js';
import type { ProviderScope, ProviderOperation } from '../contract.js';
import { type JsonObject, type RailwayClient } from './preparation.js';
export interface RailwayRuntimeProfile {
    schema_version: 1;
    scope: ProviderScope;
    preparation_digest: string;
    source: {
        kind: 'FRESH';
        reference: null;
        environment_id: null;
        region: null;
    } | {
        kind: 'FORK' | 'CHECKPOINT';
        reference: string;
        environment_id: string;
        region: string;
    };
    resources: {
        cpu_millis: number;
        memory_bytes: string;
        disk_bytes: string;
        persistent_volume_bytes: string;
    };
    idle_timeout_minutes: number;
    network: 'ISOLATED' | 'PRIVATE';
    domains: Array<{
        port: number;
        prefix: string | null;
    }>;
    runtime_variables: Record<string, {
        kind: 'PUBLIC' | 'SECRET_REFERENCE';
        value: string;
    }>;
    build_variables: Record<string, string>;
    digest: string;
}
export declare function validateRuntimeProfile(value: unknown): RailwayRuntimeProfile;
export type CredentialResolver = (references: Readonly<Record<string, string>>, signal: AbortSignal, layer?: 'runtime' | 'process', operation?: ProviderOperation) => Promise<Record<string, string>>;
export declare function runtimeOptions(profile: RailwayRuntimeProfile, client: RailwayClient, resolve: CredentialResolver, signal: AbortSignal): Promise<CreateOptions>;
export declare function runtimeGraphQLInput(profile: RailwayRuntimeProfile, options: CreateOptions): JsonObject;
export declare function observeRuntimeProfile(profile: RailwayRuntimeProfile, observed: unknown): {
    provider_configuration_matches: boolean;
    runner_attestation_required: true;
    resources_verified: false;
    variables_verified: false;
    profile_digest: string;
    authority: 'NONE';
};
export declare function createComponent(_context: ComponentContext): Component;
