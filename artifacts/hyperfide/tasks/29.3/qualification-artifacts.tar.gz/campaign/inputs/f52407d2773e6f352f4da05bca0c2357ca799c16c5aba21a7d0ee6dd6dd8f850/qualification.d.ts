import type { ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { IdentityGateway } from './enrollment.js';
import type { AuthProfileSnapshot } from './native_auth.js';
type Connector = AuthProfileSnapshot['connector'];
type Mode = AuthProfileSnapshot['auth_mode'];
interface ModeEntry {
    profile_id: string;
    host_auth_import: string | null;
    portable_session_claimed: boolean;
}
interface ConnectorEntry {
    connector: Connector;
    selected_mode: Mode | 'UNRESOLVED';
    modes: Record<Mode, ModeEntry | null>;
    account_guidance: {
        reference: string;
        concurrent_refresh: 'UNSUPPORTED' | 'SERIALISED_ONLY' | 'ASSUMED_SAFE';
        renewal_assumption_hours: number;
    };
}
export interface OperatorModeConfig {
    config_revision: string;
    config_digest: string;
    connectors: Map<Connector, ConnectorEntry>;
}
export interface QualificationRecord {
    schema_version: 1;
    id: string;
    connector: Connector;
    auth_mode: Mode;
    profile_id: string;
    profile_digest: string;
    cli: {
        version: string;
        digest: string;
    };
    operator_config: {
        revision: string;
        digest: string;
        selected_mode: Mode | 'UNRESOLVED';
    };
    account_guidance: {
        reference: string;
        concurrent_refresh: string;
        renewal_assumption_hours: number;
    };
    probe_outcome: 'AUTHENTICATED' | 'AUTH_BLOCKED' | 'NOT_RUN';
    refresh_race: 'SERIALISED' | 'UNSAFE';
    state: 'BLOCKED' | 'PROBED_UNQUALIFIED';
    blocked_reasons: string[];
    live_qualified: false;
    portability_qualified: false;
    endurance_72h: 'NOT_CLAIMED';
    record_digest: string;
    recorded_by: string;
    created_at: string;
}
export interface QualificationStore {
    qualify(i: InvocationContext, snapshot: AuthProfileSnapshot, probe: () => Promise<{
        native_authentication: string;
    }>): Promise<QualificationRecord>;
    inspect(i: InvocationContext, connector: unknown): Promise<unknown>;
    commitRefresh(i: InvocationContext, v: unknown): Promise<unknown>;
}
export declare function qualificationReady(g: IdentityGateway): Promise<void>;
export declare function createQualificationStore(ctx: ComponentContext, g: IdentityGateway, profiles: ReadonlyMap<string, AuthProfileSnapshot>): QualificationStore;
export {};
