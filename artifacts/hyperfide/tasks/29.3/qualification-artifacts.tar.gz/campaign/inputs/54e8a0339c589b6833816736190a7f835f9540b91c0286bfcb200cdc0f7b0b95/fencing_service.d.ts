import type { Component, ComponentContext } from '../components/registry.js';
import { type ProviderIsolationRuntime } from '../providers/placement.js';
import { type VerifiedIsolationPermit } from '../identity/credentials.js';
import { type ExternalFenceReceipt, type ProviderIsolationCapability, type ProviderIsolationBackend, type LegacyWriterBackend } from './fencing.js';
export interface ExternalFencingService {
    readonly address: string;
    isolate(permit: VerifiedIsolationPermit, signal: AbortSignal): Promise<ExternalFenceReceipt>;
    describe(): Readonly<Record<string, unknown>>;
    close(): Promise<void>;
}
export interface ExternalFencingServiceOptions {
    readonly env: Readonly<NodeJS.ProcessEnv>;
    readonly signal: AbortSignal;
    readonly providers: ProviderIsolationCapability;
    readonly legacy: LegacyWriterBackend;
    readonly ownedHost?: ProviderIsolationBackend;
}
/** This permit-only listener has no database startup or authority activation path.
 * Supply actual provisioner backends from trusted startup code. Missing custody proof remains a backend refusal.
 */
export declare function startExternalFencingService(options: ExternalFencingServiceOptions): Promise<ExternalFencingService>;
/** Offline provisioner bootstrap uses the real lower provider factory without constructing a database context. */
export declare function startProviderExternalFencingService(options: Omit<ExternalFencingServiceOptions, 'providers'> & {
    runtime: Omit<ProviderIsolationRuntime, 'env' | 'signal'>;
}): Promise<ExternalFencingService>;
/** Managed provisioner startup shares genuine initialized backends; standalone embedding uses the pure factory above. */
export declare function createComponent(context: ComponentContext): Promise<Component>;
