import type { Component, ComponentContext } from '../components/registry.js';
import type { DrillReconciliation } from '../storage/recovery_probes.js';
export type DrillScenario = 'DATABASE' | 'OBJECT' | 'GIT' | 'PROVIDER' | 'AUTH' | 'FULL_DISK' | 'RESTORE';
export interface RecoveryDrillProbe {
    ready(): Promise<void>;
    execute(input: {
        scenario: DrillScenario;
        organisation_id: string;
        run_id: string;
        operation_id: string;
        source_epoch: string;
        signal: AbortSignal;
    }): Promise<{
        status: 'RECOVERED' | 'FAILED' | 'UNKNOWN';
        source_epoch: string;
        recovery_epoch: string | null;
        scope: string;
        acknowledged_ids: readonly string[];
        recovered_ids: readonly string[];
        evidence_digest: string;
        limits: string;
        reconciliation: DrillReconciliation | null;
    }>;
}
export declare function createComponent(startup: ComponentContext): Component;
