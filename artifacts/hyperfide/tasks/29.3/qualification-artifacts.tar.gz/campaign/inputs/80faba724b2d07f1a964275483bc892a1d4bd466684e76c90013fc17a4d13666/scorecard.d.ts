import type { Component, ComponentContext } from '../components/registry.js';
import { type DatasetRow, type EvidenceClass, type Obj } from './datasets.js';
export interface Profile {
    id: string;
    model: string;
    route: string;
    purpose: string;
    rubric: string;
}
export interface Prediction {
    case_id: string;
    profile_id: string;
    probabilities: Record<string, number> | null;
    decision: string | null;
    status: 'ok' | 'abstained' | 'error';
    latency_ms: number;
    attempts: number;
    input_tokens: number | null;
    cost_microusd: number | null;
    usage_class: 'actual' | 'estimated' | 'unknown';
    evidence_class: EvidenceClass;
    receipt_digest: string;
}
export interface Calibration {
    dataset_id: string;
    holdout_digest: string;
    profile: Profile;
    bins: {
        count: number;
        correct: number;
        calibrated: number | null;
    }[];
    fitted_split: 'calibration';
    evidence_class: string;
    evidence_digest: string;
}
export declare function profile(value: unknown): Profile;
export declare function wilson(successes: number, total: number): {
    lower: number;
    upper: number;
} | null;
export declare function parsePredictions(context: ComponentContext, values: unknown, rows: DatasetRow[], profiles: Profile[]): Prediction[];
export declare function calibrate(input: unknown, context: ComponentContext): Promise<Obj>;
export interface Scorecard {
    dataset_id: string;
    holdout_digest: string;
    split: string;
    purpose: string;
    baseline_profile: string;
    profiles: Profile[];
    metrics: Record<string, Obj>;
    strata: Record<string, Record<string, Obj>>;
    comparisons: Record<string, Obj>;
    evidence_class: string;
    comparison_complete: boolean;
    missing_candidates: string[];
    evidence_digest: string;
    calibration_ids: Record<string, string>;
}
export declare function score(input: unknown, context: ComponentContext): Promise<Obj>;
export declare function createComponent(_context: ComponentContext): Component;
