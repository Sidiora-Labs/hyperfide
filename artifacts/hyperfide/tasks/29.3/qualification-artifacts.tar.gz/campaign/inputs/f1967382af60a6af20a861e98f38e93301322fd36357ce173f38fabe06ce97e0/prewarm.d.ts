import type { Component, ComponentContext } from '../components/registry.js';
/** Operator retry policy; every attempt is bounded and spaced by exponential backoff. */
export declare function retryPolicy(env: Readonly<NodeJS.ProcessEnv>): {
    max_attempts: number;
    backoff_base_ms: number;
    backoff_max_ms: number;
};
/** Control role: eligible work becomes reserved, durable remote preparation jobs with 8.3 PREPARATION intents. */
export declare function createComponent(context: ComponentContext): Component;
/** Provisioner role: drives the 8.3 PREPARATION intent and accepts only remote, boot-bound results. */
export declare function createProvisionerComponent(context: ComponentContext): Component;
