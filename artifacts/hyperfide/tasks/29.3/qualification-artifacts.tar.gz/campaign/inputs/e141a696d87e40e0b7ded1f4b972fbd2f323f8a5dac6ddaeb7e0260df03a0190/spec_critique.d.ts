import type { Component, ComponentContext } from '../components/registry.js';
import { type Data } from './audit.js';
export interface ClauseRef {
    section: string;
    field: string;
}
export declare function clauseState(document: unknown, selectors: unknown, sourceDigest: string): Data;
export declare function validateCritique(value: unknown, packetState: Data): Data[];
export declare function amendmentSummary(value: unknown): Data;
export declare function createComponent(ctx: ComponentContext): Component;
