import type { Component, ComponentContext } from '../components/registry.js';
export declare const GRAPH_SCHEMA_VERSION = 1;
export declare const GRAPH_TABLES: readonly string[];
export type JsonObject = Record<string, unknown>;
export declare function fail(code: string, message: string): never;
export declare function exact(value: unknown, required: string[], optional?: string[]): JsonObject;
export declare function canonical(value: unknown): string;
export declare function digest(value: string | Buffer): string;
export declare function text(value: unknown, kind?: string, limit?: number): string;
export declare function uuid(value: unknown): string;
export declare function decimal(value: unknown, zero?: boolean): string;
export declare function sha(value: unknown): string;
export interface ExtractionIdentity {
    organisation_id: string;
    run_id: string;
    repository_id: string;
    commit: string;
    tree: string;
    generation: string;
    source_kind: 'COMMIT' | 'OVERLAY';
    overlay_digest: string | null;
    overlay_name: string | null;
    parser_digest: string;
    config_digest: string;
    source_manifest_digest: string;
}
export interface Fact {
    table: string;
    key: string;
    row: JsonObject;
}
export interface GraphChunk {
    schema_version: 1;
    identity: ExtractionIdentity;
    index: number;
    rows: Fact[];
    digest: string;
}
export interface BundleManifest {
    schema_version: 1;
    bundle_digest: string;
    identity: ExtractionIdentity;
    complete: boolean;
    counts: Record<string, number>;
    chunks: {
        index: number;
        digest: string;
        rows: number;
        bytes: number;
    }[];
    coverage: JsonObject;
    authority: 'NONE';
    cache: 'NON_AUTHORITATIVE';
}
export declare function validateIdentity(value: unknown): ExtractionIdentity;
export declare function validateChunk(value: unknown): GraphChunk;
export declare function validateManifest(value: unknown): BundleManifest;
export declare function createComponent(ctx: ComponentContext): Promise<Component>;
