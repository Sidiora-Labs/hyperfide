import type { Component, ComponentContext } from '../components/registry.js';
import type { GraphScope, GraphTransaction } from './ingestion.js';
import type { JsonObject } from './extraction.js';
export declare function publishedGraph(tx: GraphTransaction, s: GraphScope, manifestId: string): Promise<JsonObject>;
export declare function loadGraphSnapshot(tx: GraphTransaction, s: GraphScope, manifestId: string, expected: unknown): Promise<JsonObject>;
export declare function stagingDebt(tx: GraphTransaction, s: GraphScope, id: string, channel: string): Promise<JsonObject>;
export declare function createComponent(ctx: ComponentContext): Component;
