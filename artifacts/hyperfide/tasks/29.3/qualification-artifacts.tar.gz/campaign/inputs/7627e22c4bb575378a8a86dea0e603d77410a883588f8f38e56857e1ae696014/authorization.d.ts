import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
export interface AuthorizationAuthority {
    authorize(i: InvocationContext): Promise<void>;
    resource(i: InvocationContext, input: unknown): Promise<unknown>;
}
export declare function isAuthorizationAuthority(v: unknown): v is AuthorizationAuthority;
export declare function createComponent(ctx: ComponentContext): Promise<Component>;
