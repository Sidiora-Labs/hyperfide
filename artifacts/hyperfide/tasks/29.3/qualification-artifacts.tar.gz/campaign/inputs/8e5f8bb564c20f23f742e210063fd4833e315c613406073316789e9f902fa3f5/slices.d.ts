import type { Component, ComponentContext } from '../components/registry.js';
/**
 * Packet-scoped workspace slices (task 11.5).
 * Control derives an immutable slice manifest from the exact packet and its pinned published graph; a slice that cannot
 * prove its closure is an explicit FULL_TREE manifest with a recorded reason. Only the remote provisioner clones,
 * materialises (partial clone + no-cone sparse checkout) and runs commands. Slice results never claim full-tree
 * qualification, and every detected out-of-slice access is persisted as REFUSED or as an explicit WIDENED manifest.
 */
export declare const SLICE_ACTIONS: readonly ["preparation.slice.describe", "preparation.slice.derive", "preparation.slice.widen", "preparation.slice.inspect", "preparation.slice.materialize", "preparation.slice.run", "preparation.slice.release"];
export declare const DEFAULT_BUDGET: Readonly<{
    files: 100000;
    edges: 4000000;
    graph_rows: 8000000;
}>;
/** Normalised repository-relative path: no absolute, `..`, `.`, empty, backslash, control or glob segments. */
export declare function slicePath(value: unknown, allowDirectory?: boolean): string;
export interface SliceManifestBody {
    schema_version: 1;
    kind: 'hyperfide.workspace-slice';
    packet_digest: string;
    repository_id: string;
    commit: string;
    graph_manifest_id: string | null;
    graph_manifest_digest: string | null;
    mode: 'SLICE' | 'FULL_TREE';
    fallback_reason: string | null;
    included_paths: string[];
    excluded_roots: string[];
    build_roots: string[];
    metadata_roots: string[];
    submodules: {
        path: string;
        commit: string;
    }[];
    lfs_paths: string[];
    closure: {
        complete: boolean;
        seeds: number;
        files: number;
        edges: number;
        unresolved: number;
        truncated: boolean;
        tests: number;
        fixtures: number;
    };
    diagnostics: {
        code: string;
        path: string | null;
    }[];
    input_roots: {
        contracts: string[];
        registries: string[];
    };
    budget: {
        files: number;
        edges: number;
    };
    slot: {
        sandbox_id: string;
        slot_id: string;
        sandbox_boot_generation: string;
    };
    parent_slice_digest: string | null;
    widening: {
        added_paths: string[];
        reason: string;
    } | null;
}
export interface SliceManifest extends SliceManifestBody {
    digest: string;
}
export interface SliceReceipt {
    schema_version: 1;
    kind: 'hyperfide.workspace-slice-receipt';
    slice_digest: string;
    materialisation_id: string;
    commit: string;
    graph_manifest_digest: string | null;
    mode: 'SLICE' | 'FULL_TREE';
    fallback_reason: string | null;
    qualification_scope: 'SLICE' | 'FULL_TREE';
    full_tree_equivalent: boolean;
    qualification_outcome: 'PASS' | 'FAIL' | 'REFUSED';
    [key: string]: unknown;
}
/** Exact membership: listed files, or anything below a listed `dir/`. FULL_TREE includes everything. */
export declare function sliceIncludes(manifest: Pick<SliceManifestBody, 'mode' | 'included_paths'>, file: string): boolean;
/** Inputs a later full-tree run observed that this slice did not contain. */
export declare function omittedInputs(manifest: Pick<SliceManifestBody, 'mode' | 'included_paths'>, fullTreePaths: readonly string[]): string[];
/** A slice receipt is never full-tree qualification; returns the slice identity a full-tree run must compare against. */
export declare function assertNotFullTreeQualification(receipt: unknown): {
    slice_digest: string;
    commit: string;
    graph_manifest_digest: string | null;
    mode: 'SLICE' | 'FULL_TREE';
    fallback_reason: string | null;
};
/** Recompute the content identity of a stored or supplied manifest. */
export declare function verifySliceManifest(value: unknown): SliceManifest;
export declare function createComponent(_context: ComponentContext): Component;
