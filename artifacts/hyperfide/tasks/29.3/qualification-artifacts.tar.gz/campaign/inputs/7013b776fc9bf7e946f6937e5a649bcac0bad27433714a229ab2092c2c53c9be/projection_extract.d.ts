import type { QuerySession } from '../storage/transactions.js';
import type { ExtractionIdentity, JsonObject } from './extraction.js';
import type { GraphScope } from './ingestion.js';
export declare const PARITY_INDEXES: readonly string[];
export declare const PARITY_MIGRATION = "0704-graph-query-parity";
export declare function assertParityIndexes(session: Pick<QuerySession, 'query'>): Promise<void>;
export declare function readPublishedManifest(session: Pick<QuerySession, 'query'>, s: GraphScope, manifestId: string): Promise<JsonObject>;
export type Cell = string | null;
export interface NormalisedFile {
    path: string;
    content: Cell;
    lang: Cell;
    symbols: Cell[][];
    refs: Cell[][];
    comments: Cell[][];
    routes: Cell[][];
    edges: Cell[][];
}
export interface RepositoryFacts {
    bundle_digest: string;
    identity: ExtractionIdentity;
    files: Map<string, NormalisedFile>;
    symbolNamesByPath: Map<string, Set<string>>;
    targetPathsByPath: Map<string, Set<string>>;
    refNamesByPath: Map<string, Set<string>>;
}
export declare const MAX_PROJECTION_ROWS = 200000;
export declare function repositoryFacts(session: Pick<QuerySession, 'query'>, s: GraphScope, manifest: JsonObject, repositoryId: string): Promise<RepositoryFacts>;
export declare function sortedFiles(files: Iterable<NormalisedFile>): NormalisedFile[];
export declare function factsDigest(files: Iterable<NormalisedFile>): string;
