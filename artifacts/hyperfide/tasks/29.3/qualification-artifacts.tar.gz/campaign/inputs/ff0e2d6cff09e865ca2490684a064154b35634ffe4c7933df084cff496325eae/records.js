export class AuthorityRecordError extends Error {
    code = 'INVALID_RECORD';
    constructor(message) { super(message); this.name = 'AuthorityRecordError'; }
}
export function recordObject(value, path = 'input') {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        throw new AuthorityRecordError(path + ' must be an object');
    return value;
}
function text(pattern, maximum) {
    return (value, path) => {
        if (typeof value !== 'string' || value.length > maximum || !pattern.test(value))
            throw new AuthorityRecordError(path + ' has an invalid encoding');
        return value;
    };
}
const uuid = text(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/, 36);
const digest = text(/^sha256:[0-9a-f]{64}$/, 71);
const oid = text(/^(?:[0-9a-f]{40}|[0-9a-f]{64})$/, 64);
const bigint = (positive) => (value, path) => {
    if (typeof value !== 'string' || !/^(0|[1-9][0-9]*)$/.test(value) || value.length > 19 ||
        BigInt(value) > 9223372036854775807n || (positive && value === '0'))
        throw new AuthorityRecordError(path + ' must be a canonical PostgreSQL bigint decimal string');
    return value;
};
const generation = bigint(true), nonnegative = bigint(false);
const timestamp = (value, path) => {
    if (typeof value !== 'string' || value.length > 40 ||
        !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?Z$/.test(value) ||
        !Number.isFinite(Date.parse(value)) || value.startsWith('0000-') ||
        new Date(value).toISOString().slice(0, 19) !== value.slice(0, 19))
        throw new AuthorityRecordError(path + ' must be a UTC timestamp');
    return value;
};
const enumValue = (...values) => (value, path) => {
    if (typeof value !== 'string' || !values.includes(value))
        throw new AuthorityRecordError(path + ' is not a supported value');
    return value;
};
const nullable = (validator) => (value, path) => value === null ? null : validator(value, path);
const scoped = { organisation_id: uuid, run_id: uuid };
const identified = { ...scoped, id: uuid };
export const CREATE_RECORDS = Object.freeze({
    source_object: { table: 'source_objects', fields: {
            organisation_id: uuid, repository_id: uuid, object_id: oid,
            object_type: enumValue('commit', 'tree', 'blob', 'tag')
        }, required: ['organisation_id', 'repository_id', 'object_id'] },
    attempt: { table: 'attempts', fields: {
            ...identified, task_id: uuid, generation, authority_epoch: uuid, input_packet_digest: digest,
            kind: enumValue('IMPLEMENTATION', 'REVIEW', 'VERIFICATION', 'INTEGRATION', 'INDEX'),
            execution_state: enumValue('PLANNED', 'RESERVED', 'PREPARING', 'START_REQUESTED', 'RUNNING', 'SUBMITTED', 'SUCCEEDED', 'FAILED', 'CANCELLED'),
            compute_authority: enumValue('CURRENT', 'RELEASED', 'REVOKED', 'EXPIRED'),
            sandbox_id: nullable(uuid), slot_id: nullable(uuid), sandbox_boot_generation: nullable(generation),
            lease_expires_at: nullable(timestamp), state_version: generation
        }, required: [...Object.keys(identified), 'task_id', 'generation', 'authority_epoch', 'input_packet_digest'] },
    compute_lease: { table: 'compute_leases', fields: {
            ...identified, attempt_id: uuid, attempt_generation: generation, authority_epoch: uuid,
            sandbox_boot_generation: generation, expires_at: timestamp, state: enumValue('ACTIVE', 'RELEASED', 'REVOKED', 'EXPIRED'),
            state_version: generation
        }, required: [...Object.keys(identified), 'attempt_id', 'attempt_generation', 'authority_epoch', 'sandbox_boot_generation', 'expires_at'] },
    submission_custody: { table: 'submission_custodies', fields: {
            ...identified, task_id: uuid, source_attempt_id: uuid, source_generation: generation,
            custody_generation: generation, authority_epoch: uuid, repository_id: uuid, source_object_id: oid,
            source_manifest_digest: digest, evidence_manifest_digest: digest, criteria_digest: digest,
            authority: enumValue('ACTIVE', 'REVOKED', 'SUPERSEDED', 'RELEASED'),
            qualification_outcome: enumValue('PENDING', 'PASS', 'FAIL'), state_version: generation
        }, required: [...Object.keys(identified), 'task_id', 'source_attempt_id', 'source_generation', 'custody_generation',
            'authority_epoch', 'repository_id', 'source_object_id', 'source_manifest_digest', 'evidence_manifest_digest', 'criteria_digest'] },
    evidence: { table: 'evidence', fields: {
            ...identified, attempt_id: uuid, attempt_generation: generation, repository_id: uuid, source_object_id: oid,
            criteria_digest: digest, manifest_digest: digest, artifact_id: uuid,
            admission_state: enumValue('PENDING', 'ADMITTED', 'REJECTED', 'STALE'), state_version: generation
        }, required: [...Object.keys(identified), 'attempt_id', 'attempt_generation', 'repository_id', 'source_object_id',
            'criteria_digest', 'manifest_digest', 'artifact_id'] },
    evidence_artifact: { table: 'evidence_artifacts', fields: {
            ...scoped, evidence_id: uuid, artifact_id: uuid, role: text(/^[a-z][a-z0-9_.-]*$/, 64)
        }, required: [...Object.keys(scoped), 'evidence_id', 'artifact_id'] },
    qualification_job: { table: 'qualification_jobs', fields: {
            ...identified, custody_id: uuid, custody_generation: generation, rubric_digest: digest,
            state: enumValue('PENDING', 'RUNNING', 'SUCCEEDED', 'FAILED', 'CANCELLED'),
            lease_generation: nonnegative, lease_owner: nullable(uuid), lease_expires_at: nullable(timestamp),
            outcome: enumValue('PENDING', 'PASS', 'FAIL'), state_version: generation
        }, required: [...Object.keys(identified), 'custody_id', 'custody_generation', 'rubric_digest'] },
    publication_operation: { table: 'publication_operations', fields: {
            ...identified, publication_intent_id: uuid, candidate_id: uuid, branch_authority_id: uuid,
            branch_generation: generation, authority_epoch: uuid, repository_id: uuid,
            expected_old_head: nullable(oid), candidate_head: oid, request_id: uuid, operation_generation: generation,
            state: enumValue('PENDING', 'RUNNING', 'OUTCOME_UNKNOWN', 'PUBLISHED', 'FAILED', 'CANCELLED'),
            observed_head: nullable(oid), state_version: generation
        }, required: [...Object.keys(identified), 'publication_intent_id', 'candidate_id', 'branch_authority_id',
            'branch_generation', 'authority_epoch', 'repository_id', 'candidate_head', 'request_id'] }
});
const VALIDATION_RECORDS = {
    scope: scoped,
    source: { ...scoped, repository_id: uuid, source_object_id: oid },
    artifact: { ...identified, digest, size_bytes: nonnegative,
        storage_key: text(/^[^\x00-\x1f\x7f]+$/, 2048),
        status: enumValue('PENDING', 'COMPLETE', 'QUARANTINED', 'DELETED'),
        storage_backend: text(/^[A-Za-z0-9][A-Za-z0-9_.-]*$/, 64),
        retention_class: enumValue('EPHEMERAL', 'RUN', 'RELEASE', 'LEGAL_HOLD') },
    compute_token: { ...scoped, task_id: uuid, attempt_id: uuid, attempt_generation: generation,
        authority_epoch: uuid, sandbox_id: uuid, sandbox_boot_generation: generation },
    custody_token: { ...scoped, task_id: uuid, submission_id: uuid, custody_generation: generation, authority_epoch: uuid }
};
function parseFields(value, fields, required) {
    const record = recordObject(value, 'record');
    for (const key of Object.keys(record))
        if (!Object.hasOwn(fields, key))
            throw new AuthorityRecordError('Unknown record field: ' + key);
    for (const key of required)
        if (!Object.hasOwn(record, key))
            throw new AuthorityRecordError('Missing record field: ' + key);
    return Object.fromEntries(Object.entries(record).map(([key, value]) => [key, fields[key](value, 'record.' + key)]));
}
export function parseCreateRecord(kind, value) {
    if (typeof kind !== 'string' || !Object.hasOwn(CREATE_RECORDS, kind))
        throw new AuthorityRecordError('Unsupported creation record kind');
    const definition = CREATE_RECORDS[kind];
    return { table: definition.table, record: parseFields(value, definition.fields, definition.required) };
}
export function validateAuthorityRecord(kind, value) {
    if (typeof kind !== 'string' || !Object.hasOwn(VALIDATION_RECORDS, kind))
        throw new AuthorityRecordError('Unsupported validation record kind');
    const fields = VALIDATION_RECORDS[kind];
    return parseFields(value, fields, Object.keys(fields));
}
export function operationInput(value) {
    const input = recordObject(value);
    if (Object.keys(input).length !== 2 || !Object.hasOwn(input, 'kind') || !Object.hasOwn(input, 'record'))
        throw new AuthorityRecordError('Operation requires exactly kind and record');
    return { kind: input.kind, record: input.record };
}
//# sourceMappingURL=records.js.map