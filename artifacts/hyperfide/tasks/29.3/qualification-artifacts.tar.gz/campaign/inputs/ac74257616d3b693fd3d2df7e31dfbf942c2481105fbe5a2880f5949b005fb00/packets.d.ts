import type { InvocationContext } from '../transport/protocol.js';
import type { Component, ComponentContext } from '../components/registry.js';
import type { PrimaryTransaction, QuerySession } from '../storage/transactions.js';
export interface ContinuationArtifactBinding {
    artifact_id: string;
    artifact_digest: string;
    artifact_size_bytes: string;
    storage_kind: 'object' | 'manifest';
    content_digest: string;
    content_size_bytes: string;
}
export interface ContinuationBinding {
    schema_version: 1;
    checkpoint_id: string;
    artifact: ContinuationArtifactBinding;
    source: {
        attempt_id: string;
        attempt_generation: string;
        task_id: string;
        workspace_id: string;
        repository_id: string;
        source_object_id: string;
        input_packet_digest: string;
        preparation_digest: string;
        dependency_digest: string;
        source_metadata_digest: string;
        agent_session_id: string | null;
        support_level: 'NATIVE_RESUME' | 'SOURCE_ONLY' | 'UNSUPPORTED';
    };
    context_artifacts: {
        dependency: ContinuationArtifactBinding;
        summary: ContinuationArtifactBinding;
        findings: ContinuationArtifactBinding;
    };
    instruction_cursor: string;
    authority: 'NONE';
    context_restored: false;
}
export type ContinuationReader = (tx: PrimaryTransaction, scope: {
    organisation_id: string;
    run_id: string;
    checkpoint_id: string;
}, invocation: InvocationContext) => Promise<ContinuationBinding>;
/** Accepted physical preparation demand, independent of a not-yet-created executor. */
export declare function loadPreparationIntent(tx: PrimaryTransaction, input: {
    organisation_id: string;
    run_id: string;
    task_id: string;
    profile_id?: string;
}): Promise<{
    preparation_digest: string;
    preparation_manifest: {
        [x: string]: unknown;
    };
    declared_profile: import("../preparation/manifests.js").EnvironmentProfile;
    task_id: string;
    spec_revision_id: any;
    spec_generation: any;
    criteria_digest: any;
    profile_id: string;
    profile_version: string;
    resource_requirements: Record<string, unknown>;
    registry_digest: string;
    proof_policy: unknown;
    execution_profile: Record<string, unknown>;
    policy_digest: string;
    execution_authority: false;
}>;
/** Declared 7.3 capability; its graphGuard binds the authenticated role, scope and epoch to the read. */
export interface GraphSnapshotCapability {
    loadGraphSnapshot(tx: PrimaryTransaction, input: {
        organisation_id: string;
        run_id: string;
        authority_epoch: string;
        manifest_id: string;
        expected_sources: unknown[];
    }, invocation: InvocationContext): Promise<Record<string, unknown>>;
}
export declare function isGraphSnapshotCapability(value: unknown): value is GraphSnapshotCapability;
export interface PacketAuthority {
    loadExecutionPacket: typeof loadExecutionPacket;
    readExecutionPacket: typeof readExecutionPacket;
    loadPreparationIntent: typeof loadPreparationIntent;
    validateExecutionInputs: typeof validateExecutionInputs;
    derivePreparedEnvironmentRoles: typeof derivePreparedEnvironmentRoles;
    deriveQualificationInputs: typeof deriveQualificationInputs;
    installContinuationReader: (reader: ContinuationReader) => void;
}
export declare function isPacketAuthority(value: unknown): value is PacketAuthority;
export interface ExecutionPacketRecord {
    packet_id: string;
    digest: string;
    mandatory_digest: string;
    packet: Record<string, unknown>;
}
/** Return immutable historical inputs. Current admission/custody authority is a separate gate. */
export declare function loadExecutionPacket(tx: PrimaryTransaction, input: {
    organisation_id: string;
    run_id: string;
    digest: string;
}): Promise<ExecutionPacketRecord>;
/** Exact immutable observation only; caller owns authenticated causal snapshot admission. */
export declare function readExecutionPacket(tx: QuerySession, input: {
    organisation_id: string;
    run_id: string;
    digest: string;
}): Promise<ExecutionPacketRecord>;
/** Current input eligibility for NEW admission only; never replace historical packet reads.
 * Each independently changeable input class is rechecked against current authority: accepted task intent,
 * platform epoch, environment manifest and its source commits, run source pins, dependency custody/qualification,
 * contract revisions, required graph artifacts and continuation bindings. Unrelated rows are never consulted. */
export declare function validateExecutionInputs(tx: PrimaryTransaction, input: {
    organisation_id: string;
    run_id: string;
    digest: string;
}, invocation?: InvocationContext, graphReader?: GraphSnapshotCapability): Promise<{
    packet_id: string;
    digest: string;
    mandatory_digest: string;
    packet: Record<string, unknown>;
    checked_inputs: string[];
    execution_authority: false;
}>;
/** Pure hashes of supplied prepared bytes. The caller must establish provenance and readiness. */
export declare function derivePreparedEnvironmentRoles(manifest: unknown, context: unknown): {
    preparation_digest: string;
    profile_digest: string;
    toolchain_digest: string;
    configuration_digest: string;
    authority: 'NONE';
};
/** Hash actual non-result inputs; source-result commit/tree provenance stays distinct. */
export declare function deriveQualificationInputs(packet: unknown): {
    dependency_digest: string;
    toolchain_digest: string;
    configuration_digest: string;
    graph_digest: string;
    contract_digest: string;
    graph_manifest_digest: string | null;
    graph_status: 'PINNED' | 'NOT_REQUIRED';
};
export declare function createComponent(context: ComponentContext): Component;
