import type { Component, ComponentContext } from '../components/registry.js';
interface Issue {
    number: number;
    title: string;
    body: string;
    state: 'open' | 'closed';
    updated_at: string;
    pull_request?: unknown;
}
export declare class GitHubClient {
    readonly env: Readonly<NodeJS.ProcessEnv>;
    readonly signal?: AbortSignal | undefined;
    deadline: number;
    readonly base: URL;
    readonly token: string;
    constructor(env: Readonly<NodeJS.ProcessEnv>, signal?: AbortSignal | undefined, deadline?: number);
    request(method: string, relative: string, payload?: unknown): Promise<{
        data: unknown;
        link: string | null;
    }>;
    issues(owner: string, name: string, since: string): Promise<Issue[]>;
}
export declare function createComponent(_context: ComponentContext): Component;
export {};
