import type { ProviderIsolationBinding, ProviderIsolationReceipt, ProviderIsolationObservationJournal, ProviderWriterObservation } from '../providers/placement.js';
import { type InvocationContext } from '../transport/protocol.js';
import { type VerifiedWriterObservationPermit, type VerifiedIsolationPermit } from '../identity/credentials.js';
import { type TransactionGateway } from '../storage/transactions.js';
type Binding = {
    deployment_id: string;
    operation_id: string;
    source_epoch: string | null;
    topology_digest: string;
    authority_digest: string;
    authority_nonce: string | null;
};
export interface ExternalFenceReceipt {
    deployment_id: string;
    operation_id: string;
    fence_id: string;
    source_epoch: string | null;
    isolated_writer: string;
    observed_at: string;
    expires_at: string;
    evidence_digest: string;
}
export interface ExternalWriterFence {
    isolate(input: {
        deployment_id: string;
        operation_id: string;
        source_epoch: string | null;
        signal?: AbortSignal;
    }): Promise<ExternalFenceReceipt>;
}
export type WriterIsolationReceipt = ProviderIsolationReceipt;
export type IsolationJournalBinding = ProviderIsolationBinding;
export interface IsolationJournalRecord {
    binding: IsolationJournalBinding;
    state: 'PREPARED' | 'UNKNOWN' | 'ISOLATED';
    receipt: WriterIsolationReceipt | null;
    observations: readonly {
        operation: unknown;
        outcome: unknown;
    }[];
    writer_observations?: readonly WriterObservationJournalEntry[];
}
export type WriterObservationReceipt = ProviderWriterObservation;
export type WriterObservationJournalEntry = Parameters<ProviderIsolationObservationJournal['recordObservation']>[0];
export interface WriterObservationJournal {
    read(): Promise<IsolationJournalRecord | null>;
    recordObservation(value: WriterObservationJournalEntry): Promise<void>;
}
export interface IsolationJournal {
    read(): Promise<IsolationJournalRecord | null>;
    prepare(binding: IsolationJournalBinding): Promise<{
        created: boolean;
        state: IsolationJournalRecord;
    }>;
    record(outcome: {
        binding: IsolationJournalBinding;
        receipt: WriterIsolationReceipt | null;
        observations: readonly {
            operation: unknown;
            outcome: unknown;
        }[];
    }): Promise<void>;
}
export interface ProviderIsolationBackend {
    isolateConfiguredResource(referenceKey: string, operationId: string, signal: AbortSignal, journal: IsolationJournal): Promise<WriterIsolationReceipt>;
}
export interface LegacyWriterReceipt {
    deployment_id: string;
    operation_id: string;
    source_epoch: string | null;
    status: 'ADMISSION_DISABLED' | 'ISOLATED';
    topology_digest: string;
    observed_at: string;
    evidence_digest: string;
    expires_at?: string;
    isolated_writer?: string;
    visibility: {
        scope: 'CONFIGURED_PID_NAMESPACE';
        pid_namespace: string;
        mount_namespace: string;
        checked_processes?: number;
        checked_mount_namespaces?: number;
    };
    admission_disabled?: boolean;
    writable_fds?: number;
    writable_shared_mappings?: number;
    read_only_aliases?: number;
}
export interface LegacyWriterBackend {
    disableAdmission(input: {
        deployment_id: string;
        operation_id: string;
        source_epoch: string | null;
        signal?: AbortSignal;
    }): Promise<LegacyWriterReceipt>;
    observeIsolation(input: {
        deployment_id: string;
        operation_id: string;
        source_epoch: string | null;
        signal?: AbortSignal;
    }): Promise<LegacyWriterReceipt>;
}
export interface ExternalFenceTopology {
    schema_version: 1;
    deployment_id: string;
    organisation_id: string;
    run_id: string;
    source_epoch: string | null;
    evidence_scope: 'LIVE_PROVIDER' | 'COMPONENT_FIXTURE';
    legacy_topology_digest: string;
    legacy_pid_namespace: string;
    legacy_mount_namespace: string;
    required_writer_ids: string[];
    resources: {
        reference_key: string;
        topology_digest: string;
        writer_ids: string[];
        backend: 'PROVIDER' | 'OWNED_HOST';
    }[];
}
export type ExternalFenceAuthority = {
    kind: 'INVOCATION';
    invocation: InvocationContext;
    gateway: Pick<TransactionGateway, 'withPrimaryTransaction'>;
} | {
    kind: 'ISOLATION_PERMIT';
    permit: VerifiedIsolationPermit;
};
export interface ProviderIsolationCapability {
    isolateConfiguredResource(referenceKey: string, operationId: string, authority: InvocationContext | VerifiedIsolationPermit, signal: AbortSignal, journal: IsolationJournal): Promise<WriterIsolationReceipt>;
}
export declare function bindProviderIsolation(capability: ProviderIsolationCapability, authority: InvocationContext | VerifiedIsolationPermit): ProviderIsolationBackend;
/** Private fsynced custody survives a control restart independently of the database being fenced.
 * A crashed operation lock is deliberately not age-reclaimed: operator reconciliation must establish ownership.
 */
export declare class FileExternalFenceJournal {
    private readonly directory;
    constructor(directory: string);
    readCompleted(input: {
        deployment_id: string;
        operation_id: string;
        source_epoch: string | null;
        topology_digest: string;
        expected_proof_digest?: string;
    }): Promise<ExternalFenceReceipt>;
    withOperation<T>(binding: Binding, body: (resource: (key: string) => IsolationJournal, recordCompletion: (receipt: ExternalFenceReceipt) => Promise<void>) => Promise<T>): Promise<T>;
    withObservation<T>(binding: Binding, body: (resource: (key: string) => WriterObservationJournal) => Promise<T>): Promise<T>;
    private operate;
}
/** Construct only in trusted deployment code. Request JSON cannot choose topology, backends, or journal paths. */
export declare function externalFenceTopologyDigest(config: ExternalFenceTopology): string;
export declare function createExternalWriterFence(config: ExternalFenceTopology, providers: ProviderIsolationBackend, legacy: LegacyWriterBackend, journal: FileExternalFenceJournal, authority: ExternalFenceAuthority, ownedHost?: ProviderIsolationBackend): ExternalWriterFence;
export interface ExternalFenceObservation {
    schema_version: 1;
    deployment_id: string;
    operation_id: string;
    source_epoch: string | null;
    topology_digest: string;
    status: 'OBSERVED' | 'UNKNOWN';
    observed_at: string;
    expires_at: string;
    evidence_digest: string;
    journal_operation_id: string;
    resource_count: number;
    isolated_count: number;
    unknown_count: number;
    legacy_status: 'ISOLATED' | 'UNKNOWN';
    destruction_authority: false;
    activation_authority: false;
}
export interface ProviderWriterObservationCapability {
    observeConfiguredResource(referenceKey: string, operationId: string, authority: VerifiedWriterObservationPermit, signal: AbortSignal, journal: WriterObservationJournal): Promise<WriterObservationReceipt>;
}
/** Observation has separate identity and capability. It cannot prepare or repeat isolation. */
export declare function createExternalWriterObserver(config: ExternalFenceTopology, providers: ProviderWriterObservationCapability, legacy: Pick<LegacyWriterBackend, 'observeIsolation'>, journal: FileExternalFenceJournal, ownedHost?: ProviderWriterObservationCapability): Readonly<{
    observe: (permit: VerifiedWriterObservationPermit, signal: AbortSignal) => Promise<ExternalFenceObservation>;
}>;
export {};
