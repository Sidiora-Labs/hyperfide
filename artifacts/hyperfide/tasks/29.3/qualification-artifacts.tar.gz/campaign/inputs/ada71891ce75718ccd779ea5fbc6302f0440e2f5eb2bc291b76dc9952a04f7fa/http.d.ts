import type { InvocationContext } from './protocol.js';
import type { IdentityAuthority } from '../identity/enrollment.js';
export interface HttpTransportOptions {
    origin: string;
    host: string;
    port: number;
    certificate: string;
    privateKey: string;
    signal: AbortSignal;
    identity: IdentityAuthority;
    maxConcurrent?: number;
    deadlineMs?: number;
    requestLimit?: number;
    responseLimit?: number;
    dispatch: (i: InvocationContext) => Promise<unknown>;
    authorize?: (i: InvocationContext) => Promise<void>;
}
export interface HttpTransport {
    readonly address: string;
    close(): Promise<void>;
}
export declare function startHttpTransport(o: HttpTransportOptions): Promise<HttpTransport>;
export interface ServiceClientConfiguration {
    readonly origin: string;
    readonly caFile: string;
    readonly keyFile: string;
    readonly credentialId: string;
    readonly runId: string;
    readonly routes: Readonly<Record<string, {
        readonly roles: readonly string[];
        readonly components: readonly string[];
        readonly actions: readonly string[];
    }>>;
    readonly timeoutMs?: number;
    readonly maxConcurrent?: number;
}
export interface ServiceCommand {
    readonly operation: import('./protocol.js').Operation;
    readonly payloadBytes: Buffer;
}
export type ServiceResponse = {
    transport: 'RESPONSE';
    status: number;
    body: unknown;
    operation_id: string;
} | {
    transport: 'UNKNOWN';
    operation_id: string;
    reason: string;
};
export interface ServiceClient {
    invoke(invocation: InvocationContext, command: ServiceCommand): Promise<ServiceResponse>;
}
export declare function createServiceClient(config: ServiceClientConfiguration, gateway: import('../identity/enrollment.js').IdentityGateway): Promise<ServiceClient>;
