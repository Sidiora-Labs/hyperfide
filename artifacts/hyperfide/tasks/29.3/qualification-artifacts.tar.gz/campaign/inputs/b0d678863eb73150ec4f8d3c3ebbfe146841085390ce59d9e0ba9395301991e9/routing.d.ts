import type { Component, ComponentContext } from '../components/registry.js';
export declare function createComponent(_context: ComponentContext): Component;
