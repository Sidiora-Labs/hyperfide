import type { FileHandle } from 'node:fs/promises';
import type { Component, ComponentContext } from '../components/registry.js';
type Item = {
    from: string;
    to: string;
    digest: string;
    size: number;
    mode: number;
};
export interface NamesManifest {
    schema_version: 1;
    migration_id: string;
    files: Item[];
    retained_paths: {
        path: string;
        state: string;
        policy: 'PRESERVE_IN_PLACE';
    }[];
    digest: string;
}
export declare const ENVIRONMENT_ALIASES: readonly (readonly string[])[];
export declare function strictObject(value: unknown, keys: string[]): Record<string, unknown>;
export declare function relativePath(value: unknown, empty?: boolean): string;
export declare function resolveEnvironmentAliases(env: Readonly<NodeJS.ProcessEnv>): NodeJS.ProcessEnv;
export declare const contentDigest: (data: Uint8Array | string) => string;
export declare function openDirectory(root: FileHandle, relative: string, create?: boolean): Promise<FileHandle>;
export declare function openWorkspace(context: ComponentContext, relative: unknown): Promise<FileHandle>;
export declare function readContained(root: FileHandle, relative: string): Promise<{
    bytes: Buffer;
    mode: number;
} | null>;
export declare function createComponent(context: ComponentContext): Component;
export {};
