import type { ServiceResources } from '../storage/runtime.js';
import type { ExternalAuthorityJournal } from '../storage/authority_journal.js';
import type { PrimaryTransaction, TransactionOptions } from '../storage/transactions.js';
export interface AcceptedRunRebindInput {
    readonly schema_version: 1;
    readonly organisation_id: string;
    readonly run_id: string;
    readonly recovery_operation_id: string;
    readonly activation_operation_id: string;
    readonly deployment_id: string;
    readonly expected_run_epoch: string;
    readonly target_epoch: string;
    readonly expected_spec_generation: string;
    readonly expected_spec_revision_id: string;
    readonly expected_revision_digest: string;
    readonly external_previous_epoch: string | null;
    readonly database_predecessor_epoch: string | null;
    readonly fence_proof_digest: string;
    readonly external_journal_sequence: string;
}
export type RecoveryEvidenceScope = 'LIVE_PROVIDER' | 'ISOLATED_POSTGRESQL_FIXTURE';
export interface AcceptedRunRecoveryIntent extends AcceptedRunRebindInput {
    readonly intent_digest: string;
    readonly evidence_scope: RecoveryEvidenceScope;
}
export interface RecoveryComputeRevocation {
    readonly revoked_attempts: string;
    readonly revoked_allocations: string;
    readonly retained_debt_references: readonly string[];
}
export interface PreparedAcceptedRunRecovery {
    verify(tx: PrimaryTransaction): Promise<AcceptedRunRecoveryIntent>;
    revokeCompute(tx: PrimaryTransaction): Promise<RecoveryComputeRevocation>;
}
export interface RunRebindReceipt {
    readonly schema_version: 1;
    readonly organisation_id: string;
    readonly run_id: string;
    readonly recovery_operation_id: string;
    readonly deployment_id: string;
    readonly activation_operation_id: string;
    readonly source_epoch: string;
    readonly target_epoch: string;
    readonly spec_generation: string;
    readonly spec_revision_id: string;
    readonly accepted_revision_digest: string;
    readonly input_digest: string;
    readonly intent_digest: string;
    readonly receipt_digest: string;
    readonly evidence_scope: RecoveryEvidenceScope;
    readonly revoked_principals: string;
    readonly revoked_grants: string;
    readonly revoked_attachments: string;
    readonly revoked_attempts: string;
    readonly revoked_allocations: string;
    readonly retained_debt_references: readonly string[];
    readonly run_state: 'PAUSED';
    readonly state_version: string;
    readonly created_at: string;
    readonly compute_admission_granted: false;
    readonly publication_authorized: false;
}
export interface RunRebindReceiptExpectation {
    readonly organisation_id: string;
    readonly run_id: string;
    readonly recovery_operation_id: string;
    readonly receipt_digest: string;
    readonly deployment_id: string;
    readonly target_epoch: string;
    readonly accepted_revision_digest: string;
    readonly evidence_scope: RecoveryEvidenceScope;
}
/** Local trusted deployment composition only. The prepared verifier reads actual24
 * retained physical evidence; its scheduler callback revokes actual5 authority.
 * Neither caller JSON nor an isolation permit may construct this recovery proof.
 */
export declare function rebindAcceptedRun(resources: ServiceResources, journal: ExternalAuthorityJournal, raw: AcceptedRunRebindInput, prepared: PreparedAcceptedRunRecovery, options?: TransactionOptions): Promise<RunRebindReceipt>;
/** Trusted26 issuer uses this in its own genuine primary transaction, after fresh
 * external journal verification. It does not accept a serialized receipt as proof.
 */
export declare function inspectRunRebindReceipt(tx: PrimaryTransaction, expected: RunRebindReceiptExpectation): Promise<RunRebindReceipt>;
