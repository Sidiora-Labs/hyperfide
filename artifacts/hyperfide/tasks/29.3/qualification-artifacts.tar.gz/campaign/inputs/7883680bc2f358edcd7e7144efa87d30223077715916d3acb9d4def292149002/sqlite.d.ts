import { DatabaseSync } from 'node:sqlite';
import type { Component, ComponentContext } from '../components/registry.js';
type Json = Record<string, unknown>;
export interface Profile {
    id: string;
    source_id: string;
    repository_id: string;
    organisation_id: string;
    root: string;
    database: string;
    external?: {
        label: string;
        path: string;
        kind: string;
        sensitive?: boolean;
    }[];
    kvx?: {
        label: string;
        path: string;
    }[];
    archive_approved_digests?: string[];
}
export declare function hash(bytes: string | Buffer): string;
export declare function canonical(value: unknown): string;
export declare function mappedId(source: string, repository: string, table: string, key: unknown): string;
export declare function fileHash(filename: string): Promise<string>;
export declare function regular(root: string, relative: string): Promise<string>;
export declare function profiles(env: Readonly<NodeJS.ProcessEnv>): Promise<Profile[]>;
export declare function archiveRoot(env: Readonly<NodeJS.ProcessEnv>): Promise<string>;
export declare function open(filename: string): DatabaseSync;
export declare function inventory(db: DatabaseSync): Json;
export interface LogicalRow {
    key: unknown;
    data: unknown;
    mapped: string;
    digest: string;
    disposition: string;
}
/** The one logical-row encoder. Import batches and cutover parity samples must agree
 * byte-for-byte, so neither may re-derive keys, cells or payload digests independently. */
export declare function logicalBatch(db: DatabaseSync, table: string, offset: string, limit: number, source: string, repository: string): {
    rows: LogicalRow[];
    total: bigint;
};
export declare const MIGRATION_ACTIONS: readonly ['migration.sqlite.describe', 'migration.sqlite.snapshot', 'migration.sqlite.inventory', 'migration.sqlite.archive', 'migration.sqlite.import', 'migration.sqlite.status'];
export declare function createComponent(_startup: ComponentContext): Component;
export {};
