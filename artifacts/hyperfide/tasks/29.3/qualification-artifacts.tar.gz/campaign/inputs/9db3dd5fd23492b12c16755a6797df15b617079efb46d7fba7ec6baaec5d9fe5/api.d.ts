import type { ComponentContext } from '../components/registry.js';
import type { TransactionGateway } from '../storage/transactions.js';
type Action = (input: unknown, context: ComponentContext) => Promise<unknown> | unknown;
export declare const RUNNER_EVENT_BOUNDS: Readonly<{
    payload_bytes: 16384;
    events_per_stream: 4096;
}>;
export declare function ingestRunnerEvent(g: TransactionGateway, context: ComponentContext, input: unknown): Promise<unknown>;
export declare function runnerApi(g: TransactionGateway): Record<string, Action>;
export {};
