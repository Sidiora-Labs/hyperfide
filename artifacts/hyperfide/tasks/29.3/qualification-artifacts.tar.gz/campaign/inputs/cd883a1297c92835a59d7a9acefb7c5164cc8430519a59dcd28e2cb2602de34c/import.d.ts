import type pg from 'pg';
import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext, AuthorityTransaction } from '../transport/protocol.js';
export interface KvxField {
    key: string;
    raw: string;
    value: unknown;
    line: number;
}
export interface KvxSection {
    name: string;
    line: number;
    fields: Record<string, KvxField>;
}
export interface KvxDocument {
    sections: KvxSection[];
    counts: {
        sections: number;
        fields: number;
        tasks: number;
        requirements: number;
        criteria: number;
        acceptances: number;
    };
}
export interface RepositoryPin {
    repository_id: string;
    source_object_id: string;
    integration_ref: string;
}
export interface ImportEnvelope {
    run_id: string;
    source: {
        relative_path: string;
        sha256: string;
        size_bytes: string;
    };
    repositories: RepositoryPin[];
    allowed_actions: string[];
    closure_policy: {
        required_evidence: string[];
        required_review_roles: string[];
        publication: 'AFTER_QUALIFICATION';
    };
    provenance: null | {
        repository_id: string;
        git_object_id: string;
    };
}
export interface SpecScope {
    organisation_id: string;
    project_id: string;
    run_id: string;
    authority_epoch: string;
    root: string;
    allowed_actions: readonly string[];
}
export declare function validIntegrationRef(value: unknown): value is string;
export declare function canonical(value: unknown): string;
export declare const digest: (value: string | Buffer) => string;
export declare function derivedId(value: string): string;
export declare function parseKvx(source: string): KvxDocument;
export declare function specScope(context: ComponentContext): SpecScope;
export declare function validateImport(value: unknown, scope: SpecScope): ImportEnvelope;
export declare function readPinnedSource(root: string, source: ImportEnvelope['source']): Promise<{
    bytes: Buffer;
    text: string;
}>;
export interface StoredIntent {
    schema_version: 1;
    revision_digest: string;
    source_digest: string;
    repositories: RepositoryPin[];
    allowed_actions: string[];
    closure_policy: ImportEnvelope['closure_policy'];
    provenance: ImportEnvelope['provenance'];
    parsed: KvxDocument;
    runtime_wave_offset: number;
}
export declare function taskDefinitions(parsed: KvxDocument): {
    section: KvxSection;
    key: string;
    feature_key: string;
    declared_wave: unknown;
    wave: number;
    package_key: string;
}[];
export interface SpecTransaction {
    query<Row extends pg.QueryResultRow = pg.QueryResultRow>(text: string, values?: unknown[]): Promise<pg.QueryResult<Row>>;
}
export interface PinnedRun {
    id: string;
    spec_revision_id: string;
    spec_generation: string;
    state_version: string;
    state: string;
    source_content: string;
    source_digest: string;
    document: StoredIntent;
}
export declare function loadPinnedRun(client: SpecTransaction, scope: SpecScope): Promise<PinnedRun>;
export declare function prepareAcceptedIntent(scope: SpecScope, raw: unknown, rawSource?: Buffer): Promise<{
    input: ImportEnvelope;
    source: {
        bytes: Buffer;
        text: string;
    };
    parsed: KvxDocument;
    tasks: {
        section: KvxSection;
        key: string;
        feature_key: string;
        declared_wave: unknown;
        wave: number;
        package_key: string;
    }[];
    document: StoredIntent;
    specId: string;
    revision_digest: string;
    accepted: {
        schema_version: number;
        source_digest: string;
        repositories: RepositoryPin[];
        allowed_actions: string[];
        closure_policy: {
            required_evidence: string[];
            required_review_roles: string[];
            publication: 'AFTER_QUALIFICATION';
        };
        provenance: {
            repository_id: string;
            git_object_id: string;
        } | null;
    };
}>;
export declare function importRunTransaction(client: SpecTransaction, scope: SpecScope, raw: unknown): Promise<unknown>;
export declare function importRun(pool: pg.Pool, scope: SpecScope, raw: unknown): Promise<unknown>;
export declare function exportProjection(pool: SpecTransaction, scope: SpecScope, input: unknown): Promise<unknown>;
export declare function specTransaction<T>(context: ComponentContext, mode: 'READ' | 'WRITE', body: (tx: AuthorityTransaction, invocation: InvocationContext) => Promise<T>): Promise<T>;
export declare function createComponent(_startup: ComponentContext): Component;
