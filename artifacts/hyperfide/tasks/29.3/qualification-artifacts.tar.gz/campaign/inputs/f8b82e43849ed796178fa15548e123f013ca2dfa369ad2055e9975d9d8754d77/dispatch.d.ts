import type { Component, ComponentContext } from '../components/registry.js';
export declare function createComponent(ctx: ComponentContext): Component;
