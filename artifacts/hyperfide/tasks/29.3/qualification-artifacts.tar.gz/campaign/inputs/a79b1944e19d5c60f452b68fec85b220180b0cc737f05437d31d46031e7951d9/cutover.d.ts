import type { Component, ComponentContext } from '../components/registry.js';
/** States: LOCAL -> QUIESCED (legacy admission disabled, kernel isolation observed, 24.3
 * quiescence) -> VALIDATED (parity receipt). ACTIVE requires a separately approved 4.4
 * fence and stays refused here. Rollback before new PostgreSQL writes returns authority
 * to the quiesced legacy writer; after writes or external effects only forward recovery
 * from PostgreSQL is offered, and the SQLite archive never reopens as authority. */
export declare function createComponent(_startup: ComponentContext): Component;
