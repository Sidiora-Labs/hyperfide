import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { QuerySession } from './transactions.js';
import type { ServiceResources } from './runtime.js';
interface PacketInput {
    organisation_id: string;
    run_id: string;
    digest: string;
}
export interface ExecutionPacketReader {
    readExecutionPacket(snapshot: QuerySession, input: PacketInput): Promise<unknown>;
}
interface Topology {
    system_id: string;
    timeline: string;
    authority_epoch: string;
}
export interface CausalBarrier extends Topology, PacketInput {
    schema_version: 1;
    deployment_id: string;
    lsn: string;
    issued_at: string;
    expires_at: string;
    signature: string;
}
export interface PacketReadOptions {
    digest: string;
    barrier?: CausalBarrier;
    timeoutMs?: number;
    waitMs?: number;
    preferReplica?: boolean;
    expected_graph_manifest_digest?: string | null;
}
export declare class PacketSnapshots {
    private readonly resources;
    private readonly reader;
    private readonly key;
    private readonly deployment;
    constructor(resources: ServiceResources, reader: ExecutionPacketReader, env: Readonly<NodeJS.ProcessEnv>);
    private topology;
    private admit;
    private validate;
    mint(digest: string, invocation: InvocationContext, options?: {
        timeoutMs?: number;
    }): Promise<CausalBarrier>;
    private validatePins;
    read(options: PacketReadOptions, invocation: InvocationContext): Promise<unknown>;
}
export declare function createComponent(context: ComponentContext): Component;
export {};
