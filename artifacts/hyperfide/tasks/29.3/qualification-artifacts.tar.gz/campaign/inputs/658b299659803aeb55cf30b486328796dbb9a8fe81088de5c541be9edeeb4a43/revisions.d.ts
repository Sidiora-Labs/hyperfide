import type { AuthorityTransaction } from '../transport/protocol.js';
import type { Component, ComponentContext } from '../components/registry.js';
import type { SpecScope } from './import.js';
import type { DependencyReport } from './dependencies.js';
type Tx = AuthorityTransaction;
export interface AmendmentRequest {
    run_id: string;
    base_spec_revision_id: string;
    base_spec_generation: string;
    state_version: string;
    purpose: 'REPLAN' | 'INTENT_CHANGE';
    reason: string;
    replacement: unknown;
}
export interface ActiveTaskImpact {
    task_id: string;
    task_key: string;
    state: string;
    spec_generation: string;
    current_compute: number;
    active_custody: number;
    released_custody: number;
    live_evidence: number;
    current_packets: number;
    accepted_work: boolean;
    disposition: 'REVALIDATE' | 'FENCE_REQUIRED' | 'RETIRE';
}
export interface AmendmentImpact {
    added: string[];
    changed: string[];
    retired: string[];
    affected_task_ids: string[];
    global_intent_changed: boolean;
    external_dependents: {
        run_id: string;
        task_id: string;
    }[];
    revalidation: ActiveTaskImpact[];
    unaffected_active_task_ids: string[];
}
export interface AmendmentAnalysis {
    schema_version: 1;
    proposal_digest: string;
    accepted: false;
    dispatch_authority: false;
    status: 'STRUCTURALLY_VALID' | 'INVALID';
    diagnostics: {
        code: string;
        task_key?: string;
    }[];
    impact: AmendmentImpact;
    structural: DependencyReport;
}
export declare function validateSpecAmendment(tx: Tx, scope: SpecScope, input: unknown): Promise<AmendmentAnalysis>;
export declare function createComponent(_startup: ComponentContext): Component;
export {};
