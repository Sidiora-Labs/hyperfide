import type { ServiceResources } from './runtime.js';
interface ProbeInput {
    scenario: string;
    organisation_id: string;
    run_id: string;
    operation_id: string;
    source_epoch: string;
    signal: AbortSignal;
}
interface Artifact {
    path: string;
    sha256: string;
    size: number;
}
export interface DrillReconciliation {
    scope: string;
    mechanism: string;
    stale_workers: {
        presented: number;
        fenced: number;
        current_accepted: boolean;
    };
    external_effects: {
        outstanding: number;
        adopted: number;
        orphans_removed: number;
        unresolved: number;
    };
}
export interface DrillProbeResult {
    status: 'RECOVERED' | 'FAILED' | 'UNKNOWN';
    source_epoch: string;
    recovery_epoch: string | null;
    acknowledged_ids: readonly string[];
    recovered_ids: readonly string[];
    evidence_digest: string;
    limits: string;
    scope: string;
    artifacts: readonly Artifact[];
    started_at: string;
    completed_at: string;
    cleanup: {
        complete: boolean;
        root_absent: boolean;
        processes_absent: boolean;
    };
    reconciliation: DrillReconciliation | null;
}
export interface PostgresDrillResult extends DrillProbeResult {
    scope: 'ISOLATED_POSTGRESQL_FIXTURE';
}
/** Strictly copies producer reconciliation evidence; anything malformed is treated as missing evidence. */
export declare function reconciliationOf(value: unknown): DrillReconciliation | null;
export declare function createPostgresRecoveryProbe(_resources: ServiceResources, env: Readonly<NodeJS.ProcessEnv>): Readonly<{
    execute: (input: ProbeInput) => Promise<PostgresDrillResult>;
}>;
type LocalScenario = 'OBJECT' | 'GIT' | 'AUTH' | 'FULL_DISK' | 'PROVIDER';
export declare const LOCAL_DRILL_SCOPES: Readonly<Record<LocalScenario, string>>;
/** Registered drill producer: isolated PostgreSQL for DATABASE/RESTORE and owned local fixtures for every other scenario. */
export declare function createRecoveryProbe(resources: ServiceResources, env: Readonly<NodeJS.ProcessEnv>): Readonly<{
    ready: () => Promise<void>;
    execute: (input: ProbeInput) => Promise<DrillProbeResult>;
}>;
export {};
