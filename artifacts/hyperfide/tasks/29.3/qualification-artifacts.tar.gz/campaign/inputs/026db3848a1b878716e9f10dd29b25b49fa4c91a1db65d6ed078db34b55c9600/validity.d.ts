import type { Component, ComponentContext } from '../components/registry.js';
import type { Data, PrimaryClient } from './submission.js';
import type { CoverageScope, Queryable } from './coverage.js';
/** Accepted-spec writers use their existing primary transaction; history remains immutable. */
export declare function invalidateAcceptedSpec(db: Queryable, s: CoverageScope, taskIds: string[], reason: string): Promise<number>;
/** Read-only same-primary inspector for views and delivery accounting. */
export declare function inspectValidity(db: PrimaryClient, s: CoverageScope, id: string): Promise<Data>;
export declare function createComponent(ctx: ComponentContext): Component & {
    capabilities: Record<string, unknown>;
};
