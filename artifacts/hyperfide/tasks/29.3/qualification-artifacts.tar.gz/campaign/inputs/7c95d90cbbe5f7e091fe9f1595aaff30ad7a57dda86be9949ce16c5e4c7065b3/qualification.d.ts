import type { KeyObject } from 'node:crypto';
import type { Component, ComponentContext } from '../components/registry.js';
import type { AuthProfileSnapshot } from '../identity/native_auth.js';
import type { InvocationContext } from '../transport/protocol.js';
export declare const CONNECTOR_CAPABILITIES: readonly ['launch', 'input', 'output', 'steer', 'cancel', 'child_registration', 'resume'];
export type ConnectorCapability = typeof CONNECTOR_CAPABILITIES[number];
export type CapabilityOutcome = 'QUALIFIED' | 'UNQUALIFIED' | 'UNSUPPORTED' | 'REFUSED';
type ProbeResult = 'ACCEPTED' | 'REFUSED' | 'NOT_OFFERED';
export interface CapabilityObservation {
    result: ProbeResult;
    evidence_digest: string;
    context_restored: boolean;
}
export interface ConnectorObservationInput {
    profile_id: string;
    cli_version_output: string;
    binary_digest: string;
    resolution: {
        configured_model_alias: string;
        resolved_model_id: string;
        resolved_provider_id: string | null;
        source: 'cli-config' | 'auth-profile';
        config_digest: string | null;
    };
    observation: {
        native_session_id: string;
        observed_model_id: string;
        observed_provider_id: string | null;
        observation_digest: string;
    };
    probes: Record<ConnectorCapability, CapabilityObservation>;
}
export interface ConnectorQualificationPayload {
    schema_version: 1;
    receipt_id: string;
    connector: 'codex' | 'claude';
    cli_version: string;
    binary_digest: string;
    auth_mode: string;
    profile_id: string;
    profile_digest: string;
    configured_model_alias: string;
    requested_model_id: string;
    observed_model_id: string;
    observed_provider_id: string;
    capabilities: Record<ConnectorCapability, CapabilityOutcome>;
    issued_at: number;
    expires_at: number;
    evidence_digest: string;
    auth_qualification_digest: string;
}
export interface SignedConnectorReceipt {
    schema_version: 1;
    payload: string;
    signature: string;
}
export interface ConnectorQualificationRecord {
    key: string;
    state: 'QUALIFIED' | 'UNQUALIFIED';
    reasons: readonly string[];
    payload: ConnectorQualificationPayload;
    receipt_digest: string;
    receipt: SignedConnectorReceipt | null;
}
export interface NativeQualificationView {
    state: 'UNQUALIFIED' | 'QUALIFIED' | 'STALE';
    live_qualified: boolean;
    receipt_digest: string | null;
}
export interface ConnectorQualificationAuthority {
    readonly schema_version: 1;
    record(i: InvocationContext, input: unknown): Promise<ConnectorQualificationRecord>;
    inspect(profileId: string): ConnectorQualificationRecord | null;
    qualification(profileId: string): NativeQualificationView;
    receipt(profileId: string): SignedConnectorReceipt | null;
    publicKey(): string;
}
export declare function isConnectorQualificationAuthority(v: unknown): v is ConnectorQualificationAuthority;
export interface RegistryOptions {
    signingKey: KeyObject | null;
    ttlSeconds: number;
    now?: () => number;
    resolve: (profileId: string) => AuthProfileSnapshot;
    authenticate: (i: InvocationContext, profileId: string) => Promise<unknown>;
}
export declare function parseObservation(v: unknown): ConnectorObservationInput;
export declare function versionLine(connector: 'codex' | 'claude', version: string): string;
export declare function deriveOutcomes(s: AuthProfileSnapshot, o: ConnectorObservationInput): {
    capabilities: Record<ConnectorCapability, CapabilityOutcome>;
    reasons: string[];
};
export declare function signReceipt(key: KeyObject, payload: ConnectorQualificationPayload): SignedConnectorReceipt;
export declare function rawPublicKey(key: KeyObject): string;
export declare function createConnectorQualificationRegistry(options: RegistryOptions): ConnectorQualificationAuthority;
export declare function createComponent(ctx: ComponentContext): Promise<Component>;
export {};
