import type { Operation } from '../transport/protocol.js';
import type { PrimaryTransaction } from '../storage/transactions.js';
import type { Component, ComponentContext } from '../components/registry.js';
export declare const REMOTE_JOB_CLASSES: readonly ['implementation', 'dependency_preparation', 'indexing', 'build', 'test', 'reproduction', 'review_execution', 'integration', 'installation', 'upgrade', 'self_development'];
export declare const SUPERVISORY_JOB_CLASSES: readonly ['supervision', 'control', 'source_inspection', 'graph_query', 'context_composition'];
export type RemoteJobClass = typeof REMOTE_JOB_CLASSES[number];
export type JobClass = RemoteJobClass | typeof SUPERVISORY_JOB_CLASSES[number];
export type MainTool = 'source.read' | 'graph.query' | 'state.query' | 'supervise' | 'delegate' | 'native.shell' | 'native.file.write' | 'native.spawn' | 'native.process.stop' | 'supervisor.session.launch';
export declare const REGISTERED_RUNNER_TOOLS: Readonly<{
    'runner.test.execute': Readonly<{
        job_class: 'test';
        tool: 'native.spawn';
    }>;
    'runner.review.execute': Readonly<{
        job_class: 'review_execution';
        tool: 'native.spawn';
    }>;
    'runner.integration.execute': Readonly<{
        job_class: 'integration';
        tool: 'native.spawn';
    }>;
    'runner.index.execute': Readonly<{
        job_class: 'indexing';
        tool: 'native.spawn';
    }>;
    'runner.build.execute': Readonly<{
        job_class: 'build';
        tool: 'native.spawn';
    }>;
    'runner.preparation.execute': Readonly<{
        job_class: 'dependency_preparation';
        tool: 'native.spawn';
    }>;
    'runner.slot.prepare': Readonly<{
        job_class: 'dependency_preparation';
        tool: 'native.file.write';
    }>;
    'runner.agent.launch': Readonly<{
        job_class: 'implementation';
        tool: 'native.spawn';
    }>;
    'runner.inspect': Readonly<{
        job_class: 'supervision';
        tool: 'state.query';
    }>;
    'runner.stop': Readonly<{
        job_class: 'control';
        tool: 'native.process.stop';
    }>;
}>;
export type RunnerAction = keyof typeof REGISTERED_RUNNER_TOOLS;
export declare function registeredRunnerTool(action: unknown): {
    job_class: JobClass;
    tool: MainTool;
};
export interface PlacementProfile {
    schema_version: 1;
    programme_id: string;
    repository: string;
    spec_revision: string;
    policy_revision: number;
    supervisory_host_id: string;
    restrictions: {
        profile_digest: string;
        evidence_digest: string;
        qualification: 'QUALIFIED';
        expires_at: string;
    };
}
export interface HostBinding {
    host_id: string;
    kind: 'SUPERVISORY' | 'REMOTE';
    boot_generation: string;
}
export interface PlacementDecision {
    job_class: JobClass;
    host_id: string;
    location: 'LOCAL_SUPERVISION' | 'REMOTE_EXECUTION';
    spec_revision: string;
    policy_revision: number;
    policy_digest: string;
}
export declare function validatePlacementProfile(input: unknown, context: ComponentContext): PlacementProfile;
export declare function validateHostBinding(input: unknown): HostBinding;
/**
 * Execution gateways must pass their authenticated host binding and actual registered tool class.
 * An agent's prompt, job label, environment labels, or requested target cannot replace that binding.
 * No local shell, write or native spawn is admitted on the supervisory host, including upgrades/self-work.
 */
export declare function enforcePlacement(profile: PlacementProfile, binding: HostBinding, job: unknown, tool: unknown): PlacementDecision;
interface PlacementPrincipal {
    credential_id?: string;
    actor_id: string;
    organisation_id: string;
    run_id: string;
    role: string;
    deployment_epoch: string;
    sandbox_id: string | null;
    boot_id: string | null;
    boot_generation: string | null;
    allowed_actions: readonly string[];
}
export interface PlacementInvocation {
    operation: Operation;
    principal: PlacementPrincipal;
    guard(tx: PrimaryTransaction): Promise<void>;
}
export interface RemoteDestinationInput {
    job_class: RemoteJobClass;
    tool: MainTool;
    target_sandbox_id: string;
    boot_generation: string;
}
export interface PlacementAuthorization extends PlacementDecision {
    authorized: true;
    authority: 'PLACEMENT_ONLY';
    tool: MainTool;
    boot_generation: string;
    execution_started: false;
    capacity_reserved: false;
}
export interface SupervisorSessionInput {
    session_id: string;
    leader_generation: string;
    package_id: string | null;
    package_generation: string | null;
}
export interface SupervisorAuthorization extends PlacementAuthorization {
    supervisor_session_id: string;
    supervisor_role: 'LEADER' | 'FEATURE_MANAGER';
    restriction_profile_digest: string;
    restriction_evidence_digest: string;
}
export interface PlacementAuthority {
    authorizeSupervisor(tx: PrimaryTransaction, invocation: PlacementInvocation, input: SupervisorSessionInput): Promise<SupervisorAuthorization>;
    authorize(tx: PrimaryTransaction, invocation: PlacementInvocation, input: {
        job_class: JobClass;
        tool: MainTool;
    }): Promise<PlacementAuthorization>;
    admitRemote(tx: PrimaryTransaction, invocation: PlacementInvocation, input: RemoteDestinationInput): Promise<PlacementAuthorization>;
}
export declare function isPlacementAuthority(value: unknown): value is PlacementAuthority;
export declare function createComponent(context: ComponentContext): Component;
export {};
