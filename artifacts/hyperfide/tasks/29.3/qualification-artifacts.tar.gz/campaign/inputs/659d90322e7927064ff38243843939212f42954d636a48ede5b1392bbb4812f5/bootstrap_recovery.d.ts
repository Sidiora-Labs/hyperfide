import type { ServiceResources } from './storage/runtime.js';
import type { BootstrapPolicy } from './bootstrap_identity.js';
export declare const RECOVERY_REASONS: readonly ["LOST", "COMPROMISED", "EXPIRED"];
export interface RecoveryReceipt {
    recovery_id: string;
    generation: string;
    previous_credential_id: string;
    previous_state: string;
    credential_id: string;
    organisation_id: string;
    run_id: string;
    actor_id: string;
    role: 'OPERATOR';
    credential_version: string;
    deployment_epoch: string;
    expires_at: string;
    accepted_revision_digest: string;
    reason: string;
    replayed: boolean;
}
export declare function recoverBootstrapOperator(resources: ServiceResources, value: unknown, policy: BootstrapPolicy, signal?: AbortSignal): Promise<RecoveryReceipt>;
