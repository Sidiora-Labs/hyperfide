import type { VerifiedIsolationPermit } from '../identity/credentials.js';
export interface IsolationFenceReceipt {
    readonly deployment_id: string;
    readonly operation_id: string;
    readonly fence_id: string;
    readonly source_epoch: string | null;
    readonly isolated_writer: string;
    readonly observed_at: string;
    readonly expires_at: string;
    readonly evidence_digest: string;
}
export interface IsolationPermitVerifier {
    verifySigned(serialized: Buffer | string): VerifiedIsolationPermit;
}
export interface IsolationHttpTransportOptions {
    readonly origin: string;
    readonly host: string;
    readonly port: number;
    readonly certificate: string;
    readonly privateKey: string;
    readonly signal: AbortSignal;
    readonly verifier: IsolationPermitVerifier;
    readonly dispatch: (permit: VerifiedIsolationPermit, signal: AbortSignal) => Promise<IsolationFenceReceipt>;
    readonly maxConcurrent?: number;
    readonly deadlineMs?: number;
}
export interface IsolationHttpTransport {
    readonly address: string;
    close(): Promise<void>;
}
export type IsolationHttpResult = {
    readonly outcome: 'SUCCEEDED';
    readonly receipt: IsolationFenceReceipt;
} | {
    readonly outcome: 'REJECTED';
    readonly code: string;
} | {
    readonly outcome: 'UNKNOWN';
    readonly code: 'ISOLATION_OUTCOME_UNKNOWN';
};
export interface IsolationHttpClientOptions {
    readonly origin: string;
    readonly caFile: string;
    readonly deadlineMs?: number;
    readonly maxConcurrent?: number;
}
export interface IsolationHttpClient {
    isolate(permitEnvelope: string, signal: AbortSignal): Promise<IsolationHttpResult>;
}
export declare function parseIsolationFenceReceipt(value: unknown): IsolationFenceReceipt;
/** Separate permit-only listener. It cannot enrol, register or activate any authority. */
export declare function startIsolationHttpTransport(options: IsolationHttpTransportOptions): Promise<IsolationHttpTransport>;
/** No redirects, dynamic URLs, bearer identity or PG fallback are accepted. */
export declare function createIsolationHttpClient(options: IsolationHttpClientOptions): Promise<IsolationHttpClient>;
