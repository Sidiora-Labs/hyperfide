import type pg from 'pg';
import type { Component, ComponentContext } from '../components/registry.js';
import { type PrimaryTransaction } from '../storage/transactions.js';
export interface RecoveryScope {
    organisation_id: string;
    run_id: string;
    authority_epoch: string;
}
export interface RecoveryTransaction {
    query<R extends pg.QueryResultRow = pg.QueryResultRow>(sql: string, values?: unknown[]): Promise<pg.QueryResult<R>>;
    remainingMs(): number;
    readonly signal: AbortSignal;
}
export interface RecoveryGateway {
    withPrimaryTransaction<T>(options: {
        timeoutMs: number;
        maxRetries?: number;
        guard?: (tx: RecoveryTransaction) => Promise<void>;
        signal?: AbortSignal;
    }, body: (tx: RecoveryTransaction) => Promise<T>): Promise<T>;
}
export interface RecoveryAuthority {
    assertCurrent(tx: RecoveryTransaction, scope: RecoveryScope): Promise<void>;
}
export interface RecoverySupervisor {
    observe(input: {
        scope: RecoveryScope;
        session_id: string;
        attempt_id: string | null;
        sandbox_id: string | null;
        boot_generation: string | null;
    }): Promise<{
        status: 'MATCHED_RUNNING' | 'CONFIRMED_STOPPED' | 'UNKNOWN' | 'IDENTITY_MISMATCH';
        evidence_digest: string;
        observed_at: string;
    }>;
    stop(input: {
        scope: RecoveryScope;
        session_id: string;
        command_id: string;
        generation: string;
    }): Promise<{
        status: 'CONFIRMED_STOPPED' | 'UNKNOWN' | 'IDENTITY_MISMATCH';
        evidence_digest: string;
        observed_at: string;
    }>;
}
export declare function fail(code: string, message: string): never;
export declare function record(value: unknown, required: string[], optional?: string[]): Record<string, unknown>;
export declare function uuid(value: unknown): string;
export declare function positive(value: unknown): string;
export declare function digest(value: unknown): string;
export declare function timestamp(value: unknown): number;
export declare function scopeOf(value: unknown): RecoveryScope;
export declare function capability<T>(context: ComponentContext, id: string, name: string, guard: (value: unknown) => value is T): T;
export interface RecoveryEvents {
    recoverySnapshot(tx: RecoveryTransaction, input: {
        organisation_id: string;
        run_id: string;
        limit: number;
    }): Promise<unknown>;
}
export interface RecoverySnapshotReader {
    read(tx: RecoveryTransaction, scope: RecoveryScope): Promise<Record<string, unknown>>;
}
export declare function isRecoveryEvents(value: unknown): value is RecoveryEvents;
export declare function isRecoverySnapshotReader(value: unknown): value is RecoverySnapshotReader;
export declare function isGateway(value: unknown): value is RecoveryGateway;
export declare function isAuthority(value: unknown): value is RecoveryAuthority;
export interface RecoveryExecutionControls {
    applyExecutionControl(tx: RecoveryTransaction, scope: RecoveryScope, input: {
        scope_kind: 'RUN' | 'PACKAGE' | 'ATTEMPT' | 'SANDBOX';
        scope_id: string;
        mode: 'ACTIVE' | 'PAUSE' | 'DRAIN' | 'STOP';
        operation_id: string;
        reason: string;
        expected_generation?: string;
        resume?: boolean;
        deadline_at?: string;
        fallback_mode?: 'PAUSE' | 'STOP';
    }): Promise<unknown>;
}
export declare function isExecutionControls(value: unknown): value is RecoveryExecutionControls;
export declare function derivedOperationId(namespace: string, label: string): string;
export declare function isSupervisor(value: unknown): value is RecoverySupervisor;
export declare function canonical(value: unknown): string;
export declare function inputDigest(value: unknown): string;
export declare function recoveryReady(tx: Pick<RecoveryTransaction, 'query'>): Promise<void>;
export declare function lockRun(tx: RecoveryTransaction, scope: RecoveryScope, write?: boolean): Promise<pg.QueryResultRow>;
export declare function recoveryTransaction<T>(context: ComponentContext, scope: RecoveryScope, body: (tx: RecoveryTransaction) => Promise<T>, requiresExternalAuthority?: boolean, observation?: boolean): Promise<T>;
export declare function operationReplay(tx: RecoveryTransaction, scope: RecoveryScope, operationId: string, kind: string, input: unknown): Promise<Record<string, unknown> | null>;
export declare function finishOperation(tx: RecoveryTransaction, scope: RecoveryScope, id: string, result: Record<string, unknown>, state?: string): Promise<void>;
export declare function inspectRecoveryHold(tx: Pick<RecoveryTransaction, 'query'>, scope: RecoveryScope): Promise<pg.QueryResultRow[]>;
/** Reads one consistent authoritative snapshot. Candidate adoption grants no new compute authority. */
export declare function readControlSnapshot(tx: Pick<RecoveryTransaction, 'query'>, scope: RecoveryScope, events?: RecoveryEvents): Promise<Record<string, unknown>>;
/** Recorded state, a PID or an open pipe is never live progress; only an exact supervisor identity observation is.
 * Native resume support is reported from durable checkpoints and is never claimed as verified here. */
export declare function inspectSessionRecovery(tx: Pick<RecoveryTransaction, 'query'>, scope: RecoveryScope): Promise<Record<string, unknown>[]>;
export declare function reconstructControl(pool: pg.Pool, scope: RecoveryScope): Promise<Record<string, unknown>>;
export declare function evaluateOffline(input: unknown, now?: number, limits?: {
    mode: 'PAUSE' | 'BOUNDED_LOCAL';
    maxOfflineMs: number;
}): Record<string, unknown>;
export declare function inspectIntegrationRecovery(tx: Pick<RecoveryTransaction, 'query'>, scope: RecoveryScope): Promise<{
    ready: boolean;
    jobs: pg.QueryResultRow[];
    scope_jobs: pg.QueryResultRow[];
    preparations: pg.QueryResultRow[];
}>;
export declare function createRecoveryControlCapability(): Readonly<{
    inspectHolds: typeof inspectRecoveryHold;
    assertQuiesced: (tx: RecoveryTransaction, scope: RecoveryScope) => Promise<void>;
    assertNoNewEffects: (tx: RecoveryTransaction, scope: RecoveryScope) => Promise<void>;
}>;
export declare const SUPERVISOR_PROVIDER: {
    readonly id: '12.4';
    readonly capability: 'runner.supervisors.v1';
};
export declare function supervisorCapability(context: ComponentContext): RecoverySupervisor;
export declare function createComponent(startup: ComponentContext): Component;
export interface AcceptedRunRebindInput {
    schema_version: 1;
    organisation_id: string;
    run_id: string;
    recovery_operation_id: string;
    activation_operation_id: string;
    deployment_id: string;
    expected_run_epoch: string;
    target_epoch: string;
    expected_spec_generation: string;
    expected_spec_revision_id: string;
    expected_revision_digest: string;
    external_previous_epoch: string | null;
    database_predecessor_epoch: string | null;
    fence_proof_digest: string;
    external_journal_sequence: string;
}
export interface AcceptedRunRecoveryIntent extends AcceptedRunRebindInput {
    intent_digest: string;
}
/** Only trusted local deployment composition receives this factory. A signed isolation
 * permit cannot call it or authorise run rebind. All proof is read from retained journals.
 */
export declare function createAcceptedRunRecoveryVerifier(options: {
    resources: import('../storage/runtime.js').ServiceResources;
    journal: import('../storage/authority_journal.js').ExternalAuthorityJournal;
    fenceJournal: import('./fencing.js').FileExternalFenceJournal;
    topology: import('./fencing.js').ExternalFenceTopology;
    revokeCompute: (tx: PrimaryTransaction, input: AcceptedRunRebindInput) => Promise<{
        revoked_attempts: string;
        revoked_allocations: string;
        retained_debt_references: readonly string[];
    }>;
}): Readonly<{
    prepare: (raw: AcceptedRunRebindInput) => Promise<Readonly<{
        verify: (tx: PrimaryTransaction) => Promise<AcceptedRunRecoveryIntent>;
        revokeCompute: (tx: PrimaryTransaction) => Promise<{
            revoked_attempts: string;
            revoked_allocations: string;
            retained_debt_references: readonly string[];
        }>;
    }>>;
}>;
