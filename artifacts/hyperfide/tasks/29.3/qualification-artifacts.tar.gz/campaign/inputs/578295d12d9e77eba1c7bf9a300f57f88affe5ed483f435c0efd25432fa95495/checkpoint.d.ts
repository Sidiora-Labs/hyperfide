import type { PreparationManifest } from './manifests.js';
export interface CheckpointExpected {
    checkpoint_digest: string;
    source_metadata_digest: string;
    source_repository_id: string;
    source_workspace_id: string;
    source_object_id: string;
    source_preparation_digest: string;
    parent_preparation_digest: string;
}
export interface RestoredCheckpointInput {
    capsule: Uint8Array;
    expected: CheckpointExpected;
    native_result: unknown;
    workspace_path: string;
    scratch_root: string;
    parent_manifest: PreparationManifest;
    repository_key: string;
    signal?: AbortSignal;
    timeout_ms?: number;
}
type Row = Record<string, any>;
/** Byte validation only. A stable local scan cannot prove external writer
 * quiescence or grant preparation/readiness.12 must seal these bytes separately. */
export declare function validateRestoredCheckpoint(input: RestoredCheckpointInput): Promise<Row>;
export {};
