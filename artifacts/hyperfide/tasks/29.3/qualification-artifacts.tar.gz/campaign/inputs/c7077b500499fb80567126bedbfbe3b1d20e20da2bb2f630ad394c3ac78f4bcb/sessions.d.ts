import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext, AuthorityTransaction } from '../transport/protocol.js';
export declare function readTrustedAgentFile(filename: string, maxBytes: number): Promise<Buffer>;
export type AgentScope = {
    organisation_id: string;
    run_id: string;
    session_id: string;
};
type RecordValue = Record<string, unknown>;
export declare function agentError(code: string): never;
export declare function exactAgentObject(value: unknown, required: string[], optional?: string[]): RecordValue;
export declare function agentString(value: unknown, kind?: 'uuid' | 'digest' | 'name' | 'decimal'): string;
export declare function agentScope(value: unknown, invocation: InvocationContext): AgentScope;
export declare function assertNativeRunnerScope(i: InvocationContext, admitted: Record<string, unknown>, nativeBinding?: Record<string, unknown>): void;
export declare function agentDigest(value: unknown): string;
export declare function agentTransaction<T>(ctx: ComponentContext, invocation: InvocationContext, callback: (client: AuthorityTransaction) => Promise<T>): Promise<T>;
export declare function getNativeSessionProfile(ctx: ComponentContext, authProfile: unknown): Promise<RecordValue>;
export declare function agentOperation(client: AuthorityTransaction, s: AgentScope, id: string, payload: unknown, run: () => Promise<RecordValue>, invocation: InvocationContext): Promise<RecordValue>;
export interface AgentSessionsCapability {
    readonly schema_version: 1;
    resumeCheck(input: unknown, invocation: InvocationContext): Promise<unknown>;
}
export declare function isAgentSessionsCapability(value: unknown): value is AgentSessionsCapability;
export declare function createComponent(ctx: ComponentContext): Component;
export {};
