import type { Component, ComponentContext } from '../components/registry.js';
import type { PrimaryTransaction } from '../storage/transactions.js';
import type { OutboxEvent, Scope } from './outbox.js';
export interface InboxResult {
    status: 'APPLIED' | 'DUPLICATE' | 'GAP' | 'RESNAPSHOT_REQUIRED';
    event_id: string;
    inbox_id?: string;
    expected_version?: string;
    observed_version?: string;
    result?: unknown;
}
export declare function receive(tx: PrimaryTransaction, input: unknown, apply?: (tx: PrimaryTransaction, e: OutboxEvent) => Promise<unknown>): Promise<InboxResult>;
export declare function replay(tx: PrimaryTransaction, input: unknown): Promise<unknown>;
export interface SnapshotBootstrap extends Scope {
    bootstrap_id: string;
    consumer_id: string;
    aggregate_types: readonly string[];
    limit: number;
}
export declare function bootstrapConsumer(tx: PrimaryTransaction, input: SnapshotBootstrap, buildSnapshot: (tx: PrimaryTransaction) => Promise<unknown>): Promise<unknown>;
export interface DeliverySupersession extends Scope {
    transfer_id: string;
    original_event_id: string;
    original_consumer_id: string;
    replacement_event_id: string;
    replacement_consumer_id: string;
}
export declare function supersedeDelivery(tx: PrimaryTransaction, input: DeliverySupersession, authorize: (tx: PrimaryTransaction, events: {
    original: OutboxEvent;
    replacement: OutboxEvent;
}) => Promise<Record<string, unknown>>): Promise<unknown>;
export interface EventInboxCapability {
    receive: typeof receive;
    replay: typeof replay;
    bootstrapConsumer: typeof bootstrapConsumer;
    supersedeDelivery: typeof supersedeDelivery;
}
export declare function isEventInboxCapability(value: unknown): value is EventInboxCapability;
export declare function createComponent(context: ComponentContext): Component;
