import type { Component, ComponentContext } from '../components/registry.js';
import type { ReviewControl, ReviewDb, ReviewScope } from './coverage.js';
export declare function buildReviewSnapshot(db: ReviewDb, binding: ReviewScope, candidateDigest: string, value: unknown, context?: ComponentContext): Promise<Record<string, unknown>>;
export declare function bindReviewInputs(context: ComponentContext, value: unknown): Promise<unknown>;
export declare const REVIEW_CERTIFICATION: {
    certifies_correctness: boolean;
    decision_model_role: string;
    coverage_authority: string;
};
export declare function submitReviewReceipt(context: ComponentContext, value: unknown): Promise<unknown>;
export declare function claimReviewObligation(context: ComponentContext, value: unknown): Promise<unknown>;
export declare function reconcileReviewInputs(db: ReviewDb, binding: ReviewScope, afterId?: string | null, limit?: number): Promise<unknown>;
export declare function createComponent(_context: ComponentContext): Component;
export declare function fenceReviewObligations(db: ReviewDb, binding: ReviewScope, control: ReviewControl): Promise<unknown>;
export declare function renewReviewObligation(context: ComponentContext, value: unknown): Promise<unknown>;
