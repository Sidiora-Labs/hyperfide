import type { PrimaryTransaction } from '../storage/transactions.js';
export type FailureClass = 'PROVIDER_UNAVAILABLE' | 'PROVIDER_FAILED' | 'PACKAGE_FAILURE' | 'PARTIAL_DOWNLOAD' | 'READINESS_FAILED' | 'OBSOLETE_MANIFEST';
export interface PreparationJobRow {
    organisation_id: string;
    run_id: string;
    id: string;
    pool_id: string;
    profile_id: string;
    job_class: 'PREPARATION' | 'INDEX';
    warm_spare: boolean;
    configuration_digest: string;
    preparation_digest: string;
    recipe_digest: string;
    plan_digest: string;
    plan: unknown;
    intent_id: string;
    sandbox_id: string;
    state: string;
    attempts: number;
    max_attempts: number;
    backoff_base_ms: number;
    backoff_max_ms: number;
    next_attempt_at: string;
    prepared_base_id: string | null;
    reservation_ids: string[];
    physical_reservation_ids: string[];
}
export interface PreparationTarget {
    provider: 'railway' | 'blaxel';
    configuration_digest: string;
    preparation_digest: string;
    profile_id: string | null;
}
export interface RemoteReport {
    job_id: string;
    attempt: number;
    execution: {
        host_class: string;
        sandbox_id: string;
        boot_generation: string;
        native_sandbox_id: string;
    };
    manifest_artifact_digest: string;
    provider_reference: {
        preparation_reference: string;
    };
    execution_receipt: Record<string, unknown>;
    verification_receipt: Record<string, unknown>;
}
export type Classification = {
    ok: true;
} | {
    ok: false;
    failure_class: FailureClass;
    retryable: boolean;
    detail: string;
};
export declare const documentDigest: (value: unknown) => string;
/** Only exact current pool configuration and preparation identity may be published. */
export declare function isObsolete(job: PreparationJobRow, target: PreparationTarget): boolean;
/**
 * Classifies a remote attempt from its retained receipts. Order matters: an obsolete manifest is never
 * retried, a package failure or partial download is retryable, and readiness must be observed READY.
 */
export declare function classifyRemoteReport(job: PreparationJobRow, report: RemoteReport, target: PreparationTarget): Classification;
export declare function backoffMs(job: Pick<PreparationJobRow, 'backoff_base_ms' | 'backoff_max_ms'>, attempt: number): number;
/** Diagnostics are retained as a COMPLETE artifact whose bytes live in the attempt row. */
export declare function retainDiagnostics(tx: PrimaryTransaction, job: PreparationJobRow, attempt: number, diagnostics: Record<string, unknown>): Promise<string>;
/** Ends the current attempt; retryable failures back off until the bounded attempt limit is reached. */
export declare function finishAttempt(tx: PrimaryTransaction, job: PreparationJobRow, attempt: number, result: {
    outcome: 'SUCCEEDED';
} | {
    outcome: 'FAILURE';
    failure_class: FailureClass;
    retryable: boolean;
}, diagnostics: Record<string, unknown>): Promise<{
    state: string;
    outcome: string;
    next_attempt_at: string | null;
    diagnostics_artifact_digest: string;
}>;
/** Older bases for this pool/profile become STALE once their configuration or preparation identity is not current. */
export declare function markObsoleteBases(tx: PrimaryTransaction, job: Pick<PreparationJobRow, 'organisation_id' | 'pool_id' | 'profile_id'>, target: PreparationTarget): Promise<string[]>;
/** Every receipt must be a COMPLETE retained artifact whose digest is the exact canonical receipt body. */
export declare function requireCompleteArtifacts(tx: PrimaryTransaction, job: PreparationJobRow, digests: readonly string[]): Promise<void>;
/**
 * Publishes one pool-verified reusable base. Callers have already classified the attempt as successful;
 * this re-checks currency and complete custody under lock before inserting the QUALIFIED row.
 */
export declare function sealPreparedBase(tx: PrimaryTransaction, job: PreparationJobRow, report: RemoteReport, target: PreparationTarget, manifest: unknown, expiresAt: string): Promise<{
    base_id: string;
    provider_prepared_digest: string;
    stale: string[];
}>;
