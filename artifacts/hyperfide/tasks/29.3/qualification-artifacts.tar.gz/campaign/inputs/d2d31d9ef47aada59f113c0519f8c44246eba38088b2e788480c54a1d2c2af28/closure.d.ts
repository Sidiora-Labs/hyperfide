import type { Component, ComponentContext } from '../components/registry.js';
import { git, type Scope, type DB, type IntegrationConfig, type GateConfig, type AdmittedIntegrationWork } from './candidates.js';
type Level = 'TASK' | 'WAVE' | 'PROGRAMME';
interface ScopeGate extends GateConfig {
    covers: string[];
    proof: {
        manifest_path: string;
        manifest_digest: string;
        registry_path: string;
        registry_digest: string;
        expected_assertion_ids: string[];
        case_ids: string[];
    };
}
interface ClosurePolicy {
    wave_gates: ScopeGate[];
    programme_gates: ScopeGate[];
    required_acceptance_ids: string[];
    required_docs: boolean;
    end_to_end_ids?: string[];
    activation_rehearsal_ids?: string[];
}
/** One explicit obligation of exactly one closure level; unmet obligations are reported, never inferred from lower levels. */
export interface ClosureObligation {
    level: Level;
    id: string;
    met: boolean;
    reason: string | null;
    detail?: unknown;
}
export declare function closurePolicy(c: IntegrationConfig): ClosurePolicy;
/** Programme-only end-to-end and activation/rehearsal obligations, satisfied only by current PASS programme receipts covering each case. */
export declare function programmeCaseObligations(policy: ClosurePolicy, receipts: Record<string, any>[], inputDigest: string): ClosureObligation[];
export declare function closureSnapshot(db: DB, s: Scope, level: Level, wave?: number, taskId?: string, admittedWork?: AdmittedIntegrationWork): Promise<Record<string, any>>;
export declare function evaluateClosure(pool: import('./candidates.js').DB, cfg: IntegrationConfig, input: unknown): Promise<unknown>;
export declare function integratedRepositoryManifest(snapshot: Record<string, any>): Record<string, string>[];
export declare function integratedManifestDigest(snapshot: Record<string, any>): string;
export declare const integrationGit: typeof git;
export declare function registeredScopeGate(gate: ScopeGate, cwd: string, work: string, inputDigest: string, env: Readonly<NodeJS.ProcessEnv>, requireFull?: boolean): Promise<{
    stdout: string;
    stderr: string;
    exitCode: number;
    assertions: number;
    proof: Record<string, unknown>;
}>;
export declare function createComponent(ctx: ComponentContext): Component;
/** Primary-authoritative task delivery denominator; programme closure stays separate. */
export declare function qualifiedIntegratedOutcomes(db: DB, s: Scope): Promise<Record<string, unknown>>;
/** Uses the exact current primary snapshot and previously executed immutable full-case receipts. */
export declare function inspectProgrammeClosure(db: DB, invocation: unknown): Promise<Record<string, unknown>>;
export {};
