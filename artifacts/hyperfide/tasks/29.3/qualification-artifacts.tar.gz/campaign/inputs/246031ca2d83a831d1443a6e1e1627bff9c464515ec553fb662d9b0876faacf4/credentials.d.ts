import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { IdentityTransaction } from './enrollment.js';
export type CredentialPurpose = 'WORKER_BUILD' | 'WORKER_RUNTIME' | 'WORKER_PROCESS' | 'PROVIDER_API';
export interface CredentialResolutionRequest {
    references: readonly {
        name: string;
        reference_id: string;
    }[];
    purpose: CredentialPurpose;
    sandbox_id: string;
    boot_id: string;
    boot_generation: string;
}
export type EnvironmentLayer = 'image' | 'build' | 'runtime' | 'process';
export type SecretLayer = Exclude<EnvironmentLayer, 'image'>;
export type LayeredEnvironment = {
    readonly [L in EnvironmentLayer]: Readonly<Record<string, string>>;
};
export type CredentialStatus = 'AVAILABLE' | 'MISSING' | 'EXPIRED' | 'REVOKED' | 'AUTH_BLOCKED';
export interface CredentialAvailability {
    schema_version: 1;
    reference_id: string;
    credential_version: string | null;
    status: CredentialStatus;
    expires_at: string | null;
    assignment_scope: {
        run_id: string;
        actor_id: string;
        attempt_id: string | null;
    };
    attachment_id: string | null;
}
export interface CredentialAuthority {
    inspectInTransaction(tx: IdentityTransaction, i: InvocationContext, reference: string): Promise<CredentialAvailability>;
    resolveCredentialReferences(i: InvocationContext, request: CredentialResolutionRequest, signal?: AbortSignal): Promise<Readonly<Record<string, string>>>;
    inspect(i: InvocationContext, reference: string): Promise<CredentialAvailability>;
    attach(i: InvocationContext, reference: string, layer: string): Promise<CredentialAvailability>;
    privateAttachment(i: InvocationContext, id: string): Promise<{
        path: string;
        uid: number;
        expires_at: string;
    }>;
}
export declare function isCredentialAuthority(v: unknown): v is CredentialAuthority;
export declare function composeEnvironment(layers: LayeredEnvironment | unknown): Readonly<Record<string, string>>;
export declare class StreamingRedactor {
    private pending;
    private readonly secrets;
    private readonly reserve;
    constructor(secrets: readonly string[]);
    push(chunk: string, final?: boolean): string;
}
export declare function createComponent(ctx: ComponentContext): Promise<Component>;
export interface IsolationPermitClaims {
    readonly schema_version: 1;
    readonly purpose: 'EXTERNAL_WRITER_ISOLATION_ONLY';
    readonly deployment_id: string;
    readonly operation_id: string;
    readonly organisation_id: string;
    readonly run_id: string;
    readonly source_epoch: string | null;
    readonly topology_digest: string;
    readonly resources: readonly {
        readonly reference_key: string;
        readonly topology_digest: string;
    }[];
    readonly issued_at: string;
    readonly expires_at: string;
    readonly nonce: string;
}
export interface IsolationPermitExpectation {
    readonly deployment_id: string;
    readonly operation_id: string;
    readonly organisation_id: string;
    readonly run_id: string;
    readonly source_epoch: string | null;
    readonly topology_digest: string;
    readonly resource_reference?: string;
    readonly resource_topology_digest?: string;
}
export interface VerifiedIsolationPermit extends IsolationPermitClaims {
    readonly permit_digest: string;
    readonly issuer_key_id: string;
}
export interface IsolationPermitVerifier {
    verifySigned(serialized: Buffer | string): VerifiedIsolationPermit;
    verify(serialized: Buffer | string, expected: IsolationPermitExpectation): VerifiedIsolationPermit;
}
export declare function isVerifiedIsolationPermit(value: unknown): value is VerifiedIsolationPermit;
export declare function assertVerifiedIsolationPermit(value: unknown): asserts value is VerifiedIsolationPermit;
export declare function assertIsolationPermit(value: unknown, expected: IsolationPermitExpectation): asserts value is VerifiedIsolationPermit;
export declare function issueIsolationPermit(claims: IsolationPermitClaims, issuer: {
    key_id: string;
    private_key_file: string;
}): Promise<string>;
export declare function loadIsolationPermitVerifier(configFile: string): Promise<IsolationPermitVerifier>;
export type WriterObservationPermitClaims = Omit<IsolationPermitClaims, 'purpose'> & {
    readonly purpose: 'EXTERNAL_WRITER_OBSERVATION_ONLY';
};
export interface VerifiedWriterObservationPermit extends WriterObservationPermitClaims {
    readonly permit_digest: string;
    readonly issuer_key_id: string;
}
export interface WriterObservationPermitVerifier {
    verifySigned(serialized: Buffer | string): VerifiedWriterObservationPermit;
    verify(serialized: Buffer | string, expected: IsolationPermitExpectation): VerifiedWriterObservationPermit;
}
export declare function isVerifiedWriterObservationPermit(value: unknown): value is VerifiedWriterObservationPermit;
export declare function assertVerifiedWriterObservationPermit(value: unknown): asserts value is VerifiedWriterObservationPermit;
export declare function assertWriterObservationPermit(value: unknown, expected: IsolationPermitExpectation): asserts value is VerifiedWriterObservationPermit;
export declare function issueWriterObservationPermit(claims: WriterObservationPermitClaims, issuer: {
    key_id: string;
    private_key_file: string;
}): Promise<string>;
export declare function loadWriterObservationPermitVerifier(configFile: string): Promise<WriterObservationPermitVerifier>;
