import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import { assertRunnerPublicationAllowed } from './workspaces.js';
export declare const CAPTURE_CHUNK_BYTES = 196608;
export interface RunnerCaptureCapability {
    putChunk(i: InvocationContext, input: unknown): Promise<Record<string, unknown>>;
    assertPublicationAllowed: typeof assertRunnerPublicationAllowed;
}
export declare function isRunnerCaptureCapability(v: unknown): v is RunnerCaptureCapability;
export declare function createComponent(ctx: ComponentContext): Component;
