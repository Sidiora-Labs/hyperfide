import type { ComponentContext } from '../components/registry.js';
import { type PreparedRequest, type RouteId } from './adapters.js';
export interface Media {
    id: string;
    data_uri: string;
}
export interface CapabilityRequest {
    route_id: RouteId;
    request: unknown;
    media?: Media[];
    reasoning?: {
        mode: 'off' | 'on' | 'auto';
        budget_ms?: number;
    };
    timeout_ms: number;
    long_context?: boolean;
}
/** Profiles are trusted startup configuration; wire callers cannot enable an extension. */
export declare function prepareCapabilities(raw: unknown, env: Readonly<NodeJS.ProcessEnv>): {
    prepared: PreparedRequest;
    metadata: Record<string, unknown>;
};
export declare function billing(raw: unknown, env: Readonly<NodeJS.ProcessEnv>): Record<string, unknown>;
export declare function createComponent(ctx: ComponentContext): {
    apiVersion: number;
    capabilities: {
        'decision.capabilities.v1': Readonly<{
            schemaVersion: 1;
            prepare: (input: unknown) => {
                prepared: PreparedRequest;
                metadata: Record<string, unknown>;
            };
            billing: (input: unknown) => Record<string, unknown>;
        }>;
    };
    actions: {
        'decision.capabilities.prepare': (input: unknown) => {
            prepared: PreparedRequest;
            metadata: Record<string, unknown>;
        };
        'decision.capabilities.billing': (input: unknown) => Record<string, unknown>;
    };
};
