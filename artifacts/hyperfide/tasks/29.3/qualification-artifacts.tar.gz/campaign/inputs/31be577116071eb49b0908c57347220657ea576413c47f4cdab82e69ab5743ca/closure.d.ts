import type { Component, ComponentContext } from '../components/registry.js';
import { type PrimaryTransaction } from '../storage/transactions.js';
export type RecordValue = Record<string, unknown>;
export declare function invalid(message: string): never;
export declare function fields(value: unknown, required: string[], optional?: string[]): RecordValue;
export declare function boundedText(value: unknown, max?: number): string;
export declare function sha256(value: Uint8Array | string): string;
export declare function canonical(value: unknown): string;
export declare function contentDigest(value: unknown): string;
export declare function digest(value: unknown): string;
export declare function uuid(value: unknown): string;
export declare function decimal(value: unknown): string;
export declare function stringList(value: unknown, min?: number, max?: number): string[];
export interface Scope {
    organisation_id: string;
    run_id: string;
}
export interface DocumentationPins {
    spec_revision_id: string;
    spec_generation: string;
    programme_manifest_digest: string;
    source_manifest_digest: string;
}
export interface DocumentationInspection {
    status: 'CURRENT' | 'STALE' | 'MISSING' | 'HELD';
    closed: boolean;
    source_manifest_digest: string;
    reasons: string[];
    checker_receipt_digest?: string;
    snapshot_digest?: string;
    baseline_digest?: string;
    receipt_id?: string;
}
interface DocumentationPolicy {
    mode: 'auto' | 'manual';
    targets: string[];
    check_cmd: string;
}
interface RepositoryVersion {
    repository_id: string;
    candidate_head: string;
    input_manifest_digest: string;
}
interface BlobSnapshot {
    path: string;
    digest: string;
    size: number;
    content_base64: string;
}
interface RepositorySnapshot {
    repository_id: string;
    commit: string;
    tree: string;
    files: BlobSnapshot[];
}
export interface DocumentationPacket {
    schema_version: 1;
    scope: Scope;
    pins: DocumentationPins;
    authority_epoch: string;
    policy: DocumentationPolicy;
    repositories: RepositoryVersion[];
    snapshot: {
        repositories: RepositorySnapshot[];
    };
    snapshot_digest: string;
    previous_baseline_digest: string | null;
    incremental?: DocumentationReload;
}
export interface DocumentationReload {
    previous_baseline_digest: string | null;
    changed: {
        repository_id: string;
        path: string;
    }[];
    removed: {
        repository_id: string;
        path: string;
    }[];
    unchanged: number;
}
export declare function documentationReload(previous: unknown, files: {
    repositories: RepositorySnapshot[];
}, previousDigest: string | null): DocumentationReload;
export declare function inspectDocumentationClosure(db: Pick<PrimaryTransaction, 'query'>, scope: Scope, p: DocumentationPins): Promise<DocumentationInspection>;
export declare function packetDocumentation(input: unknown, context: ComponentContext): Promise<unknown>;
export declare function closeDocumentation(input: unknown, context: ComponentContext): Promise<unknown>;
export declare function createClosureComponent(_context: ComponentContext): Component;
export declare function persistReleaseArtifact(context: ComponentContext, kind: string, payload: unknown): Promise<RecordValue>;
export declare function validateDocumentationResult(value: unknown, packet: DocumentationPacket, packetDigest: string, repositoryID: string): RecordValue;
export declare function checkDocumentation(input: unknown, context: ComponentContext): Promise<unknown>;
export declare function createComponent(context: ComponentContext): Component;
export declare function requireDocumentationCleanup(value: unknown): void;
export {};
