import type { Component, ComponentContext } from '../components/registry.js';
export interface VersionPin {
    name: string;
    version: string;
}
export interface FilePin {
    path: string;
    digest: string;
}
export interface EnvironmentProfile {
    schema_version: 1;
    profile_id: string;
    profile_version: string;
    os: {
        distribution: string;
        version: string;
        architecture: 'x86_64' | 'aarch64';
    };
    image: {
        provider: string;
        reference: string;
        digest: string | null;
    };
    resources: {
        cpu_millis: number;
        memory_bytes: string;
        disk_bytes: string;
        persistent_volume_bytes: string;
    };
    toolchains: VersionPin[];
    package_managers: {
        name: string;
        version: string;
        locks: FilePin[];
    }[];
    native_agents: VersionPin[];
    connectors: VersionPin[];
    supervisor: VersionPin;
    hyperfide: {
        version: string;
    };
    system_packages: VersionPin[];
    repositories: {
        id: string;
        url: string;
        commit: string;
        submodules: {
            path: string;
            commit: string;
        }[];
        lfs: boolean;
    }[];
    recipe: FilePin;
    generated_inputs: FilePin[];
    build_config: FilePin[];
    caches: {
        name: string;
        trust_scope: string;
        input_digest: string;
    }[];
    required_capabilities: string[];
    network: {
        routes: string[];
        registries: string[];
    };
    credential_references: string[];
    policy: {
        max_process_lifetime_seconds: number;
        expires_at: string;
        rebuild_on: string[];
    };
    preparation_evidence: FilePin[];
}
export interface InventoryEntry {
    path: string;
    mode: number;
    size: string;
    digest: string;
}
export interface DirectoryEntry {
    path: string;
    mode: number;
}
interface ScanDeclaration {
    policy_version: 1;
    canary_counts: {
        secret: number;
        identity: number;
        lease: number;
    };
    checks: string[];
}
export interface SymlinkEntry {
    path: string;
    target: string;
    digest: string;
}
export interface HardlinkGroup {
    paths: string[];
}
export interface PreparationManifest {
    schema_version: 1 | 2;
    profile: EnvironmentProfile;
    files: InventoryEntry[];
    directories: DirectoryEntry[];
    symlinks?: SymlinkEntry[];
    hardlinks?: HardlinkGroup[];
    scan: ScanDeclaration;
    digest: string;
}
type InventoryContext = Pick<ComponentContext, 'env' | 'signal'>;
export declare function validateProfile(input: unknown): EnvironmentProfile;
export declare function canonicalJSON(value: unknown): string;
export declare function createManifest(input: unknown, context: InventoryContext): Promise<PreparationManifest>;
/** Re-scan the trusted candidate and compare canonical schema v1/v2 content, including link topology.
 * Expired historical profiles may verify; integrity grants no current reuse or execution authority. */
export declare function verifyManifest(input: unknown, context: InventoryContext): Promise<{
    valid: true;
    digest: string;
    file_count: number;
}>;
export declare function createComponent(_context: InventoryContext): Component;
export declare function validateManifestMetadata(value: unknown): PreparationManifest;
/** This compares pinned preparation inputs. It grants neither readiness nor ownership.
 * Actual tool/resource/network/credential probes must still pass on the target boot. */
export declare function compareEnvironmentCompatibility(source: unknown, target: unknown): Promise<{
    compatible: boolean;
    evidence_digest: string;
    source_digest: string;
    target_digest: string;
    scope: 'pinned-preparation-compatibility';
}>;
export {};
