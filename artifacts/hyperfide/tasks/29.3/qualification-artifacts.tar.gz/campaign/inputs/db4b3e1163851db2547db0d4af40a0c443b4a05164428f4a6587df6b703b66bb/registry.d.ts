import type { Component, ComponentContext } from '../components/registry.js';
import type { AuthorityTransaction } from '../transport/protocol.js';
export interface FindingScope {
    organisation_id: string;
    run_id: string;
    repository_id?: string;
    source_object_id?: string;
}
export interface FindingPrincipal {
    credential_id: string;
    actor_id: string;
    organisation_id: string;
    run_id: string;
    deployment_epoch: string;
    role: string;
    allowed_actions: readonly string[];
    expires_at: string;
}
export interface FindingInvocation {
    principal: FindingPrincipal;
    operation: unknown;
    payload: {
        action: string;
        run_id: string;
    };
    guard(tx: AuthorityTransaction): Promise<void>;
}
export type FindingDatabase = AuthorityTransaction;
export interface FindingTransaction {
    tx: FindingDatabase;
    scope: FindingScope;
    principal: FindingPrincipal;
    context: ComponentContext;
}
export declare function fail(code: string, message: string): never;
export declare function record(value: unknown): Record<string, unknown>;
export declare function fields(value: Record<string, unknown>, required: string[], optional?: string[]): void;
export declare function text(value: unknown, label: string, max?: number): string;
export declare function uuid(value: unknown): string;
export declare function decimal(value: unknown): string;
export declare function digestValue(value: unknown): string;
export declare function oid(value: unknown): string;
export declare function ids(value: unknown, max?: number): string[];
export declare function canonical(value: unknown): string;
export declare function digest(value: unknown): string;
export declare function invocation(context: ComponentContext, action: string): Promise<FindingInvocation>;
export declare function readiness(tx: FindingDatabase): Promise<void>;
/** Delegates freshness to the single storage-owned SERIALIZABLE generation fence. */
export declare function semanticDisposition(tx: FindingDatabase, scope: FindingScope, write?: boolean): Promise<void>;
export declare function withFindingTransaction<T>(context: ComponentContext, action: string, fn: (value: FindingTransaction) => Promise<T>): Promise<T>;
export declare function admin(value: FindingTransaction): Promise<void>;
export declare function manager(value: FindingTransaction, packageId: string): Promise<void>;
export declare function emit(tx: FindingDatabase, scope: FindingScope, findingId: string, version: string, event: string, payload: Record<string, unknown>): Promise<void>;
export declare function finding(tx: FindingDatabase, scope: FindingScope, id: string, lock?: boolean): Promise<Record<string, any>>;
export declare function admittedEvidence(tx: FindingDatabase, scope: FindingScope, evidenceIds: string[], repositoryId?: string, sourceObjectId?: string): Promise<void>;
export declare function acceptedResolution(tx: FindingDatabase, scope: FindingScope, taskId: string, repositoryId: string, input: unknown): Promise<Record<string, unknown>>;
export declare function revalidateResolution(tx: FindingDatabase, scope: FindingScope, f: Record<string, any>): Promise<void>;
export declare function reportFinding(value: FindingTransaction, input: unknown): Promise<Record<string, unknown>>;
export declare function readFindingContext(tx: FindingDatabase, scope: FindingScope, input?: unknown): Promise<Record<string, unknown>>;
export declare function inspectBlockingFindings(tx: FindingDatabase, scope: FindingScope): Promise<{
    clear: boolean;
    blockers: Record<string, unknown>[];
}>;
export declare function createComponent(_context: ComponentContext): Component;
