import type { Component, ComponentContext } from '../components/registry.js';
import type { QuerySession } from '../storage/transactions.js';
type Invocation = {
    principal: {
        organisation_id: string;
        run_id: string;
        actor_id: string;
        deployment_epoch: string;
        role: string;
    };
    operation: {
        operation_id: string;
    };
    guard: (tx: QuerySession) => Promise<void>;
    signal: AbortSignal;
};
type Context = ComponentContext & {
    invocation?: Invocation;
};
export declare class ArtifactRetention {
    private readonly context;
    constructor(context: Context);
    private actor;
    private scope;
    private policy;
    private transaction;
    private artifact;
    private blockers;
    private otherReferences;
    private result;
    private inspect;
    private reference;
    private hold;
    private release;
    private changePolicy;
    private advance;
    private execute;
    private collect;
    private reconcile;
    /** Unresolved destruction stays listed after restart; an empty bounded page is the only clean bill. */
    private debt;
    invoke(action: string, input: unknown): Promise<unknown>;
}
export declare function createComponent(_context: ComponentContext): Component;
export {};
