export type EvidenceClass = 'SOURCE' | 'SESSION' | 'ENVIRONMENT';
export type AdoptionMode = 'SOURCE_ONLY' | 'NATIVE_RESUME';
export interface RecipeOutcome {
    readonly evidence_class: EvidenceClass;
    readonly verdict: 'COMPATIBLE' | 'REBUILD_REQUIRED' | 'FRESH_SESSION';
    readonly rule: string;
    readonly source: string | null;
    readonly target: string | null;
}
export interface CheckpointLineage {
    id: string;
    artifact_id: string;
    attempt_id: string;
    attempt_generation: string;
    repository_id: string;
    source_object_id: string;
    input_packet_digest: string;
    support_level: string;
    agent_session_id: string | null;
    digest: string;
    status: string;
    registration_operation_id: string | null;
    preparation_digest: string | null;
    artifact_content_digest: string | null;
    source_metadata_digest: string | null;
    source_compute_authority: string;
    source_packet_digest: string;
    source_task_id: string;
    source_expired: boolean;
}
export interface TargetIdentity {
    task_id: string;
    attempt_id: string;
    attempt_generation: string;
}
export interface TargetExecution {
    input_packet_digest: string;
    preparation_digest: string;
}
export interface NativeResumeRequest {
    session_id: string;
    native_session_id: string;
    configuration_digest: string;
    source_manifest_digest: string;
}
export declare const CHECKPOINT_RECIPES: Readonly<Record<EvidenceClass, string>>;
/** Registration provenance, byte identity and lineage of the historical source. */
export declare function sourceRecipe(source: CheckpointLineage, target: TargetIdentity, expectedArtifactDigest: string): RecipeOutcome;
/** The committed source must still be the one validated before external reads. */
export declare function sourceUnchanged(initial: CheckpointLineage, current: CheckpointLineage): void;
/** Pre-check before asking the session service; a mismatch is refused, never downgraded. */
export declare function sessionPrecheck(source: CheckpointLineage, mode: AdoptionMode, native: NativeResumeRequest | null, expectedPacketDigest: string): void;
export declare function sessionRecipe(source: CheckpointLineage, mode: AdoptionMode, resume: Record<string, unknown> | null): RecipeOutcome;
export declare function environmentRecipe(source: CheckpointLineage, mode: AdoptionMode, target: TargetExecution, expected: TargetExecution): RecipeOutcome;
