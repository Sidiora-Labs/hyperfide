import type { Component, ComponentContext } from '../components/registry.js';
export interface IntentInput {
    request_id: string;
    idempotency_key: string;
    expected_leader_generation: string;
    kind: 'INTENT' | 'CRITERIA' | 'PROGRAMME_CHANGE' | 'UNRESOLVED_INTENT' | 'ROUTINE';
    package_id: string | null;
    package_generation: string | null;
    payload: Record<string, unknown>;
}
export declare function validateIntent(input: unknown): IntentInput;
export declare function createComponent(_context: ComponentContext): Component;
