import type { Component, ComponentContext } from '../../components/registry.js';
export interface BlaxelLifetimePolicy {
    schema_version: 1;
    run_seconds: number;
    checkpoint_lead_seconds: number;
    termination_grace_seconds: number;
    api_wait_seconds: number;
    process: {
        keep_alive: true;
        timeout_seconds: 0;
    };
    expiration_policies: Array<{
        type: 'ttl-idle' | 'ttl-max-age' | 'date';
        value: string;
        action: 'delete';
    }>;
    runtime_ttl: string | null;
    runtime_expires_at: string | null;
}
export interface LifetimeObservation {
    created_at: string;
    observed_at: string;
    last_resume_or_suspend_at: string | null;
    expires_in_seconds: number | null;
    account_max_age_seconds: number | null;
    account_limits_qualified: boolean;
    process: {
        keep_alive: boolean;
        timeout_seconds: number | null;
        started_at: string;
        state: 'RUNNING' | 'EXITED' | 'UNKNOWN';
    };
}
export declare function durationSeconds(v: unknown): number;
export declare function validateBlaxelLifetimePolicy(value: unknown): BlaxelLifetimePolicy;
export declare function blaxelProcessLifetimeOptions(policy: BlaxelLifetimePolicy): {
    keepAlive: true;
    timeout: 0;
    waitForCompletion: false;
    restartOnFailure: false;
    maxRestarts: 0;
};
export declare function blaxelSandboxLifetimeOptions(policy: BlaxelLifetimePolicy): {
    lifecycle: {
        expirationPolicies: BlaxelLifetimePolicy['expiration_policies'];
    };
    runtime: {
        terminationGracePeriodSeconds: number;
        ttl?: string;
        expires?: string;
    };
};
export declare function assessBlaxelLifetime(value: unknown): unknown;
export declare function boundedBlaxelRead<T>(read: (signal: AbortSignal) => Promise<T>, signal: AbortSignal, deadline: number): Promise<T>;
export declare function observeBlaxelLifetime(value: unknown, ctx: ComponentContext): Promise<unknown>;
export declare function createComponent(_ctx: ComponentContext): Component;
