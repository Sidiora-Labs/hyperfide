import type { Component, ComponentContext } from '../components/registry.js';
import { type RecordValue } from '../docs/closure.js';
export interface ReleaseTask {
    id: string;
    reqs: string[];
    acceptance_ids: string[];
    requires: string[];
    wave: number;
}
export interface ClauseMapping {
    id: string;
    task_ids: string[];
    acceptance_ids: string[];
    chapters: string[];
}
export interface SourcePin {
    path: string;
    sha256: string;
    size: number;
}
export interface ReviewStates {
    original_approval: {
        source: string;
        implementation_authorized: boolean;
        task_status: Record<string, string>;
        grants_product_qualification: false;
    };
    pack_review: {
        source: string;
        sha256: string;
        scope: 'DESIGN_AND_AUTHORING_ONLY';
        grants_implementation_approval: false;
        grants_product_qualification: false;
    };
    product_qualification: {
        source: string;
        case_qualification: Record<string, string>;
        qualified_case_ids: string[];
        unresolved_case_ids: string[];
    };
}
export interface ReleaseContract {
    clauses: string[];
    tasks: ReleaseTask[];
    cases: Record<string, {
        full_assertion_ids: string[];
    }>;
    native_case_requirements: Record<string, string[]>;
    mappings: ClauseMapping[];
    source_pins: SourcePin[];
    review_states: ReviewStates;
    contract_digest: string;
}
export declare function parseReleasePack(value: unknown): ReleaseContract;
export declare function validateTraceability(contract: ReleaseContract, mappings?: ClauseMapping[]): RecordValue;
export interface PackSource {
    root: string;
    origin: 'IMPLEMENTED_REVISION' | 'CONTROLLED';
}
export declare function packSource(env?: NodeJS.ProcessEnv): PackSource;
type LoadedContract = {
    contract: ReleaseContract;
    records: {
        path: string;
        sha256: string;
        size: number;
        content_base64: string;
    }[];
};
export declare function loadReleaseContract(source?: PackSource): Promise<LoadedContract>;
export declare function snapshotReleaseContract(source?: PackSource): Promise<LoadedContract>;
export declare function traceabilityReceipt(input: unknown): Promise<RecordValue>;
export declare function archiveTraceability(input: unknown, context: ComponentContext): Promise<RecordValue>;
export declare function checkReleasePack(input: unknown): Promise<RecordValue>;
export declare function createComponent(_context: ComponentContext): Component;
export {};
