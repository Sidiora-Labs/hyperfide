import fs from 'node:fs/promises';
import { randomUUID, timingSafeEqual } from 'node:crypto';
import { assertPrimaryTransaction } from '../storage/transactions.js';
import { object } from '../policy/programme.js';
import { assertInvocation, authenticatedInvocation, base64, canonicalOrigin, decodeEnrollment, decodeInvoke, decimal, enrollmentSecret, exact, fail, frozen, hash, NAME, proof, strictJSON, uuid, verifyProof } from '../transport/protocol.js';
const agentRoles = ['LEADER', 'FEATURE_MANAGER', 'WORKER', 'COMMIT_WATCHER', 'ISSUE_WATCHER', 'VERIFIER', 'INTEGRATOR', 'INDEXER'];
const allRoles = [...agentRoles, 'OPERATOR', 'COORDINATOR', 'PROVISIONER', 'DISPATCH', 'RUNNER', 'GITHUB_MIRROR'];
export function invocationOf(ctx) { const i = ctx.invocation; assertInvocation(i); return i; }
export function gatewayOf(ctx) { const g = ctx.resources?.gateway; if (!g || typeof g.withPrimaryTransaction !== 'function')
    fail('RESOURCE_REQUIRED', 'Initialized primary transaction gateway required'); return g; }
export function isIdentityAuthority(v) { return object(v) && typeof v.guard === 'function' && typeof v.authenticate === 'function' && typeof v.enroll === 'function' && typeof v.authorize === 'function'; }
function allowed(v) { if (!Array.isArray(v) || !v.length || v.length > 256 || v.some(x => typeof x !== 'string' || !NAME.test(x)) || new Set(v).size !== v.length)
    fail('INVALID_REQUEST', 'Unique action capabilities required'); return v; }
function principal(row) { return frozen({ credential_id: row.credential_id, organisation_id: row.organisation_id, run_id: row.run_id, actor_id: row.actor_id, role: row.role, credential_version: String(row.credential_version), deployment_epoch: row.deployment_epoch, sandbox_id: row.sandbox_id, boot_id: row.boot_id, boot_generation: row.boot_generation === null ? null : String(row.boot_generation), attempt_id: row.attempt_id, attempt_generation: row.attempt_generation === null ? null : String(row.attempt_generation), allowed_actions: [...row.allowed_actions], expires_at: new Date(row.expires_at).toISOString() }); }
async function assertCredentialIdentity(tx, p, strictCompute, action, continuation = false) {
    assertPrimaryTransaction(tx);
    let attemptExpiry;
    const r = (await tx.query('SELECT p.*,r.authority_epoch,r.state AS run_state,clock_timestamp() AS db_now FROM hyperfide.identity_principals p JOIN hyperfide.runs r ON r.organisation_id=p.organisation_id AND r.id=p.run_id WHERE p.credential_id=$1 FOR SHARE OF p,r', [p.credential_id])).rows[0];
    // Match the expiry refusal below regardless of which row-lock wait crosses the deadline.
    if (r && new Date(r.expires_at).getTime() <= new Date(r.db_now).getTime())
        fail('AUTH_EXPIRED', 'Credential expired');
    if (!r || r.state !== 'ACTIVE' || String(r.credential_version) !== p.credential_version || r.organisation_id !== p.organisation_id || r.run_id !== p.run_id || r.actor_id !== p.actor_id || r.role !== p.role || r.deployment_epoch !== p.deployment_epoch || r.authority_epoch !== p.deployment_epoch || JSON.stringify(r.allowed_actions) !== JSON.stringify(p.allowed_actions) || new Date(r.expires_at).toISOString() !== p.expires_at || r.sandbox_id !== p.sandbox_id || r.boot_id !== p.boot_id || (r.boot_generation === null ? null : String(r.boot_generation)) !== p.boot_generation || r.attempt_id !== p.attempt_id || (r.attempt_generation === null ? null : String(r.attempt_generation)) !== p.attempt_generation)
        fail('AUTH_REVOKED', 'Credential or run authority is not current');
    if ((r.role === 'WORKER') !== (r.attempt_id !== null))
        fail('AUTH_STALE_ATTEMPT', 'Only a coding worker may carry implementation attempt authority');
    const closing = ['DRAINING', 'PAUSING', 'PAUSED', 'STOPPING', 'STOPPED', 'CANCELLING', 'CANCELLED', 'DRAINED', 'FAILED', 'SUCCEEDED'];
    const cleanup = ['recovery.control.reconstruct', 'recovery.worker.inventory', 'recovery.stop.request', 'recovery.stop.reconcile', 'recovery.stop.finalize', 'recovery.drill.describe', 'recovery.drill.plan', 'recovery.drill.inspect', 'recovery.drill.execute', 'recovery.drill.reconcile', 'recovery.control.resume', 'integration.publication.reconcile', 'review.coverage.inspect', 'review.reproduction.inspect'];
    if (strictCompute && closing.includes(r.run_state) && !(continuation && r.run_state === 'DRAINING') && !(action && ['OPERATOR', 'COORDINATOR', 'LEADER'].includes(p.role) && cleanup.includes(action)) && !(action === 'integration.publication.reconcile' && p.role === 'INTEGRATOR') && !(action === 'identity.principal.renew' && ['COORDINATOR', 'PROVISIONER', 'DISPATCH'].includes(p.role) && ['PAUSED', 'STOPPING', 'PAUSING', 'DRAINING'].includes(r.run_state)) && !(action && ['OPERATOR', 'COORDINATOR', 'LEADER'].includes(p.role) && ((['cutover.describe', 'cutover.inspect', 'cutover.recovery'].includes(action) && ['PAUSED', 'DRAINED', 'STOPPED', 'CANCELLED'].includes(r.run_state)) || (['cutover.prepare', 'cutover.validate'].includes(action) && ['PAUSED', 'DRAINED', 'STOPPED'].includes(r.run_state)))))
        fail('AUTH_RUN_CLOSED', 'Run state denies this operation');
    if (r.sandbox_id !== null) {
        const b = (await tx.query('SELECT s.boot_generation,s.observed_state,b.boot_id FROM hyperfide.sandboxes s JOIN hyperfide.sandbox_boots b ON b.organisation_id=s.organisation_id AND b.sandbox_id=s.id AND b.boot_generation=s.boot_generation WHERE s.organisation_id=$1 AND s.id=$2 FOR SHARE OF s,b', [r.organisation_id, r.sandbox_id])).rows[0];
        if (!b || String(b.boot_generation) !== p.boot_generation || b.boot_id !== p.boot_id || strictCompute && b.observed_state !== 'RUNNING')
            fail('AUTH_STALE_BOOT', 'Sandbox boot is not current');
    }
    if (agentRoles.includes(r.role)) {
        const a = (await tx.query('SELECT role,state,attempt_id,sandbox_id,sandbox_boot_generation,native_session_id FROM hyperfide.agent_sessions WHERE organisation_id=$1 AND run_id=$2 AND id=$3 FOR SHARE', [r.organisation_id, r.run_id, r.actor_id])).rows[0];
        if (!a || typeof a.native_session_id !== 'string' || !a.native_session_id || a.role !== r.role || !['REGISTERED', 'RUNNING', 'DISCONNECTED'].includes(a.state) || a.attempt_id !== r.attempt_id || a.sandbox_id !== p.sandbox_id || (a.sandbox_boot_generation === null ? null : String(a.sandbox_boot_generation)) !== p.boot_generation)
            fail('AUTH_STALE_SESSION', 'Registered session is not current');
    }
    if (r.attempt_id !== null) {
        const a = (await tx.query('SELECT *,clock_timestamp() AS db_now FROM hyperfide.attempts WHERE organisation_id=$1 AND run_id=$2 AND id=$3 FOR SHARE', [r.organisation_id, r.run_id, r.attempt_id])).rows[0];
        if (!a || r.role !== 'WORKER' || a.kind !== 'IMPLEMENTATION' || strictCompute && a.compute_authority !== 'CURRENT' || String(a.generation) !== p.attempt_generation || a.authority_epoch !== p.deployment_epoch || a.sandbox_id !== p.sandbox_id || String(a.sandbox_boot_generation) !== p.boot_generation || strictCompute && new Date(a.lease_expires_at).getTime() <= new Date(a.db_now).getTime())
            fail('AUTH_STALE_ATTEMPT', 'Attempt authority is not current');
        attemptExpiry = new Date(a.lease_expires_at).getTime();
    }
    const clock = (await tx.query('SELECT clock_timestamp() AS db_now')).rows[0].db_now;
    if (new Date(r.expires_at).getTime() <= new Date(clock).getTime() || strictCompute && attemptExpiry !== undefined && attemptExpiry <= new Date(clock).getTime())
        fail('AUTH_EXPIRED', 'Authority expired while waiting for row locks');
}
export async function assertCurrentPrincipal(tx, p, authority) { assertPrimaryTransaction(tx); if (!authority || typeof authority.assertCurrent !== 'function')
    fail('RESOURCE_REQUIRED', 'Actual deployment epoch authority required'); await assertCredentialIdentity(tx, p, true); await authority.assertCurrent(tx, { organisation_id: p.organisation_id, run_id: p.run_id, authority_epoch: p.deployment_epoch }); await assertCredentialIdentity(tx, p, true); }
// Trusted domain code supplies the actual durable job/attempt validator; this is never wire data.
export function continuationInvocation(i, validatePersistedAdmission) { assertInvocation(i); if (typeof validatePersistedAdmission !== 'function')
    fail('AUTH_CONTINUATION_REQUIRED', 'Trusted persisted admission validator required'); return authenticatedInvocation({ ...i, guard: tx => i.continuationGuard(tx, validatePersistedAdmission) }); }
export async function identityTransaction(ctx, operation) { const i = invocationOf(ctx); return gatewayOf(ctx).withPrimaryTransaction({ timeoutMs: 5000, maxRetries: 2, signal: i.signal, guard: tx => i.guard(tx) }, tx => operation(tx, i)); }
export async function recorded(tx, scope, name, op, action) {
    await tx.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [scope + ':' + name + ':' + op.idempotency_key]);
    const r = (await tx.query('SELECT operation_id,payload_digest,response FROM hyperfide.identity_operation_results WHERE scope_id=$1 AND operation=$2 AND idempotency_key=$3', [scope, name, op.idempotency_key])).rows[0];
    if (r) {
        if (r.operation_id !== op.operation_id || r.payload_digest !== op.payload_digest)
            fail('IDEMPOTENCY_CONFLICT', 'Key reused with different operation bytes');
        return r.response;
    }
    const result = await action();
    await tx.query('INSERT INTO hyperfide.identity_operation_results(scope_id,operation,idempotency_key,operation_id,payload_digest,response) VALUES($1,$2,$3,$4,$5,$6)', [scope, name, op.idempotency_key, op.operation_id, op.payload_digest, JSON.stringify(result)]);
    return result;
}
async function ready(g) { const bytes = await fs.readFile(new URL('../../migrations/0014-enrollment.sql', import.meta.url)); await g.withPrimaryTransaction({ timeoutMs: 5000 }, async (tx) => { const r = (await tx.query('SELECT name,checksum FROM hyperfide.schema_migrations WHERE version=14')).rows[0]; if (!r || r.name !== '0014-enrollment' || r.checksum !== hash(bytes))
    fail('IDENTITY_SCHEMA_REQUIRED', 'Apply the trusted identity migration before service startup'); for (const n of ['identity_principals', 'identity_provider_bindings', 'identity_enrollment_grants', 'identity_request_nonces', 'identity_enrollment_nonces', 'identity_operation_results', 'identity_credential_references', 'identity_credential_attachments', 'identity_runner_status'])
    if (!(await tx.query('SELECT to_regclass($1) AS name', ['hyperfide.' + n])).rows[0]?.name)
        fail('IDENTITY_SCHEMA_REQUIRED', 'Identity schema incomplete'); }); }
async function configOf(ctx) { const file = ctx.env.HF_IDENTITY_CONFIG_FILE; if (!file)
    fail('IDENTITY_CONFIG_REQUIRED', 'Trusted identity configuration required'); const st = await fs.lstat(file); if (!st.isFile() || st.isSymbolicLink() || st.size > 1048576)
    fail('IDENTITY_CONFIG_INVALID', 'Bounded regular configuration required'); const c = strictJSON(await fs.readFile(file)); exact(c, ['schema_version', 'origin', 'clock_skew_seconds', 'grant_ttl_seconds', 'credential_ttl_seconds', 'principals']); if (c.schema_version !== 1 || !Number.isInteger(c.clock_skew_seconds) || Number(c.clock_skew_seconds) < 1 || Number(c.clock_skew_seconds) > 120 || !Number.isInteger(c.grant_ttl_seconds) || Number(c.grant_ttl_seconds) < 1 || Number(c.grant_ttl_seconds) > 900 || !Number.isInteger(c.credential_ttl_seconds) || Number(c.credential_ttl_seconds) < 60 || Number(c.credential_ttl_seconds) > 86400 || !Array.isArray(c.principals) || c.principals.length > 64)
    fail('IDENTITY_CONFIG_INVALID', 'Invalid identity limits'); return { origin: canonicalOrigin(c.origin), clock_skew_seconds: Number(c.clock_skew_seconds), grant_ttl_seconds: Number(c.grant_ttl_seconds), credential_ttl_seconds: Number(c.credential_ttl_seconds), principals: c.principals }; }
async function seed(g, c, authority) { for (const v of c.principals) {
    exact(v, ['credential_id', 'organisation_id', 'run_id', 'actor_id', 'role', 'public_key_b64', 'deployment_epoch', 'allowed_actions', 'expires_at']);
    if (!uuid(v.credential_id) || !uuid(v.organisation_id) || !uuid(v.run_id) || !uuid(v.actor_id) || !uuid(v.deployment_epoch) || typeof v.role !== 'string' || !allRoles.includes(v.role) || ['RUNNER', 'WORKER'].includes(v.role) || typeof v.expires_at !== 'string' || !Number.isFinite(Date.parse(v.expires_at)))
        fail('IDENTITY_CONFIG_INVALID', 'Invalid bootstrap principal');
    base64(v.public_key_b64, 32);
    const a = allowed(v.allowed_actions);
    await g.withPrimaryTransaction({ timeoutMs: 5000 }, async (tx) => { const run = (await tx.query('SELECT authority_epoch FROM hyperfide.runs WHERE organisation_id=$1 AND id=$2 FOR SHARE', [v.organisation_id, v.run_id])).rows[0]; if (!run || run.authority_epoch !== v.deployment_epoch)
        fail('IDENTITY_CONFIG_INVALID', 'Bootstrap epoch mismatch'); const p = (await tx.query('SELECT * FROM hyperfide.identity_principals WHERE credential_id=$1', [v.credential_id])).rows[0]; if (!p || p.state !== 'ACTIVE' || p.organisation_id !== v.organisation_id || p.run_id !== v.run_id || p.actor_id !== v.actor_id || p.role !== v.role || p.public_key_b64 !== v.public_key_b64 || p.deployment_epoch !== v.deployment_epoch || JSON.stringify(p.allowed_actions) !== JSON.stringify(a))
        fail('IDENTITY_BOOTSTRAP_CONFLICT', 'Bootstrap cannot overwrite or reactivate identity'); assertPrimaryTransaction(tx); await assertCredentialIdentity(tx, principal(p), false); await authority.assertCurrent(tx, { organisation_id: v.organisation_id, run_id: v.run_id, authority_epoch: v.deployment_epoch }); });
} }
function role(i, values) { if (!values.includes(i.principal.role))
    fail('ROLE_DENIED', 'Principal role is not permitted'); }
function result(p) { return { protocol_version: 1, credential_id: p.credential_id, actor_id: p.actor_id, run_id: p.run_id, role: p.role, sandbox_id: p.sandbox_id, boot_generation: p.boot_generation === null ? null : String(p.boot_generation), boot_id: p.boot_id, expires_at: new Date(p.expires_at).toISOString() }; }
export async function createComponent(ctx) {
    const g = gatewayOf(ctx), c = await configOf(ctx), globalAuthority = ctx.dependencies.require('4.4', 'storage.authority.v1', (v) => object(v) && typeof v.assertCurrent === 'function');
    await ready(g);
    await seed(g, c, globalAuthority);
    let mainVerifier, registrationsSealed = false;
    const installMainSessionVerifier = (verifier) => {
        if (registrationsSealed)
            fail('IDENTITY_REGISTRY_SEALED', 'Trusted identity registrations are sealed before listening');
        if (!object(verifier) || typeof verifier.verify !== 'function' || mainVerifier !== undefined)
            fail('MAIN_VERIFIER_CONFLICT', 'Exactly one trusted MAIN session verifier may register');
        mainVerifier = Object.freeze({ verify: verifier.verify.bind(verifier) });
    };
    const sealTrustedRegistrations = () => { registrationsSealed = true; };
    const assertBoundIdentity = async (tx, p, strict, action, continuation = false) => { assertPrimaryTransaction(tx); await assertCredentialIdentity(tx, p, strict, action, continuation); await globalAuthority.assertCurrent(tx, { organisation_id: p.organisation_id, run_id: p.run_id, authority_epoch: p.deployment_epoch }); await assertCredentialIdentity(tx, p, strict, action, continuation); };
    const assertBoundPrincipal = (tx, p) => assertCurrentPrincipal(tx, p, globalAuthority);
    const authorize = async (i) => { const p = i.principal, b = i.payload; if (p.run_id !== b.run_id || !p.allowed_actions.includes(b.action))
        fail('AUTH_SCOPE_DENIED', 'Operation outside granted run/action'); if (p.attempt_id !== null && (!b.authority || b.authority.attempt_id !== p.attempt_id || b.authority.attempt_generation !== p.attempt_generation || b.authority.sandbox_id !== p.sandbox_id || b.authority.boot_generation !== p.boot_generation || b.authority.deployment_epoch !== p.deployment_epoch))
        fail('AUTH_SCOPE_DENIED', 'Attempt authority mismatch'); if (b.authority && b.authority.deployment_epoch !== p.deployment_epoch)
        fail('AUTH_SCOPE_DENIED', 'Authority epoch mismatch'); };
    const authenticate = async (body, headers, signal) => { const decoded = decodeInvoke(body), item = proof(headers); const p = await g.withPrimaryTransaction({ timeoutMs: 5000, signal }, async (tx) => { const r = (await tx.query('SELECT *,clock_timestamp() AS db_now FROM hyperfide.identity_principals WHERE credential_id=$1 FOR SHARE', [item.id])).rows[0]; if (!r)
        fail('AUTH_INVALID', 'Credential unavailable'); verifyProof(r.public_key_b64, item, c.origin, '/v1/invoke', body); if (Math.abs(new Date(r.db_now).getTime() / 1000 - Number(item.time)) > c.clock_skew_seconds)
        fail('AUTH_EXPIRED', 'Request proof outside time window'); const p = principal(r); await assertBoundIdentity(tx, p, false); const proofNow = (await tx.query('SELECT clock_timestamp() AS db_now')).rows[0].db_now; if (Math.abs(new Date(proofNow).getTime() / 1000 - Number(item.time)) > c.clock_skew_seconds)
        fail('AUTH_EXPIRED', 'Request proof expired while waiting for identity locks'); if ((await tx.query('INSERT INTO hyperfide.identity_request_nonces(credential_id,nonce) VALUES($1,$2) ON CONFLICT DO NOTHING', [item.id, item.nonce])).rowCount !== 1)
        fail('AUTH_REPLAY', 'Nonce already consumed'); return p; }); const i = authenticatedInvocation({ principal: p, operation: decoded.operation, payload: decoded.payload, signal, guard: (tx) => assertBoundIdentity(tx, p, true, decoded.payload.action), identityGuard: (tx) => assertBoundIdentity(tx, p, false), continuationGuard: async (tx, validatePersistedAdmission) => { if (typeof validatePersistedAdmission !== 'function')
            fail('AUTH_CONTINUATION_REQUIRED', 'Trusted persisted admission validator required'); await assertBoundIdentity(tx, p, true, decoded.payload.action, true); await validatePersistedAdmission(tx, i); await assertBoundIdentity(tx, p, true, decoded.payload.action, true); } }); await authorize(i); return i; };
    const enroll = async (body, headers, signal) => {
        const d = decodeEnrollment(body), item = proof(headers, true), secret = enrollmentSecret(headers), b = d.payload;
        verifyProof(b.public_key_b64, item, c.origin, '/v1/enroll', body);
        await g.withPrimaryTransaction({ timeoutMs: 5000, signal }, async (tx) => { const r = (await tx.query('SELECT verifier,clock_timestamp() AS db_now FROM hyperfide.identity_enrollment_grants WHERE id=$1 FOR SHARE', [item.id])).rows[0], a = Buffer.from(hash(secret)), v = Buffer.from(String(r?.verifier ?? '')); if (!r || a.length !== v.length || !timingSafeEqual(a, v))
            fail('AUTH_INVALID', 'Enrollment grant unavailable'); if (Math.abs(new Date(r.db_now).getTime() / 1000 - Number(item.time)) > c.clock_skew_seconds)
            fail('AUTH_EXPIRED', 'Enrollment proof outside time window'); if ((await tx.query('INSERT INTO hyperfide.identity_enrollment_nonces(grant_id,nonce) VALUES($1,$2) ON CONFLICT DO NOTHING', [item.id, item.nonce])).rowCount !== 1)
            fail('AUTH_REPLAY', 'Enrollment nonce consumed'); });
        const outcome = await g.withPrimaryTransaction({ timeoutMs: 5000, maxRetries: 2, signal }, async (tx) => {
            assertPrimaryTransaction(tx);
            const grant = (await tx.query('SELECT g.*,r.authority_epoch,r.state AS run_state,clock_timestamp() AS db_now FROM hyperfide.identity_enrollment_grants g JOIN hyperfide.runs r ON r.organisation_id=g.organisation_id AND r.id=g.run_id WHERE g.id=$1 FOR UPDATE OF g FOR SHARE OF r', [item.id])).rows[0];
            if (!grant)
                fail('AUTH_INVALID', 'Enrollment grant unavailable');
            if (grant.run_state !== 'RUNNING')
                fail('AUTH_RUN_CLOSED', 'Enrollment requires a running run');
            await globalAuthority.assertCurrent(tx, { organisation_id: grant.organisation_id, run_id: grant.run_id, authority_epoch: grant.deployment_epoch });
            if (grant.state === 'CONSUMED') {
                const p = (await tx.query('SELECT * FROM hyperfide.identity_principals WHERE credential_id=$1 FOR UPDATE', [grant.credential_id])).rows[0];
                if (!p || p.public_key_b64 !== b.public_key_b64 || grant.boot_id !== b.boot_id || grant.sandbox_id !== b.sandbox_id || String(grant.boot_generation) !== b.boot_generation || grant.run_id !== b.run_id || grant.provisioning_intent_id !== b.provisioning_intent_id) {
                    await tx.query("UPDATE hyperfide.identity_enrollment_grants SET state='QUARANTINED' WHERE id=$1", [item.id]);
                    await tx.query("UPDATE hyperfide.identity_principals SET state='QUARANTINED',credential_version=credential_version+1 WHERE organisation_id=$1 AND sandbox_id=$2 AND boot_generation=$3 AND state='ACTIVE'", [grant.organisation_id, grant.sandbox_id, grant.boot_generation]);
                    return { quarantined: true };
                }
                await assertBoundPrincipal(tx, principal(p));
                return recorded(tx, item.id, 'identity.enroll', d.operation, async () => result(p));
            }
            if (grant.state !== 'ISSUED' || new Date(grant.expires_at).getTime() <= new Date(grant.db_now).getTime() || grant.deployment_epoch !== grant.authority_epoch)
                fail('AUTH_EXPIRED', 'Enrollment grant not current');
            if (grant.run_id !== b.run_id || grant.provisioning_intent_id !== b.provisioning_intent_id || grant.sandbox_id !== b.sandbox_id || String(grant.boot_generation) !== b.boot_generation || grant.boot_id !== b.boot_id)
                fail('AUTH_SCOPE_DENIED', 'Enrollment binding mismatch');
            const binding = (await tx.query('SELECT b.*,s.boot_generation AS current_boot,s.state_version AS current_version,s.observed_state FROM hyperfide.identity_provider_bindings b JOIN hyperfide.sandboxes s ON s.organisation_id=b.organisation_id AND s.id=b.sandbox_id WHERE b.organisation_id=$1 AND b.run_id=$2 AND b.provisioning_intent_id=$3 FOR SHARE OF b,s', [grant.organisation_id, grant.run_id, grant.provisioning_intent_id])).rows[0];
            if (!binding || String(binding.current_boot) !== b.boot_generation || String(binding.current_version) !== String(binding.sandbox_version) || binding.observed_state !== 'RUNNING')
                fail('PROVIDER_BINDING_STALE', 'Trusted provider binding missing or stale');
            const enrollmentNow = new Date((await tx.query('SELECT clock_timestamp() AS db_now')).rows[0].db_now).getTime();
            if (new Date(grant.expires_at).getTime() <= enrollmentNow || new Date(grant.credential_expires_at).getTime() <= enrollmentNow || Math.abs(enrollmentNow / 1000 - Number(item.time)) > c.clock_skew_seconds)
                fail('AUTH_EXPIRED', 'Enrollment expired while waiting for current authority');
            return recorded(tx, item.id, 'identity.enroll', d.operation, async () => { const id = randomUUID(), p = (await tx.query("INSERT INTO hyperfide.identity_principals(credential_id,organisation_id,run_id,actor_id,role,public_key_b64,deployment_epoch,sandbox_id,boot_generation,boot_id,allowed_actions,expires_at) VALUES($1,$2,$3,$1,'RUNNER',$4,$5,$6,$7,$8,$9,$10) RETURNING *", [id, grant.organisation_id, grant.run_id, b.public_key_b64, grant.deployment_epoch, grant.sandbox_id, grant.boot_generation, grant.boot_id, grant.allowed_actions, grant.credential_expires_at])).rows[0]; await tx.query("UPDATE hyperfide.identity_enrollment_grants SET state='CONSUMED',credential_id=$2,consumed_operation_id=$3,consumed_payload_digest=$4 WHERE id=$1", [item.id, id, d.operation.operation_id, d.operation.payload_digest]); return result(p); });
        });
        if (object(outcome) && outcome.quarantined)
            fail('ENROLLMENT_QUARANTINED', 'Ambiguous boot quarantined');
        return outcome;
    };
    const verifyFreshRunner = async (i, tx, target) => {
        assertInvocation(i);
        role(i, ['PROVISIONER']);
        await i.guard(tx);
        exact(target, ['sandbox_id', 'boot_id', 'boot_generation', 'provisioning_intent_id', 'credential_id', 'observed_after', ...(Object.hasOwn(target, 'grant_id') ? ['grant_id'] : [])]);
        if (!uuid(target.sandbox_id) || !uuid(target.boot_id) || !decimal(target.boot_generation, true) || !uuid(target.provisioning_intent_id) || !uuid(target.credential_id) || target.grant_id !== undefined && !uuid(target.grant_id) || typeof target.observed_after !== 'string' || !Number.isFinite(Date.parse(target.observed_after)) || new Date(target.observed_after).toISOString() !== target.observed_after)
            fail('INVALID_REQUEST', 'Exact durable enrollment observation target required');
        const rows = (await tx.query("SELECT p.*,g.id AS grant_id,g.provisioning_intent_id,g.consumed_operation_id,rs.heartbeat_at,b.sandbox_version FROM hyperfide.identity_principals p JOIN hyperfide.identity_enrollment_grants g ON g.credential_id=p.credential_id AND g.organisation_id=p.organisation_id AND g.run_id=p.run_id AND g.state='CONSUMED' JOIN hyperfide.identity_runner_status rs ON rs.credential_id=p.credential_id JOIN hyperfide.identity_provider_bindings b ON b.organisation_id=g.organisation_id AND b.run_id=g.run_id AND b.provisioning_intent_id=g.provisioning_intent_id AND b.sandbox_id=g.sandbox_id AND b.boot_generation=g.boot_generation WHERE p.credential_id=$1 AND p.organisation_id=$2 AND p.run_id=$3 FOR SHARE OF p,g,rs,b", [target.credential_id, i.principal.organisation_id, i.principal.run_id])).rows;
        if (rows.length !== 1)
            fail('ENROLLMENT_OBSERVATION_REQUIRED', 'One actual consumed grant and signed runner observation is required');
        const r = rows[0];
        if (r.role !== 'RUNNER' || r.sandbox_id !== target.sandbox_id || r.boot_id !== target.boot_id || String(r.boot_generation) !== target.boot_generation || r.provisioning_intent_id !== target.provisioning_intent_id || target.grant_id !== undefined && r.grant_id !== target.grant_id || new Date(r.heartbeat_at).getTime() < Date.parse(target.observed_after))
            fail('ENROLLMENT_OBSERVATION_STALE', 'Consumed enrollment or actual signed observation is stale');
        await assertBoundPrincipal(tx, principal(r));
        const now = (await tx.query('SELECT clock_timestamp() AS db_now')).rows[0].db_now;
        if (new Date(r.heartbeat_at).getTime() > new Date(now).getTime())
            fail('ENROLLMENT_OBSERVATION_STALE', 'Runner observation cannot come from the future');
        return frozen({ credential_id: r.credential_id, sandbox_id: r.sandbox_id, boot_id: r.boot_id, boot_generation: String(r.boot_generation), grant_id: r.grant_id, provisioning_intent_id: r.provisioning_intent_id, heartbeat_at: new Date(r.heartbeat_at).toISOString(), observation_only: true, authority: 'NONE' });
    };
    const authority = Object.freeze({ installMainSessionVerifier, sealTrustedRegistrations, verifyFreshRunner, origin: c.origin, guard: assertBoundPrincipal, authenticate, enroll, authorize });
    const action = (name, fn) => async (v, context) => identityTransaction(context, async (tx, i) => {
        if (!object(v))
            fail('INVALID_REQUEST', 'Object input required');
        await authorize(i);
        // The signed envelope expected_version is the optimistic version dispatched to the action; it cannot diverge from the input it covers.
        if (i.payload.expected_version !== null && (!Object.hasOwn(v, 'expected_version') || v.expected_version !== i.payload.expected_version))
            fail('VERSION_CONFLICT', 'Envelope expected_version differs from operation input');
        return recorded(tx, i.principal.credential_id, name, i.operation, () => fn(tx, v, i));
    });
    return { apiVersion: 1, capabilities: { 'identity.authority': authority, 'identity.transport': authority }, actions: {
            'identity.describe': async (_v, context) => { const i = invocationOf(context); await authorize(i); return { protocol_version: 1, principal: i.principal }; },
            'identity.binding.observe': action('identity.binding.observe', async (tx, v, i) => { role(i, ['PROVISIONER']); exact(v, ['provisioning_intent_id', 'sandbox_id', 'boot_generation', 'boot_id', 'native_sandbox_id', 'observation_digest', 'expected_version']); if (!uuid(v.provisioning_intent_id) || !uuid(v.sandbox_id) || !uuid(v.boot_id) || !decimal(v.boot_generation, true) || !decimal(v.expected_version, true) || typeof v.native_sandbox_id !== 'string' || typeof v.observation_digest !== 'string' || !/^sha256:[0-9a-f]{64}$/.test(v.observation_digest))
                fail('INVALID_REQUEST', 'Invalid provider binding'); const p = i.principal, s = (await tx.query('SELECT s.*,b.boot_id FROM hyperfide.sandboxes s JOIN hyperfide.sandbox_boots b ON b.organisation_id=s.organisation_id AND b.sandbox_id=s.id AND b.boot_generation=s.boot_generation WHERE s.organisation_id=$1 AND s.id=$2 FOR SHARE OF s,b', [p.organisation_id, v.sandbox_id])).rows[0]; if (!s || s.observed_state !== 'RUNNING' || s.native_sandbox_id !== v.native_sandbox_id || String(s.boot_generation) !== v.boot_generation || s.boot_id !== v.boot_id || String(s.state_version) !== v.expected_version)
                fail('PROVIDER_BINDING_STALE', 'Provider observation mismatch'); await tx.query('INSERT INTO hyperfide.identity_provider_bindings(organisation_id,run_id,provisioning_intent_id,sandbox_id,pool_id,boot_generation,boot_id,native_sandbox_id,observation_digest,observed_by,sandbox_version) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)', [p.organisation_id, p.run_id, v.provisioning_intent_id, v.sandbox_id, s.pool_id, v.boot_generation, v.boot_id, v.native_sandbox_id, v.observation_digest, p.credential_id, v.expected_version]); return { observed: true, provisioning_intent_id: v.provisioning_intent_id }; }),
            'identity.grant.issue': action('identity.grant.issue', async (tx, v, i) => { role(i, ['COORDINATOR', 'PROVISIONER', 'OPERATOR']); exact(v, ['grant_id', 'provisioning_intent_id', 'verifier', 'allowed_actions', 'ttl_seconds']); if (!uuid(v.grant_id) || !uuid(v.provisioning_intent_id) || typeof v.verifier !== 'string' || !/^sha256:[0-9a-f]{64}$/.test(v.verifier) || !Number.isInteger(v.ttl_seconds) || Number(v.ttl_seconds) < 1 || Number(v.ttl_seconds) > c.grant_ttl_seconds)
                fail('INVALID_REQUEST', 'Invalid bootstrap grant'); const a = allowed(v.allowed_actions), p = i.principal; if (a.some(x => !p.allowed_actions.includes(x)))
                fail('AUTH_SCOPE_DENIED', 'Grant cannot expand issuer capabilities'); const b = (await tx.query('SELECT b.*,s.observed_state,s.boot_generation AS current_boot,s.state_version AS current_version FROM hyperfide.identity_provider_bindings b JOIN hyperfide.sandboxes s ON s.organisation_id=b.organisation_id AND s.id=b.sandbox_id WHERE b.organisation_id=$1 AND b.run_id=$2 AND b.provisioning_intent_id=$3 FOR SHARE OF b,s', [p.organisation_id, p.run_id, v.provisioning_intent_id])).rows[0]; if (!b || b.observed_state !== 'RUNNING' || String(b.boot_generation) !== String(b.current_boot) || String(b.sandbox_version) !== String(b.current_version))
                fail('PROVIDER_BINDING_STALE', 'Current provisioning binding required'); const r = (await tx.query("INSERT INTO hyperfide.identity_enrollment_grants(id,organisation_id,run_id,provisioning_intent_id,sandbox_id,boot_generation,boot_id,verifier,deployment_epoch,allowed_actions,expires_at,credential_expires_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,clock_timestamp()+($11::int*interval '1 second'),clock_timestamp()+($12::int*interval '1 second')) RETURNING id,boot_id,boot_generation,expires_at", [v.grant_id, p.organisation_id, p.run_id, v.provisioning_intent_id, b.sandbox_id, b.boot_generation, b.boot_id, v.verifier, p.deployment_epoch, a, v.ttl_seconds, c.credential_ttl_seconds])).rows[0]; return { grant_id: r.id, boot_id: r.boot_id, boot_generation: String(r.boot_generation), expires_at: new Date(r.expires_at).toISOString() }; }),
            'identity.runner.register': action('identity.runner.register', async (tx, v, i) => {
                role(i, ['RUNNER']);
                exact(v, ['preparation_digest', 'inventory']);
                if (typeof v.preparation_digest !== 'string' || !/^sha256:[0-9a-f]{64}$/.test(v.preparation_digest) || !Array.isArray(v.inventory) || v.inventory.length > 256 || Buffer.byteLength(JSON.stringify(v.inventory)) > 262144)
                    fail('INVALID_REQUEST', 'Bounded preparation/inventory report required');
                const p = i.principal, s = (await tx.query('SELECT preparation_digest FROM hyperfide.sandboxes WHERE organisation_id=$1 AND id=$2 FOR SHARE', [p.organisation_id, p.sandbox_id])).rows[0];
                if (!s || s.preparation_digest !== v.preparation_digest)
                    fail('PREPARATION_MISMATCH', 'Reported preparation differs from registered resource');
                const r = (await tx.query('INSERT INTO hyperfide.identity_runner_status(credential_id,preparation_digest,inventory) VALUES($1,$2,$3) ON CONFLICT(credential_id) DO UPDATE SET preparation_digest=EXCLUDED.preparation_digest,inventory=EXCLUDED.inventory,state_version=hyperfide.identity_runner_status.state_version+1,heartbeat_at=clock_timestamp() RETURNING state_version,heartbeat_at', [p.credential_id, v.preparation_digest, JSON.stringify(v.inventory)])).rows[0];
                return { registered: true, credential_id: p.credential_id, sandbox_id: p.sandbox_id, boot_id: p.boot_id, boot_generation: p.boot_generation, state_version: String(r.state_version), heartbeat_at: new Date(r.heartbeat_at).toISOString() };
            }),
            'identity.runner.heartbeat': action('identity.runner.heartbeat', async (tx, v, i) => {
                role(i, ['RUNNER']);
                exact(v, ['expected_version']);
                if (!decimal(v.expected_version, true))
                    fail('INVALID_REQUEST', 'Expected runner status version required');
                const r = await tx.query('UPDATE hyperfide.identity_runner_status SET state_version=state_version+1,heartbeat_at=clock_timestamp() WHERE credential_id=$1 AND state_version=$2 RETURNING state_version,heartbeat_at', [i.principal.credential_id, v.expected_version]);
                if (r.rowCount !== 1)
                    fail('VERSION_CONFLICT', 'Runner status version is not current');
                return { heartbeat: true, state_version: String(r.rows[0].state_version), heartbeat_at: new Date(r.rows[0].heartbeat_at).toISOString() };
            }),
            'identity.principal.delegate': action('identity.principal.delegate', async (tx, v, i) => {
                role(i, ['RUNNER']);
                exact(v, ['session_id', 'public_key_b64', 'allowed_actions', 'ttl_seconds']);
                if (!uuid(v.session_id) || typeof v.public_key_b64 !== 'string' || !Number.isInteger(v.ttl_seconds) || Number(v.ttl_seconds) < 60 || Number(v.ttl_seconds) > c.credential_ttl_seconds)
                    fail('INVALID_REQUEST', 'Registered child session/key/expiry required');
                base64(v.public_key_b64, 32);
                const a = allowed(v.allowed_actions), p = i.principal;
                if (a.some(x => !p.allowed_actions.includes(x)))
                    fail('AUTH_SCOPE_DENIED', 'Child cannot expand runner capabilities');
                const session = (await tx.query('SELECT * FROM hyperfide.agent_sessions WHERE organisation_id=$1 AND run_id=$2 AND id=$3 FOR SHARE', [p.organisation_id, p.run_id, v.session_id])).rows[0];
                if (!session || typeof session.native_session_id !== 'string' || !session.native_session_id || !['WORKER', 'VERIFIER', 'COMMIT_WATCHER', 'ISSUE_WATCHER', 'INTEGRATOR', 'INDEXER'].includes(session.role) || !['REGISTERED', 'RUNNING'].includes(session.state) || session.sandbox_id !== p.sandbox_id || String(session.sandbox_boot_generation) !== p.boot_generation)
                    fail('AUTH_SCOPE_DENIED', 'Child session is not registered in this runner boot');
                let generation = null;
                if (session.role === 'WORKER') {
                    if (!session.attempt_id)
                        fail('AUTH_SCOPE_DENIED', 'Coding worker requires an implementation attempt');
                    const attempt = (await tx.query('SELECT * FROM hyperfide.attempts WHERE organisation_id=$1 AND run_id=$2 AND id=$3 FOR SHARE', [p.organisation_id, p.run_id, session.attempt_id])).rows[0];
                    if (!attempt || attempt.kind !== 'IMPLEMENTATION' || attempt.compute_authority !== 'CURRENT' || attempt.sandbox_id !== p.sandbox_id || String(attempt.sandbox_boot_generation) !== p.boot_generation || attempt.slot_id !== session.slot_id)
                        fail('AUTH_SCOPE_DENIED', 'Worker attempt/slot is not current');
                    generation = String(attempt.generation);
                }
                else if (session.attempt_id !== null)
                    fail('AUTH_SCOPE_DENIED', 'Review/index/integration jobs require independent job authority, not coding compute authority');
                await assertBoundPrincipal(tx, p);
                const id = randomUUID(), row = (await tx.query("INSERT INTO hyperfide.identity_principals(credential_id,organisation_id,run_id,actor_id,role,public_key_b64,deployment_epoch,sandbox_id,boot_generation,boot_id,attempt_id,attempt_generation,allowed_actions,expires_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,LEAST($14::timestamptz,clock_timestamp()+($15::int*interval '1 second'))) RETURNING *", [id, p.organisation_id, p.run_id, session.id, session.role, v.public_key_b64, p.deployment_epoch, p.sandbox_id, p.boot_generation, p.boot_id, session.attempt_id, generation, a, p.expires_at, v.ttl_seconds])).rows[0];
                await assertBoundPrincipal(tx, principal(row));
                return { ...result(row), authority: { deployment_epoch: p.deployment_epoch, attempt_id: row.attempt_id, attempt_generation: row.attempt_generation === null ? null : String(row.attempt_generation), sandbox_id: p.sandbox_id, boot_generation: p.boot_generation } };
            }),
            'identity.main.issue': action('identity.main.issue', async (tx, v, i) => {
                role(i, ['OPERATOR']);
                exact(v, ['session_id', 'public_key_b64', 'allowed_actions', 'ttl_seconds']);
                if (!uuid(v.session_id) || !Number.isInteger(v.ttl_seconds) || Number(v.ttl_seconds) < 60 || Number(v.ttl_seconds) > c.credential_ttl_seconds)
                    fail('INVALID_REQUEST', 'Observed MAIN session/key and bounded expiry required');
                base64(v.public_key_b64, 32);
                const a = allowed(v.allowed_actions), p = i.principal;
                if (a.some(x => !p.allowed_actions.includes(x)))
                    fail('AUTH_SCOPE_DENIED', 'MAIN grant cannot expand operator capabilities');
                if (!registrationsSealed || !mainVerifier)
                    fail('MAIN_VERIFIER_REQUIRED', 'Actual trusted MAIN host/native verifier is required');
                assertPrimaryTransaction(tx);
                const verified = await mainVerifier.verify(tx, { organisation_id: p.organisation_id, run_id: p.run_id, session_id: v.session_id }, i);
                exact(verified, ['organisation_id', 'run_id', 'session_id', 'role', 'placement', 'native_session_id', 'registration_receipt_digest']);
                if (verified.organisation_id !== p.organisation_id || verified.run_id !== p.run_id || verified.session_id !== v.session_id || !['LEADER', 'FEATURE_MANAGER'].includes(verified.role) || verified.placement !== 'MAIN' || typeof verified.native_session_id !== 'string' || !verified.native_session_id || typeof verified.registration_receipt_digest !== 'string' || !/^sha256:[0-9a-f]{64}$/.test(verified.registration_receipt_digest))
                    fail('MAIN_BINDING_INVALID', 'Exact observed MAIN session binding required');
                const session = (await tx.query('SELECT * FROM hyperfide.agent_sessions WHERE organisation_id=$1 AND run_id=$2 AND id=$3 FOR SHARE', [p.organisation_id, p.run_id, v.session_id])).rows[0];
                if (!session || session.role !== verified.role || session.native_session_id !== verified.native_session_id || !['REGISTERED', 'RUNNING'].includes(session.state) || session.sandbox_id !== null || session.sandbox_boot_generation !== null || session.attempt_id !== null)
                    fail('AUTH_STALE_SESSION', 'Observed MAIN session is not the actual current unbound supervisor');
                await i.guard(tx);
                const id = randomUUID(), row = (await tx.query("INSERT INTO hyperfide.identity_principals(credential_id,organisation_id,run_id,actor_id,role,public_key_b64,deployment_epoch,allowed_actions,expires_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,LEAST($9::timestamptz,clock_timestamp()+($10::int*interval '1 second'))) RETURNING *", [id, p.organisation_id, p.run_id, session.id, session.role, v.public_key_b64, p.deployment_epoch, a, p.expires_at, v.ttl_seconds])).rows[0];
                await assertBoundPrincipal(tx, principal(row));
                return { ...result(row), registration_receipt_digest: verified.registration_receipt_digest, placement: 'MAIN', model_qualification: 'NOT_GRANTED' };
            }),
            'identity.service.issue': action('identity.service.issue', async (tx, v, i) => {
                role(i, ['OPERATOR']);
                exact(v, ['credential_id', 'actor_id', 'role', 'public_key_b64', 'allowed_actions', 'ttl_seconds']);
                if (!uuid(v.credential_id) || !uuid(v.actor_id) || typeof v.role !== 'string' || !['COORDINATOR', 'PROVISIONER', 'DISPATCH', 'GITHUB_MIRROR'].includes(v.role) || !Number.isInteger(v.ttl_seconds) || Number(v.ttl_seconds) < 60 || Number(v.ttl_seconds) > c.credential_ttl_seconds)
                    fail('INVALID_REQUEST', 'Bounded approved service identity required');
                base64(v.public_key_b64, 32);
                const a = allowed(v.allowed_actions), p = i.principal;
                if (a.some(x => !p.allowed_actions.includes(x)))
                    fail('AUTH_SCOPE_DENIED', 'Service grant cannot expand operator capabilities');
                await i.guard(tx);
                const row = (await tx.query("INSERT INTO hyperfide.identity_principals(credential_id,organisation_id,run_id,actor_id,role,public_key_b64,deployment_epoch,allowed_actions,expires_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,LEAST($9::timestamptz,clock_timestamp()+($10::int*interval '1 second'))) RETURNING *", [v.credential_id, p.organisation_id, p.run_id, v.actor_id, v.role, v.public_key_b64, p.deployment_epoch, a, p.expires_at, v.ttl_seconds])).rows[0];
                await assertBoundPrincipal(tx, principal(row));
                return { ...result(row), credential_version: String(row.credential_version), deployment_epoch: p.deployment_epoch };
            }),
            'identity.principal.renew': action('identity.principal.renew', async (tx, v, i) => {
                exact(v, ['ttl_seconds']);
                if (!Number.isInteger(v.ttl_seconds) || Number(v.ttl_seconds) < 60 || Number(v.ttl_seconds) > c.credential_ttl_seconds)
                    fail('INVALID_REQUEST', 'Bounded platform identity renewal required');
                const p = i.principal;
                await tx.query('SELECT credential_id FROM hyperfide.identity_principals WHERE credential_id=$1 FOR UPDATE', [p.credential_id]);
                await i.guard(tx);
                const r = (await tx.query("UPDATE hyperfide.identity_principals SET credential_version=credential_version+1,expires_at=clock_timestamp()+($3::int*interval '1 second') WHERE credential_id=$1 AND credential_version=$2 AND state='ACTIVE' RETURNING *", [p.credential_id, p.credential_version, v.ttl_seconds])).rows[0];
                if (!r)
                    fail('VERSION_CONFLICT', 'Platform identity changed during renewal');
                return { ...result(r), credential_version: String(r.credential_version), compute_lease_renewed: false };
            }),
            'identity.principal.revoke': action('identity.principal.revoke', async (tx, v, i) => { role(i, ['COORDINATOR', 'OPERATOR']); exact(v, ['credential_id', 'expected_version']); if (!uuid(v.credential_id) || !decimal(v.expected_version, true))
                fail('INVALID_REQUEST', 'Credential/version required'); const p = i.principal, r = await tx.query("UPDATE hyperfide.identity_principals SET state='REVOKED',credential_version=credential_version+1 WHERE organisation_id=$1 AND run_id=$2 AND credential_id=$3 AND credential_version=$4 RETURNING credential_version", [p.organisation_id, p.run_id, v.credential_id, v.expected_version]); if (r.rowCount !== 1)
                fail('VERSION_CONFLICT', 'Credential version mismatch'); return { revoked: true, credential_id: v.credential_id, credential_version: String(r.rows[0].credential_version) }; })
        } };
}
//# sourceMappingURL=enrollment.js.map