import type pg from 'pg';
import type { Component, ComponentContext } from '../components/registry.js';
import type { JsonObject } from './extraction.js';
export interface GraphTransaction {
    query<R extends pg.QueryResultRow = pg.QueryResultRow>(sql: string, values?: unknown[]): Promise<pg.QueryResult<R>>;
    copyFrom(sql: string, bytes: Uint8Array): Promise<{
        rowCount: number;
    }>;
    remainingMs(): number;
    readonly signal: AbortSignal;
}
export interface GraphGateway {
    withPrimaryTransaction<T>(options: {
        timeoutMs: number;
        maxRetries?: number;
        guard?: (tx: GraphTransaction) => void | Promise<void>;
        signal?: AbortSignal;
    }, fn: (tx: GraphTransaction) => Promise<T>): Promise<T>;
}
export interface GraphScope {
    organisation_id: string;
    run_id: string;
    authority_epoch: string;
}
export declare function scopeInput(input: JsonObject, ctx: ComponentContext): GraphScope;
export declare function graphRole(ctx: ComponentContext, write: boolean): void;
export declare function graphGateway(ctx: ComponentContext): GraphGateway;
export declare function graphGuard(tx: GraphTransaction, scope: GraphScope, ctx: ComponentContext, write?: boolean): Promise<void>;
export interface GraphAdmissionLimits {
    max_active: number;
    max_queued: number;
    queue_wait_ms: number;
    primary_pool_max: number;
}
export declare class GraphAdmission {
    readonly limits: GraphAdmissionLimits;
    private active;
    private queue;
    private admitted;
    private refused;
    constructor(limits: GraphAdmissionLimits);
    private overloaded;
    run<T>(signal: AbortSignal | undefined, fn: () => Promise<T>): Promise<T>;
    metrics(): JsonObject;
}
export declare function graphAdmissionLimits(ctx: ComponentContext): GraphAdmissionLimits;
export declare function graphAdmission(ctx: ComponentContext): GraphAdmission;
export declare function graphTransaction<T>(ctx: ComponentContext, scope: GraphScope, fn: (tx: GraphTransaction) => Promise<T>, write?: boolean): Promise<T>;
export declare function sourceId(build: string, bundle: string, family: string, legacy: unknown): string;
export declare function semanticProjectionDebt(tx: Pick<GraphTransaction, 'query'>, s: GraphScope, graphId: string): Promise<{
    count: string;
    rows: JsonObject[];
}>;
export declare function getBuild(tx: GraphTransaction, s: GraphScope, id: string, lock?: boolean): Promise<JsonObject>;
export declare function assertGraphArtifacts(tx: GraphTransaction, s: GraphScope, id: string): Promise<void>;
export declare function graphCoverage(tx: GraphTransaction, s: GraphScope, id: string): Promise<JsonObject>;
export declare function createComponent(ctx: ComponentContext): Component;
