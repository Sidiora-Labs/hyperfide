import type { VerifiedWriterObservationPermit } from '../identity/credentials.js';
export interface WriterObservation {
    readonly schema_version: 1;
    readonly deployment_id: string;
    readonly operation_id: string;
    readonly source_epoch: string | null;
    readonly topology_digest: string;
    readonly status: 'OBSERVED' | 'UNKNOWN';
    readonly observed_at: string;
    readonly expires_at: string;
    readonly evidence_digest: string;
    readonly journal_operation_id: string;
    readonly resource_count: number;
    readonly isolated_count: number;
    readonly unknown_count: number;
    readonly legacy_status: 'ISOLATED' | 'UNKNOWN';
    readonly destruction_authority: false;
    readonly activation_authority: false;
}
export interface WriterObservationPermitVerifier {
    verifySigned(serialized: Buffer | string): VerifiedWriterObservationPermit;
}
export interface WriterObservationHttpTransportOptions {
    readonly origin: string;
    readonly host: string;
    readonly port: number;
    readonly certificate: string;
    readonly privateKey: string;
    readonly signal: AbortSignal;
    readonly verifier: WriterObservationPermitVerifier;
    readonly dispatch: (permit: VerifiedWriterObservationPermit, signal: AbortSignal) => Promise<WriterObservation>;
    readonly maxConcurrent?: number;
    readonly deadlineMs?: number;
}
export interface WriterObservationHttpTransport {
    readonly address: string;
    close(): Promise<void>;
}
export type WriterObservationHttpResult = {
    readonly outcome: 'OBSERVED';
    readonly observation: WriterObservation;
} | {
    readonly outcome: 'REJECTED';
    readonly code: string;
} | {
    readonly outcome: 'UNKNOWN';
    readonly code: 'WRITER_OBSERVATION_OUTCOME_UNKNOWN';
};
export interface WriterObservationHttpClientOptions {
    readonly origin: string;
    readonly caFile: string;
    readonly deadlineMs?: number;
    readonly maxConcurrent?: number;
}
export interface WriterObservationHttpClient {
    observe(permitEnvelope: string, signal: AbortSignal): Promise<WriterObservationHttpResult>;
}
export declare function parseWriterObservation(value: unknown): WriterObservation;
/** Observation-only listener: no destructive dispatcher or activation capability is accepted. */
export declare function startWriterObservationHttpTransport(options: WriterObservationHttpTransportOptions): Promise<WriterObservationHttpTransport>;
/** No redirects, dynamic URLs, bearer identity or PG fallback are accepted. */
export declare function createWriterObservationHttpClient(options: WriterObservationHttpClientOptions): Promise<WriterObservationHttpClient>;
