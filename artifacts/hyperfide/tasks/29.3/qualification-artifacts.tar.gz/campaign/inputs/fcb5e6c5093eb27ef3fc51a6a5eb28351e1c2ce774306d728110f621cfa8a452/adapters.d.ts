import { FoundationError } from '../policy/programme.js';
import type { ComponentContext } from '../components/registry.js';
export declare class DecisionError extends FoundationError {
    readonly retryable: boolean;
    readonly retryAfterMs: number | null;
    constructor(code: string, message: string, retryable?: boolean, retryAfterMs?: number | null);
}
export declare const fail: (code: string, message: string) => never;
export declare function record(value: unknown, label: string): Record<string, unknown>;
export declare function exact(value: Record<string, unknown>, allowed: string[], required?: string[]): void;
export declare function text(value: unknown, label: string, limit?: number): string;
export declare function integer(value: unknown, label: string, min: number, max: number): number;
/** Strict JSON keeps duplicate answer/option identities from being silently overwritten. */
export declare function strictJson(input: string, maxBytes?: number): unknown;
export declare function canonical(value: unknown): string;
export declare const hash: (value: unknown) => string;
export type QuestionType = 'noul' | 'choice' | 'score' | 'number' | 'box';
export interface Question {
    type: QuestionType;
    instructions: unknown;
    criteria?: unknown;
}
export interface DecisionRequest {
    state: unknown;
    questions: Record<string, Question>;
}
export type RouteId = 'span-native' | 'jev-native' | 'ultra-native' | 'span-openrouter' | 'jev-openrouter' | 'ultra-openrouter' | 'span-selfhost';
export interface RouteProfile {
    id: RouteId;
    catalogue_model: string;
    model: string;
    endpoint: string | null;
    route_class: 'native' | 'gateway' | 'selfhost';
    provider: 'respan' | 'typesafe' | 'liquid';
    choice_max: number | null;
    score_max: number;
    context_request_tokens: number | null;
    context_question_tokens: number | null;
    image_format: 'images' | 'assets' | 'state_parts';
    native_number: boolean;
    native_box: boolean;
    reasoning: boolean;
    live_qualification: 'UNQUALIFIED';
    source_urls: string[];
}
export declare const ROUTES: Readonly<Record<RouteId, RouteProfile>>;
export declare function route(id: unknown): RouteProfile;
export declare function validateRequest(input: unknown, profile: RouteProfile, enabled?: readonly QuestionType[], gatewayMedia?: boolean): DecisionRequest;
export interface PreparedRequest {
    route: RouteProfile;
    body: Record<string, unknown>;
    headers: Record<string, string>;
    request_hash: string;
    source_request: DecisionRequest;
}
export declare function prepare(id: unknown, input: unknown, extensions?: {
    gateway_media?: true;
    types?: readonly QuestionType[];
    body?: Record<string, unknown>;
    headers?: Record<string, string>;
}): PreparedRequest;
interface TransportProfile {
    enabled: boolean;
    mode: 'live' | 'fixture';
    qualification_ref: string;
    credential_env: string;
    endpoint: string;
    max_body_bytes: number;
    returned_models: string[];
}
export declare function configuredTransport(profile: RouteProfile, env: Readonly<NodeJS.ProcessEnv>): TransportProfile;
export interface TransportResult {
    route_id: RouteId;
    requested_model: string;
    returned_model: string;
    response: Record<string, unknown>;
    request_hash: string;
    response_hash: string;
    duration_ms: number;
    qualification: 'fixture' | 'live';
    qualification_ref: string;
    http_status: number;
}
export declare function invokePrepared(request: PreparedRequest, env: Readonly<NodeJS.ProcessEnv>, options: {
    timeout_ms: number;
    signal?: AbortSignal;
}): Promise<TransportResult>;
export declare function legacyConfiguration(env: Readonly<NodeJS.ProcessEnv>): unknown;
export declare function createComponent(ctx: ComponentContext): unknown;
export {};
