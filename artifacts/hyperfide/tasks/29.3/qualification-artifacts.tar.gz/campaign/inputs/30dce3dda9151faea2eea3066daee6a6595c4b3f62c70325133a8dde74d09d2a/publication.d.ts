import type { Component, ComponentContext } from '../components/registry.js';
import { type Scope, type IntegrationConfig } from './candidates.js';
import { type HostedResult } from './github.js';
/** Hosted publication requires a separate server-enforced adapter. A local
 * receive hook establishes no GitHub ruleset or installation permissions. */
export interface ProtectedRemoteEvidence {
    provider: 'GITHUB';
    repository_identity: string;
    protected_ref: string;
    observed_head: string;
    rules_digest: string;
    publisher_identity: string;
    direct_push_denial_receipt_digest: string;
    candidate_digest: string;
    authority_epoch: string;
    operation_id: string;
    operation_generation: string;
}
export interface ProtectedRemoteAdapter {
    inspectProtection(scope: Scope, repositoryId: string): Promise<{
        status: 'ENFORCED' | 'UNSUPPORTED' | 'UNKNOWN';
        evidence?: ProtectedRemoteEvidence;
    }>;
    publish(intent: Readonly<Permit>, evidence: ProtectedRemoteEvidence): Promise<{
        outcome: 'PUBLISHED' | 'REJECTED' | 'UNKNOWN';
        observed_head?: string;
    }>;
    reconcile(intent: Readonly<Permit>): Promise<{
        outcome: 'PUBLISHED' | 'REJECTED' | 'UNKNOWN';
        observed_head?: string;
    }>;
}
interface Permit {
    version: 1;
    organisation_id: string;
    run_id: string;
    operation_id: string;
    generation: string;
    repository_id: string;
    ref: string;
    old: string;
    next: string;
    input_digest: string;
}
export declare function receivePermit(db: unknown, key: Buffer, token: string, lines: string, receivePath: string, cfg: IntegrationConfig, trustedGateway?: {
    withPrimaryTransaction: <T>(options: {
        timeoutMs: number;
        maxRetries: number;
    }, body: (db: import('./candidates.js').DB) => Promise<T>) => Promise<T>;
}): Promise<void>;
export declare function reconcilePublication(pool: import('./candidates.js').DB, cfg: IntegrationConfig, s: Scope, id: string, transportSettled?: boolean, env?: Readonly<NodeJS.ProcessEnv>, hostedResult?: HostedResult): Promise<unknown>;
/** Shared product transport: suppress client hooks without disabling the server receive hook. */
export declare function pushManaged(repositoryPath: string, receivePath: string, ref: string, next: string, old: string, permitToken: string, env: Readonly<NodeJS.ProcessEnv>): Promise<void>;
export declare function installGatewayHook(receivePath: string, serverConfigPath: string, node?: string): Promise<void>;
export declare function inspectIntegratedPublication(db: import('./candidates.js').DB, s: Scope, pins: {
    task_id: string;
    custody_id: string;
    custody_generation: string;
}): Promise<Record<string, unknown>>;
export declare function stopIntegration(db: import('./candidates.js').DB, s: Scope, control: {
    mode: 'CANCEL' | 'STOP';
    control_generation: string;
}): Promise<{
    cancelled_operation_ids: string[];
    unresolved_operation_ids: string[];
    deferred_custody_ids: string[];
    safe_to_revoke_custody_ids: string[];
}>;
export declare function createComponent(ctx: ComponentContext): Component;
export {};
