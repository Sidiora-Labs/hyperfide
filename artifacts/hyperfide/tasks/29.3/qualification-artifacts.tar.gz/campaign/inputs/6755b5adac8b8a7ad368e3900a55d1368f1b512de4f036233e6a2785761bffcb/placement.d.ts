import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { TransactionGateway, PrimaryTransaction } from '../storage/transactions.js';
import type { ProviderOperation, ProviderScope, ProviderOutcome } from './contract.js';
import type { ProviderDatabase, DeploymentConfig, ProviderIsolationFactory } from './pools.js';
export interface FreshEnrollmentProof {
    enrolled: true;
    boot_id: string;
    session_id: string;
    credential_id: string;
    credential_lineage: string;
    verified_at: string;
    evidence_digest: string;
}
interface PlacementDependencies {
    authority: {
        verifyFreshRunner(invocation: InvocationContext, tx: PrimaryTransaction, input: Record<string, unknown>): Promise<Record<string, unknown>>;
    };
    execution: import('./reconcile.js').ProviderExecutionCapability;
    native: {
        authenticatePlacementProbe(invocation: InvocationContext, input: {
            probe_id: string;
        }, signal: AbortSignal): Promise<{
            request: import('./reconcile.js').BoundProviderRequest;
            invocation: InvocationContext;
        }>;
    };
}
export interface EnvironmentCompatibilityProof {
    compatible: boolean;
    evidence_digest: string;
}
export type EnvironmentCompatibilityVerifier = (source: unknown, target: unknown) => Promise<EnvironmentCompatibilityProof>;
/** Compares the published, self-digested preparation manifests (11.1 metadata
 * validation). It grants neither readiness nor ownership: fresh enrollment and
 * target-boot probes remain required before any admission. */
export declare const preparationCompatibilityVerifier: EnvironmentCompatibilityVerifier;
interface Target {
    name: 'coordinator' | 'git' | 'artifact' | 'model';
    url: string;
    header_name: string;
    header_prefix: string;
    credential_ref: string;
    expected_status: number;
    denied_statuses: number[];
    expected_body_sha256: string | null;
}
interface ConnectivityConfig {
    schema_version: 1;
    evidence_scope: 'LIVE_POOL' | 'COMPONENT_FIXTURE';
    targets: Target[];
    timeout_ms: number;
    maximum_attempts: number;
    base_backoff_ms: number;
    max_backoff_ms: number;
    proof_max_age_ms: number;
}
export declare function probePool(pool: ProviderDatabase, config: DeploymentConfig, policy: ConnectivityConfig, value: unknown, signal: AbortSignal, resolveDependencies?: () => PlacementDependencies): Promise<unknown>;
export declare function recordPoolFailure(pool: ProviderDatabase, config: DeploymentConfig, policy: ConnectivityConfig, value: unknown): Promise<unknown>;
export declare function planRelocation(pool: ProviderDatabase, config: DeploymentConfig, policy: ConnectivityConfig, value: unknown, environmentVerifier?: EnvironmentCompatibilityVerifier): Promise<unknown>;
export interface ProviderIsolationReceipt {
    reference_key: string;
    operation_id: string;
    status: 'ISOLATED' | 'UNKNOWN';
    topology_digest: string;
    resource_identity_digest: string;
    observed_state: 'DESTROYED' | 'ABSENT' | 'UNKNOWN';
    observed_at: string;
    expires_at: string;
    evidence_digest: string;
    evidence_scope: 'LIVE_PROVIDER' | 'COMPONENT_FIXTURE';
}
export interface ProviderIsolationBinding {
    schema_version: 1;
    reference_key: string;
    operation_id: string;
    topology_digest: string;
    resource_identity_digest: string;
    destroy_operation: ProviderOperation<'destroy'>;
    authority_digest: string;
    custody_evidence_digest: string;
    custody_expires_at: string;
}
export interface ProviderIsolationState {
    binding: ProviderIsolationBinding;
    receipt: ProviderIsolationReceipt | null;
}
export interface ProviderIsolationJournal {
    read(): Promise<ProviderIsolationState | null>;
    prepare(binding: ProviderIsolationBinding): Promise<{
        created: boolean;
        state: ProviderIsolationState;
    }>;
    record(value: {
        binding: ProviderIsolationBinding;
        receipt: ProviderIsolationReceipt;
        observations: Array<{
            operation: ProviderOperation;
            outcome: ProviderOutcome;
        }>;
    }): Promise<void>;
}
export interface IsolationTarget {
    reference_key: string;
    scope: ProviderScope;
    resource: NonNullable<ProviderOperation['resource']>;
    boot_id: string;
    preparation_digest: string;
    resource_topology_digest: string;
}
export interface ProviderIsolationCustodyProof {
    operation_id: string;
    resource_identity_digest: string;
    evidence_digest: string;
    observed_at: string;
    expires_at: string;
}
export type ProviderIsolationCustodyPreflight = (target: Readonly<IsolationTarget>, operationId: string, authority: unknown, signal: AbortSignal) => Promise<ProviderIsolationCustodyProof | null>;
export interface ProviderIsolationRuntime {
    destructionPreflight?: ProviderIsolationCustodyPreflight;
    env: Readonly<NodeJS.ProcessEnv>;
    signal: AbortSignal;
    registry: Map<string, ProviderIsolationFactory>;
    gateway?: Pick<TransactionGateway, 'withPrimaryTransaction'>;
}
export declare function createProviderIsolation(runtime: ProviderIsolationRuntime): (referenceKey: string, operationId: string, authority: unknown, signal: AbortSignal, journal: ProviderIsolationJournal) => Promise<ProviderIsolationReceipt>;
export interface ProviderWriterObservation {
    reference_key: string;
    operation_id: string;
    status: 'OBSERVED' | 'UNKNOWN';
    observed_state: 'ABSENT' | 'PRESENT' | 'UNKNOWN';
    topology_digest: string;
    resource_identity_digest: string;
    observed_at: string;
    expires_at: string;
    evidence_digest: string;
    evidence_scope: 'LIVE_PROVIDER' | 'COMPONENT_FIXTURE';
    authority: 'OBSERVATION_ONLY';
}
export interface ProviderIsolationObservationJournal {
    read(): Promise<ProviderIsolationState | null>;
    recordObservation(value: {
        binding: ProviderIsolationBinding;
        observation: ProviderWriterObservation;
        provider_observation: {
            operation: ProviderOperation<'observe'>;
            outcome: ProviderOutcome<'observe'>;
        };
        authorization_digest: string;
        authorization_expires_at: string;
    }): Promise<void>;
}
export interface ProviderIsolationObserverRuntime {
    env: Readonly<NodeJS.ProcessEnv>;
    signal: AbortSignal;
    registry: Map<string, (scope: ProviderScope) => Pick<Awaited<ReturnType<ProviderIsolationFactory>>, 'observe'> | Promise<Pick<Awaited<ReturnType<ProviderIsolationFactory>>, 'observe'>>>;
}
/** A distinct, non-mutating observation route. It cannot prepare an operation,
 * obtain destroy(), renew destructive authority, or return an activation receipt. */
export declare function createProviderIsolationObserver(runtime: ProviderIsolationObserverRuntime): (referenceKey: string, operationId: string, authority: unknown, signal: AbortSignal, journal: ProviderIsolationObservationJournal) => Promise<ProviderWriterObservation>;
export declare function createComponent(context: ComponentContext): Component;
/** This deployment entry requires actual native-worker signing/artifact
 * prerequisites. Metadata-only deployments never advertise physical probes. */
export declare function createProbeComponent(context: ComponentContext): Component;
export {};
