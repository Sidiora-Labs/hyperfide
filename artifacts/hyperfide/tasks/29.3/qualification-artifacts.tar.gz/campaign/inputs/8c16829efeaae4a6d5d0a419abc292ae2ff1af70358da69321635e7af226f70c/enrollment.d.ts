import type { PrimaryTransaction } from '../storage/transactions.js';
import type { Component, ComponentContext } from '../components/registry.js';
import type { AuthorityTransaction, InvocationContext, Operation, Principal } from '../transport/protocol.js';
export type IdentityTransaction = AuthorityTransaction;
export interface IdentityGateway {
    withPrimaryTransaction<T>(options: {
        timeoutMs: number;
        maxRetries?: number;
        signal?: AbortSignal;
        guard?: (tx: IdentityTransaction) => Promise<void>;
    }, operation: (tx: IdentityTransaction) => Promise<T>): Promise<T>;
}
export interface GlobalIdentityAuthority {
    assertCurrent(tx: PrimaryTransaction, scope: {
        organisation_id: string;
        run_id: string;
        authority_epoch: string;
    }): Promise<void>;
}
export interface FreshRunnerTarget {
    sandbox_id: string;
    boot_id: string;
    boot_generation: string;
    provisioning_intent_id: string;
    credential_id: string;
    observed_after: string;
    grant_id?: string;
}
export interface FreshRunnerObservation {
    credential_id: string;
    sandbox_id: string;
    boot_id: string;
    boot_generation: string;
    grant_id: string;
    provisioning_intent_id: string;
    heartbeat_at: string;
    observation_only: true;
    authority: 'NONE';
}
export interface MainSessionIdentityBinding {
    readonly organisation_id: string;
    readonly run_id: string;
    readonly session_id: string;
    readonly role: 'LEADER' | 'FEATURE_MANAGER';
    readonly placement: 'MAIN';
    readonly native_session_id: string;
    readonly registration_receipt_digest: string;
}
export interface MainSessionIdentityVerifier {
    verify(tx: PrimaryTransaction, scope: {
        organisation_id: string;
        run_id: string;
        session_id: string;
    }, invocation: InvocationContext): Promise<MainSessionIdentityBinding>;
}
export interface IdentityAuthority {
    installMainSessionVerifier(verifier: MainSessionIdentityVerifier): void;
    sealTrustedRegistrations(): void;
    verifyFreshRunner(i: InvocationContext, tx: IdentityTransaction, target: FreshRunnerTarget): Promise<FreshRunnerObservation>;
    readonly origin: string;
    guard(tx: IdentityTransaction, p: Principal): Promise<void>;
    authenticate(body: Buffer, headers: readonly string[], signal: AbortSignal): Promise<InvocationContext>;
    enroll(body: Buffer, headers: readonly string[], signal: AbortSignal): Promise<unknown>;
    authorize(i: InvocationContext): Promise<void>;
}
export declare function invocationOf(ctx: ComponentContext): InvocationContext;
export declare function gatewayOf(ctx: ComponentContext): IdentityGateway;
export declare function isIdentityAuthority(v: unknown): v is IdentityAuthority;
export declare function assertCurrentPrincipal(tx: IdentityTransaction, p: Principal, authority: GlobalIdentityAuthority): Promise<void>;
export declare function continuationInvocation(i: InvocationContext, validatePersistedAdmission: (tx: IdentityTransaction, invocation: InvocationContext) => Promise<void>): InvocationContext;
export declare function identityTransaction<T>(ctx: ComponentContext, operation: (tx: IdentityTransaction, i: InvocationContext) => Promise<T>): Promise<T>;
export declare function recorded<T>(tx: IdentityTransaction, scope: string, name: string, op: Operation, action: () => Promise<T>): Promise<T>;
export declare function createComponent(ctx: ComponentContext): Promise<Component>;
