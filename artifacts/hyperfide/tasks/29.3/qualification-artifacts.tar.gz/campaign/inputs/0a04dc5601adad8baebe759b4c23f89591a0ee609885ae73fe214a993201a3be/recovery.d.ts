import type { Component, ComponentContext } from '../components/registry.js';
import { type Data } from './audit.js';
export declare const RECOVERY_ACTIONS: readonly ['retry_same', 'refresh_context', 'repair_environment', 'change_frontier_profile', 'manager_review', 'insufficient_evidence'];
export declare function recoveryAdvice(value: unknown, state: Data): Data;
export declare function recoveryFallback(state: Data, reason: string): Data;
export declare function recoveryRepeat(prior: Data | null, state: Data): {
    prior_failure_evidence: Data | null;
    changed_conditions: string[];
};
export declare function createComponent(ctx: ComponentContext): Component;
