import type { KeyObject } from 'node:crypto';
import type { Component, ComponentContext } from './components/registry.js';
export declare const BASELINE_INTERVAL_SECONDS = 600;
export declare const WATCHER_CALLS: readonly [readonly ["14.1", "identity.describe"], readonly ["finding-github", "finding.github.reconcile"], readonly ["finding-github", "finding.github.due"], readonly ["finding-github", "finding.github.dispatch"], readonly ["finding-github", "finding.github.process-delivery"]];
export declare const WATCHER_ACTIONS: readonly ("finding.github.dispatch" | "finding.github.due" | "finding.github.process-delivery" | "finding.github.reconcile" | "identity.describe")[];
export interface WatchedRepository {
    repository_id: string;
    owner: string;
    repository: string;
}
export interface WatcherConfig {
    organisation_id: string;
    run_id: string;
    credential_id: string;
    key_file: string;
    ca_file: string;
    control_origin: string;
    repositories: WatchedRepository[];
    interval_seconds: number;
    cadence_amendment: {
        record_id: string;
        interval_seconds: number;
    } | null;
    due_limit: number;
    request_timeout_ms: number;
}
export interface CallOutcome {
    component: string;
    action: string;
    subject: string | null;
    outcome: 'CONFIRMED' | 'REFUSED' | 'UNCONFIRMED';
    code: string | null;
}
export interface PassReport {
    pass: number;
    confirmed: boolean;
    reconciled: string[];
    deferred: string[];
    calls: CallOutcome[];
}
/** Pure structural validation; file contents are only read by the launcher. */
export declare function validateWatcherConfig(value: unknown): WatcherConfig;
export declare class IssueWatcher {
    private readonly config;
    private readonly key;
    private readonly ca;
    private readonly signal;
    private verified;
    private passes;
    constructor(config: WatcherConfig, key: KeyObject, ca: Buffer, signal: AbortSignal);
    private call;
    private observed;
    /** One reconciliation pass. A refusal or unknown outcome is never reported as reconciliation. */
    pass(): Promise<PassReport>;
}
export declare function issueWatcherCommand(args: readonly string[], env: Readonly<NodeJS.ProcessEnv>, signal: AbortSignal, emit: (line: Record<string, unknown>) => void): Promise<number>;
export declare function createComponent(_context: ComponentContext): Component;
