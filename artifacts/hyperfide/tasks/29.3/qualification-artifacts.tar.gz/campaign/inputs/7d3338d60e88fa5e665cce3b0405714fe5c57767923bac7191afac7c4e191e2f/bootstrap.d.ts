export declare function bootstrapCommand(args: readonly string[], env?: Readonly<NodeJS.ProcessEnv>, signal?: AbortSignal): Promise<unknown>;
