import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { BoundProviderRequest } from '../providers/reconcile.js';
export type NativeControlAction = 'runner.observe' | 'runner.stop' | 'runner.pause' | 'runner.drain' | 'runner.cancel' | 'runner.resume';
/** Every action except observe is a coordinator command identified by command_id (task 12.4). */
export declare const NATIVE_CONTROL_ACTIONS: readonly NativeControlAction[];
export interface NativeRunnerRequest {
    session_id: string;
    operation_id: string;
    action: NativeControlAction;
    command_id?: string;
    launch_id?: string;
}
export interface NativeRunnerCapability {
    invokeNativeRunner(invocation: InvocationContext, input: NativeRunnerRequest, signal: AbortSignal): Promise<unknown>;
    authenticatePlacementProbe(invocation: InvocationContext, input: {
        probe_id: string;
    }, signal: AbortSignal): Promise<{
        request: BoundProviderRequest;
        invocation: InvocationContext;
    }>;
}
export declare function isNativeRunnerCapability(v: unknown): v is NativeRunnerCapability;
export interface NativeControlTarget {
    readonly launch_id: string;
    readonly attempt_id: string;
    readonly attempt_generation: string;
    readonly sandbox_id: string;
    readonly boot_id: string;
    readonly boot_generation: string;
    readonly uid: number;
}
export declare function validateNativeControlReceipt(value: unknown, target: NativeControlTarget, command_id?: string, action?: NativeControlAction): Record<string, unknown>;
export declare function createComponent(ctx: ComponentContext): Promise<Component>;
