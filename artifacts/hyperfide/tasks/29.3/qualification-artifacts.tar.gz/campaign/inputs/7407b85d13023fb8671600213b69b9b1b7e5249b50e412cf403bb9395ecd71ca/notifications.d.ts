import type { Component, ComponentContext } from '../components/registry.js';
import type { Session, Principal } from './views.js';
interface Outbox {
    bindSessionConsumer(tx: Session, input: {
        organisation_id: string;
        run_id: string;
        session_id: string;
        consumer_id: string;
        namespace: 'fleet_notification';
    }, invocation: unknown): Promise<{
        session_id: string;
        consumer_id: string;
        replayed: boolean;
        registered_actor_id: string;
    }>;
    enqueue(tx: Session, event: {
        organisation_id: string;
        run_id: string;
        id: string;
        aggregate_id: string;
        aggregate_type: string;
        aggregate_version: string;
        event_type: string;
        payload: Record<string, unknown>;
    }, options: {
        consumer_ids: string[];
    }): Promise<unknown>;
}
interface InboxBootstrap {
    bootstrapConsumer(tx: Session, input: {
        organisation_id: string;
        run_id: string;
        bootstrap_id: string;
        consumer_id: string;
        aggregate_types: string[];
        limit: number;
    }, builder: (tx: Session) => Promise<unknown>): Promise<unknown>;
}
export declare function bootstrapRecipient(tx: Session, p: Principal, input: unknown, inbox: InboxBootstrap): Promise<unknown>;
export declare function bindRecipient(tx: Session, p: Principal, input: unknown, outbox: Outbox, invocation: unknown): Promise<unknown>;
export declare function enqueueNotice(tx: Session, p: Principal, input: unknown, knownSecrets?: readonly string[]): Promise<unknown>;
export declare function dispatchNotices(tx: Session, p: Principal, input: unknown, outbox: Outbox, budget: number): Promise<unknown>;
export declare function createComponent(startup: ComponentContext): Component;
export {};
