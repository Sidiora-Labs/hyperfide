import type { Component, ComponentContext } from '../components/registry.js';
import type { Data, PrimaryClient } from './submission.js';
export declare function claimJob(ctx: ComponentContext, raw: unknown): Promise<Data>;
/** Refuses provider results that are not the admitted check: an unrelated command's zero exit cannot stand in for it. */
export declare function assertRemoteBinding(raw: Data, expected: {
    plan: Data;
    observed: Data;
    check: Data;
    snapshot: Data;
    sandbox_id: string;
    scope: [string, string];
}): void;
/** Complete command/environment/exit record retained for every executed check, passing or not. */
export declare function commandRecord(check: Data, plan: Data, observed: Data, raw: Data): Data;
/** A check passes only on an affirmative, complete observation; unknown or absent fields fail with visible reasons. */
export declare function judgeCheck(raw: Data, requiredArtifacts: readonly string[], files: readonly Data[]): {
    outcome: 'PASS' | 'FAIL';
    reasons: string[];
};
/** Receipt outcome over the exact registered selection: missing, duplicate, unknown, failed or stale checks never PASS. */
export declare function qualificationOutcome(required: readonly string[], results: readonly Data[], sourceObjectId: string): {
    outcome: 'PASS' | 'FAIL';
    unmet: Data[];
};
/** Policy or inputs that changed after admission make the run stale; its gate result is never recorded. */
export declare function assertSnapshotCurrent(admitted: {
    policy: unknown;
    inputs: unknown;
}, current: {
    policy: unknown;
    inputs: unknown;
}): void;
/** Orchestrates actual remote sessions. No command or Git checkout runs on control. */
export declare function runRegisteredChecks(ctx: ComponentContext, job: Data, snapshot: Data): Promise<Data>;
export declare function verifyStoredReceiptArtifacts(ctx: ComponentContext, s: [string, string], receipt: Data): Promise<void>;
export declare function verifyReceiptRecordArtifacts(ctx: ComponentContext, s: [string, string], record: Data): Promise<void>;
export declare function inspectExecutionReceipt(db: PrimaryClient, s: {
    organisation_id: string;
    run_id: string;
}, jobId: string, generation: string): Promise<Data>;
/** Read-only access to actual server-owned verifier execution observations.
 * This does not grant task qualification or authenticate privileged migration jobs. */
export declare function inspectExecution(ctx: ComponentContext, raw: unknown): Promise<Data>;
/** Names what a legacy claim asserts. Every signal stays historical: none is a gate receipt or releases dependent work. */
export declare function classifyLegacyClaim(claim: unknown): Data;
/** Distinguishes forced historical task status and imported claims from current server-executed evidence. */
export declare function inspectQualificationHistory(db: PrimaryClient, s: {
    organisation_id: string;
    run_id: string;
}, taskId: string): Promise<Data>;
export declare function createComponent(ctx: ComponentContext): Component & {
    capabilities: Record<string, unknown>;
};
