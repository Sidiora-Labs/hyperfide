import type { Component, ComponentContext } from '../../components/registry.js';
import type { ProviderScope, ResourceRef, ProviderOperation, ProviderOutcome } from '../contract.js';
import type { BlaxelAdapter } from './processes.js';
export type BlaxelPreviewFeature = 'environment_updates' | 'shared_storage' | 'memory_snapshot' | 'memory_fork';
export interface BlaxelPreviewEvidence {
    schema_version: 1;
    feature: BlaxelPreviewFeature;
    scope: ProviderScope;
    sdk_version: string;
    status: 'QUALIFIED';
    observed_at: string;
    expires_at: string;
    evidence_digest: string;
}
export interface BlaxelRecoveryDependencies {
    /** Reads authoritative qualification rows under the actual invocation guard.
     * A model-supplied object or arbitrary JSON evidence cannot install this closure. */
    readQualification(scope: ProviderScope, feature: BlaxelPreviewFeature): Promise<BlaxelPreviewEvidence | null>;
    assertScope(scope: ProviderScope): Promise<void>;
    assertFreshEnrollment(scope: ProviderScope, resource: ResourceRef): Promise<{
        boot_credential_version: string;
        enrollment_digest: string;
    }>;
}
export declare function validateBlaxelPreviewEvidence(input: unknown, scope: ProviderScope, feature: BlaxelPreviewFeature, now: number): BlaxelPreviewEvidence;
export declare function blaxelRecoveryPolicy(): unknown;
export declare function planBlaxelRecovery(input: unknown): unknown;
export declare function createBlaxelRecoveryController(scope: ProviderScope, deps: BlaxelRecoveryDependencies): Readonly<{
    verifyFreshEnrollment: (resource: ResourceRef) => Promise<{
        boot_credential_version: string;
        enrollment_digest: string;
    }>;
    negotiate(feature: BlaxelPreviewFeature): Promise<{
        enabled: true;
        evidence_digest: string;
    }>;
    createFresh(adapter: BlaxelAdapter, operation: ProviderOperation<'create'>): Promise<{
        outcome: ProviderOutcome<'create'>;
        enrollment: 'PENDING' | 'VERIFIED';
        enrollment_digest: string | null;
        outward_action_authorized: false;
    }>;
}>;
export declare function createComponent(ctx: ComponentContext): Component;
