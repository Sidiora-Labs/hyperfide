import { runService } from './components/service.js';
await runService('provisioner');
//# sourceMappingURL=provisioner.js.map