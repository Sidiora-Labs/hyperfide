import type pg from 'pg';
import type { Component, ComponentContext } from '../components/registry.js';
export interface DB {
    query<Row extends pg.QueryResultRow = any>(text: string, values?: unknown[]): Promise<pg.QueryResult<Row>>;
}
interface IntegrationInvocation {
    context: ComponentContext;
    invocation: unknown;
}
export declare function runnerRemote(context: ComponentContext): Promise<{
    prepare: (db: DB, invocation: unknown, plan: Record<string, unknown>) => Promise<unknown>;
    execute: (permit: unknown, signal: AbortSignal) => Promise<Record<string, any>>;
    recover?: (db: DB, invocation: unknown, plan: Record<string, unknown>) => Promise<unknown>;
}>;
export declare function bindScope(ctx: ComponentContext, component: Component): Component;
export declare function currentInvocation(): IntegrationInvocation;
export declare function prepareRemote(db: DB, plan: Record<string, unknown>): Promise<{
    remote: Awaited<ReturnType<typeof runnerRemote>>;
    permit: unknown;
    plan: Record<string, unknown>;
    expected_source_object_id?: string | undefined;
    expected_source_tree_id?: string | undefined;
}>;
export declare function snapshotRemote(prepared: Awaited<ReturnType<typeof prepareRemote>>): Record<string, unknown>;
export declare function restoreRemote(db: DB, snapshot: unknown): Promise<Awaited<ReturnType<typeof prepareRemote>>>;
export declare function executeRemote(prepared: Awaited<ReturnType<typeof prepareRemote>>): Promise<Record<string, any>>;
export interface Scope {
    organisation_id: string;
    run_id: string;
}
export declare function fail(code: string, message: string): never;
export declare function obj(v: unknown): Record<string, unknown>;
export declare function keys(v: Record<string, unknown>, required: string[], optional?: string[]): void;
export declare function uuid(v: unknown): string;
export declare function oid(v: unknown): string;
export declare function digest(v: unknown): string;
export declare function decimal(v: unknown): string;
export declare function scope(v: Record<string, unknown>): Scope;
export declare function canonical(v: unknown): string;
export declare const hash: (v: string | Buffer) => string;
export declare function values(s: Scope): string[];
export declare function semanticDisposition(db: DB, s: {
    organisation_id: string;
    run_id: string;
}, mode: 'READ' | 'WRITE'): Promise<void>;
export declare function tx<T>(_pool: unknown, fn: (db: DB) => Promise<T>, mode?: 'READ' | 'WRITE'): Promise<T>;
/** Detached reads still use the genuine current primary guard. This facade is
 * never accepted as a branded transaction or held across remote/Git work. */
export declare function primaryClient(): DB;
export declare function prepareRemoteGate(db: DB, s: Scope, request: {
    session_id: string;
    reservation_id: string;
    repository_id: string;
    input_digest: string;
    policy_digest: string;
    gate: GateConfig;
    mode: 'CANDIDATE' | 'WAVE' | 'PROGRAMME';
    candidate_head?: string;
    snapshot?: Record<string, any>;
}): Promise<Awaited<ReturnType<typeof prepareRemote>>>;
export interface AdmittedIntegrationWork {
    kind: 'CANDIDATE' | 'SCOPE' | 'PREPARATION';
    id: string;
}
export declare function currentRun(db: DB, s: Scope, lock?: boolean, admittedPublicationId?: string, observe?: boolean, admittedWork?: AdmittedIntegrationWork): Promise<Record<string, any>>;
export interface GateConfig {
    id: string;
    kind: 'build' | 'test';
    argv: string[];
    timeout_ms: number;
    proof: {
        manifest_path: string;
        manifest_digest: string;
        registry_path: string;
        registry_digest: string;
        expected_assertion_ids: string[];
        case_ids: string[];
    };
}
export interface RepositoryConfig {
    repository_id: string;
    path: string;
    target_ref: string;
    receive_path?: string;
    gates: GateConfig[];
    review_policy_digest: string;
    review_rubrics: string[];
    required_graph: boolean;
}
export interface IntegrationConfig {
    version: 1;
    organisation_id: string;
    root: string;
    repositories: RepositoryConfig[];
    closure: Record<string, unknown>;
}
export declare function config(env: Readonly<NodeJS.ProcessEnv>): Promise<IntegrationConfig>;
export declare function safeDirectory(root: string, directory: string): Promise<string>;
export declare function repository(c: IntegrationConfig, id: string): RepositoryConfig;
export declare function git(directory: string, args: string[], env?: NodeJS.ProcessEnv): Promise<string>;
/** Publication runs from a fresh private client Git directory. Source-owned
 * config cannot rewrite the target, invoke transports, or redirect credentials. */
export declare function isolatedPush(repositoryPath: string, args: string[], environment: Readonly<NodeJS.ProcessEnv>, transport: 'file' | 'https'): Promise<{
    stdout: string;
    stderr: string;
}>;
export declare function custody(db: DB, s: Scope, id: string, expectedGeneration?: string): Promise<Record<string, any>>;
export interface CandidateManifest {
    version: 1;
    request_id: string;
    run_id: string;
    spec_revision_id: string;
    spec_generation: string;
    policy_digest: string;
    authority_epoch: string;
    repository_id: string;
    branch_authority_id: string;
    branch_generation: string;
    target_ref: string;
    expected_old_head: string;
    candidate_head: string;
    tree: string;
    parents: string[];
    git_provenance_manifest: Record<string, unknown>;
    git_provenance_manifest_digest: string;
    contributors: {
        custody_id: string;
        custody_generation: string;
        task_id: string;
        source_object_id: string;
        criteria_digest: string;
        source_manifest_digest: string;
        evidence_manifest_digest: string;
        proof_criteria_digest: string;
        qualification_receipt_digest: string;
        proof_source_manifest_digest: string;
    }[];
    commit_set: {
        repository_id: string;
        candidate_head: string;
        expected_old_head: string;
    }[];
    execution_session_id: string;
    execution_receipt_digest: string;
    declared_context: {
        environment_digest: string;
        contract_digest: string;
        authority: 'UNVERIFIED_CALLER_LABELS';
    };
    context_authority: 'IMMUTABLE_REVIEW_INPUT_BINDINGS';
    required_gates: GateConfig[];
    review_policy_digest: string;
    review_rubrics: string[];
    required_graph: boolean;
    review_sources: string[];
}
export declare function readCandidate(db: DB, s: Scope, id: string, lock?: boolean): Promise<{
    row: Record<string, any>;
    manifest: CandidateManifest;
}>;
type ReviewPhase = 'ADMISSION' | 'CURRENT_PUBLISHED';
export declare function reviewCoverage(db: DB, s: Scope, m: CandidateManifest, inputDigest: string, candidateId: string, phase?: ReviewPhase): Promise<{
    digest: string;
    observations: Record<string, any>[];
}>;
/** Latest recorded remote outcome per required gate for this exact immutable
 * manifest. A FAIL is a rejection of the combined commit set, independent of
 * the historical PASS receipts of its individually qualified contributors. */
export declare function gateOutcomes(db: DB, s: Scope, id: string, row: Record<string, any>, m: CandidateManifest): Promise<Record<string, any>[]>;
export declare function commitSetEvidence(row: Record<string, any>, m: CandidateManifest): Record<string, unknown>;
export declare function candidateReady(db: DB, s: Scope, id: string, admittedPublicationId?: string): Promise<{
    row: Record<string, any>;
    manifest: CandidateManifest;
}>;
export declare function createComponent(ctx: ComponentContext): Component;
export {};
