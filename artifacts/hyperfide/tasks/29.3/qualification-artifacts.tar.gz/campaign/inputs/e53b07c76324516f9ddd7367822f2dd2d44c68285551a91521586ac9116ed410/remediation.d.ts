import type { Component, ComponentContext } from '../components/registry.js';
import type { FindingScope, FindingTransaction } from './registry.js';
export declare function inspectFindingResolution(tx: FindingTransaction['tx'], scope: FindingScope, findingId: string): Promise<{
    current: boolean;
    reason?: string;
}>;
export declare function createComponent(_context: ComponentContext): Component;
