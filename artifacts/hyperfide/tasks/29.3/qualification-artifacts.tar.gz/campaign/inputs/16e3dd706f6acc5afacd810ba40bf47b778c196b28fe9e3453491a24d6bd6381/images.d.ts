import type { Component, ComponentContext } from '../../components/registry.js';
import type { PreparationManifest } from '../../preparation/manifests.js';
import type { ProviderOutcome } from '../contract.js';
export declare const BLAXEL_PINS: Readonly<{
    sdk: "0.3.30";
    cli: "0.1.127";
    linux_x86_64_archive_sha256: "a23b387dd309cd37ba381ad9383efe124bad306347c058a6bad2803cffb3b900";
}>;
interface ImageRecipe {
    name: string;
    base_image: string;
    sandbox_api_image: string;
    sandbox_api_version: string;
    install_script: string;
    slim: false;
    build_memory_mib: number;
    build_volume_mib: number;
    build_region: string;
    timeout_seconds: number;
}
interface StoragePlan {
    overlay_bytes: string;
    reserved_memory_bytes: string;
    headroom_bytes: string;
    volume: null | {
        reference: string;
        mount_path: string;
        size_bytes: string;
        template_revision: string;
        template_path: string;
    };
    writable_paths: Array<{
        path: string;
        backend: 'overlay' | 'volume';
        required_bytes: string;
    }>;
    required_paths: Array<{
        path: string;
        source: 'image' | 'volume';
    }>;
}
interface PackageProbe {
    ecosystem: 'node' | 'python';
    name: string;
    version: string;
}
interface ProbeRequirements {
    packages: PackageProbe[];
    compile_c: boolean;
}
export interface BlaxelImagePlan {
    schema_version: 1;
    preparation_digest: string;
    manifest: PreparationManifest;
    image: ImageRecipe;
    storage: StoragePlan;
    probe_requirements: ProbeRequirements;
    recipe: {
        dockerfile: string;
        blaxel_toml: string;
    };
    plan_digest: string;
}
export declare function planBlaxelImage(value: unknown, ctx: ComponentContext): Promise<BlaxelImagePlan>;
export declare function validateBlaxelImagePlan(value: unknown): BlaxelImagePlan;
interface ProcessObservation {
    exit_code: number | null;
    stdout: string;
    stderr: string;
    timed_out: boolean;
}
export declare const BLAXEL_SUPERVISOR_PYTHON: string;
export declare function runBlaxelCommand(argv: string[], cwd: string, env: NodeJS.ProcessEnv, timeout: number, signal: AbortSignal): Promise<ProcessObservation>;
export declare function blaxelCredentials(ctx: Pick<ComponentContext, 'env'>): {
    workspace: string;
    apiKey: string;
};
export interface BlaxelRuntimeSDK {
    settings: {
        readonly baseUrl: string;
        readonly runUrl: string;
        setConfig(config: {
            apiKey: string;
            workspace: string;
            maxConcurrentH2Requests: number;
            maxConcurrentUploadH2Requests: number;
            fsPartRetries: number;
            sandboxReadRetries: number;
            integration: string;
        }): void;
    };
    SandboxInstance: {
        get(name: string): Promise<{
            process: {
                exec(request: {
                    command: string;
                    workingDir: string;
                    waitForCompletion: boolean;
                    timeout: number;
                    keepAlive: boolean;
                }): Promise<unknown>;
            };
        }>;
    };
}
export declare function configuredBlaxelSDK(ctx: Pick<ComponentContext, 'env'>): Promise<BlaxelRuntimeSDK>;
export declare function inspectBlaxelImage(value: unknown, ctx: ComponentContext): Promise<unknown>;
export declare function blaxelImageOperationReference(plan: BlaxelImagePlan): string;
export declare function publishBlaxelImage(value: unknown, ctx: ComponentContext): Promise<ProviderOutcome<'prepare'>>;
export declare function createComponent(_ctx: ComponentContext): Component;
export {};
