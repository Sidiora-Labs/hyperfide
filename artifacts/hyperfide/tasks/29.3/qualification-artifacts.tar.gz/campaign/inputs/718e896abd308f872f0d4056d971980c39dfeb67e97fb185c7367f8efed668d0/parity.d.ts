import type { ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
type Json = Record<string, unknown>;
/** Parity only ever reads; any gateway session or transaction satisfies this. */
export interface ParityReader {
    query(sql: string, values?: unknown[]): Promise<{
        rows: Record<string, any>[];
    }>;
}
interface Scope {
    organisation_id: string;
    run_id: string;
}
export interface ParityReport {
    schema_version: 1;
    import_id: string;
    snapshot_digest: string;
    history_digest: string;
    counts: {
        table: string;
        source: string | null;
        archive: string | null;
        history: string;
    }[];
    samples: {
        table: string;
        offset: string;
        mapped_id: string;
        payload_digest: string;
        history: boolean;
        live: boolean;
    }[];
    source: Json;
    git: Json;
    artifacts: Json;
    mismatches: string[];
    outcome: 'MATCHED' | 'MISMATCHED';
    writable: false;
    authority: 'NONE';
    shadow_digest: string;
}
/** Run-scoped digest over every imported history row; a later mutation must observe the same value. */
export declare function historyDigest(tx: ParityReader, importId: string): Promise<string>;
/** Count, semantic-sample, live-source, Git and artifact reconciliation for one
 * historical import. Every statement here is a read; callers that only shadow the
 * result run it in a READ ONLY transaction so no write path exists at all. */
export declare function compareParity(tx: ParityReader, ctx: ComponentContext, i: InvocationContext, scope: Scope, importId: string): Promise<ParityReport>;
/** Read-only shadow comparison in the gateway's primary REPEATABLE READ READ ONLY
 * transaction: PostgreSQL refuses any write, so shadowing cannot create a second
 * writable authority. */
export declare function shadowCompare(ctx: ComponentContext, i: InvocationContext, scope: Scope, importId: string): Promise<ParityReport>;
export {};
