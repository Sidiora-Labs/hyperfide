import pg from 'pg';
import type { Component, ComponentContext } from '../components/registry.js';
import { FoundationError } from '../policy/programme.js';
export declare const AUTHORITY_SCHEMA = "hyperfide";
export declare const AUTHORITY_SCHEMA_VERSION = 1;
export declare const AUTHORITY_TABLES: readonly ["organisations", "projects", "repositories", "source_objects", "spec_revisions", "runs", "run_spec_revisions", "run_repositories", "feature_packages", "tasks", "task_dependencies", "environment_profiles", "provider_pools", "capacity_accounts", "reservations", "sandboxes", "sandbox_boots", "worker_slots", "attempts", "compute_leases", "slot_allocations", "agent_sessions", "preparation_references", "workspaces", "branch_observations", "branch_authorities", "artifacts", "artifact_dependencies", "checkpoints", "evidence", "evidence_artifacts", "submission_custodies", "submission_evidence", "qualification_jobs", "requalification_operations", "integration_candidates", "candidate_evidence", "candidate_custodies", "publication_intents", "publication_operations", "contracts", "findings", "finding_observations", "review_coverage", "review_coverage_inputs", "graph_builds", "graph_manifests", "graph_channels", "parse_blobs", "graph_files", "graph_symbols", "graph_references", "graph_edges", "command_inbox", "event_consumers", "outbox_events", "event_deliveries"];
export interface StorageConfig {
    connectionString: string;
    max: number;
    connectionTimeoutMillis: number;
    idleTimeoutMillis: number;
    statementTimeoutMillis: number;
    lockTimeoutMillis: number;
}
export interface SchemaReceipt {
    schema: string;
    schema_version: number;
    checksum: string;
    applied: boolean;
    tables: string[];
}
export interface SchemaInspection {
    schema: string;
    schema_version: number;
    checksum: string;
    tables: string[];
    foreign_key_count: number;
    index_count: number;
    in_recovery: boolean;
}
export declare function storageConfig(env: Readonly<NodeJS.ProcessEnv>): StorageConfig;
export declare function createStoragePool(config: StorageConfig): pg.Pool;
/** Registry owns the process pool lifecycle while legacy callers retain the stable facade. */
export declare function bindStoragePool(provider: (env: Readonly<NodeJS.ProcessEnv>) => pg.Pool): () => void;
/** Stable process resource seam; task4.2 owns the later shared lifecycle. */
export declare function getPool(env: Readonly<NodeJS.ProcessEnv>): pg.Pool;
export declare function closePool(): Promise<void>;
export declare function databaseError(error: unknown): FoundationError;
export declare function bootstrapAuthoritySchema(pool: pg.Pool): Promise<SchemaReceipt>;
export declare function inspectAuthoritySchema(pool: pg.Pool): Promise<SchemaInspection>;
export declare function createComponent(context: ComponentContext): Component;
