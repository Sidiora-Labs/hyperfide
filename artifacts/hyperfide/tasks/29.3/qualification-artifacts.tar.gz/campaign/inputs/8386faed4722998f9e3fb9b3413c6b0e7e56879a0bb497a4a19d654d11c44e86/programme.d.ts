import type { Component, ComponentContext } from '../components/registry.js';
export type ServiceRole = 'control' | 'provisioner' | 'dispatch';
export interface ProgrammePolicy {
    schema_version: 1;
    programme_id: string;
    repository: string;
    spec_revision: string;
    policy_revision: number;
    status: 'ACTIVE';
    approval: {
        decision: 'APPROVED';
        record_id: string;
        spec_revision: string;
        policy_revision: number;
    };
    allowed_roles: readonly ServiceRole[];
    allowed_actions: readonly string[];
}
export declare class FoundationError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare function object(value: unknown): value is Record<string, unknown>;
export declare function validatePolicy(value: unknown, expectedRevision: string, role: ServiceRole): ProgrammePolicy;
export declare function assertAdmission(policy: ProgrammePolicy, role: ServiceRole, action: string): void;
export declare function createComponent(_context: ComponentContext): Component;
