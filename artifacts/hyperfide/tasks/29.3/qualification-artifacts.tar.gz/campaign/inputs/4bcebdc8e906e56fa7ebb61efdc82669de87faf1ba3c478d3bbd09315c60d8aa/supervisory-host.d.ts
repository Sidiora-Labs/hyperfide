/** Structural validation of the host contract; the Python host re-validates ownership and kernel state. */
export declare function validateSupervisoryHostConfig(value: unknown): Record<string, unknown>;
export interface SupervisoryLaunch {
    python: string;
    script: string;
    config: string;
    config_sha256: string;
    argv: string[];
    env: Record<string, string>;
}
export declare function prepareSupervisoryHost(args: readonly string[], env: Readonly<NodeJS.ProcessEnv>): Promise<SupervisoryLaunch>;
export declare function supervisoryHostCommand(args: readonly string[], env: Readonly<NodeJS.ProcessEnv>, signal: AbortSignal): Promise<number>;
