import type { Component, ComponentContext } from '../components/registry.js';
import type { PrimaryTransaction } from '../storage/transactions.js';
import type { ComputeToken, SchedulerActor, SchedulerScope } from './claim.js';
export interface ComputeAuthority extends ComputeToken {
    compute_lease_id: string;
    lease_expires_at: string;
    primary_now: string;
    feature_package_id: string;
    input_packet_digest: string;
    spec_revision_id: string;
    spec_generation: string;
    criteria_digest: string;
    preparation_digest: string | null;
}
export declare function parseComputeToken(value: unknown): ComputeToken;
/** Only a branded, live primary transaction may validate current compute authority. */
export declare function assertCurrentCompute(tx: PrimaryTransaction, token: ComputeToken, options?: {
    allowExpired?: boolean;
    operation?: 'ADMISSION' | 'RENEWAL' | 'CHECKPOINT' | 'ADVANCE' | 'CLEANUP';
}): Promise<ComputeAuthority>;
export declare function renewCompute(tx: PrimaryTransaction, token: ComputeToken, lease_ms: number): Promise<unknown>;
/**
 * Submission transfers logical compute only. Physical allocation remains counted
 * until a separate trusted cleanup observation establishes quiescence.
 */
export declare function releaseCompute(tx: PrimaryTransaction, token: ComputeToken, disposition: {
    execution_state: 'SUBMITTED' | 'CANCELLED';
}): Promise<void>;
export declare function lockComputeFenceTargets(tx: PrimaryTransaction, tokens: readonly ComputeToken[]): Promise<void>;
export interface ComputeFenceOptions {
    actor: SchedulerActor;
    current_authority_epoch: string;
    reason: 'SPEC_REPLAN' | 'STOP' | 'EXPIRED' | 'LOST';
    recipients: {
        consumer_ids: string[];
    };
}
export declare function fenceCompute(tx: PrimaryTransaction, token: ComputeToken, options: ComputeFenceOptions): Promise<unknown>;
export declare function expireCompute(tx: PrimaryTransaction, scope: SchedulerScope, actor: SchedulerActor, authority_epoch: string, limit?: number, recipients?: {
    consumer_ids: string[];
}): Promise<unknown>;
/** Trusted offline recovery primitive. The caller validates external authority and
 * holds the semantic WRITE fence, then persists these debt references and performs
 * the run epoch CAS in this same transaction. This never proves process cleanup. */
export declare function revokeRunForRecovery(tx: PrimaryTransaction, input: SchedulerScope & {
    expected_run_epoch: string;
    target_epoch: string;
    recovery_operation_id: string;
}): Promise<{
    revoked_attempts: string;
    revoked_allocations: string;
    retained_debt_references: readonly string[];
}>;
export declare function createComponent(context: ComponentContext): Component;
export type { ComputeToken } from './claim.js';
