import type { Component, ComponentContext } from '../components/registry.js';
/** Compatibility reads never claim an execution grant, status mutation or proof. */
export declare function createComponent(context: ComponentContext): Component;
