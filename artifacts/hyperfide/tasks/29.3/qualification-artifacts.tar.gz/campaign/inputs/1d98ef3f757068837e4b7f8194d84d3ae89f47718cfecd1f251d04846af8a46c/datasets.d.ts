import type { Component, ComponentContext } from '../components/registry.js';
export type Obj = Record<string, unknown>;
export type EvidenceClass = 'live' | 'synthetic';
export declare function fail(message: string): never;
export declare function fields(value: unknown, required: string[], optional?: string[]): Obj;
export declare function text(value: unknown, max?: number): string;
export declare function id(value: unknown): string;
export declare function finite(value: unknown, min?: number, max?: number): number;
export declare function integer(value: unknown, min?: number, max?: number): number;
export declare function list(value: unknown, min?: number, max?: number): unknown[];
export declare function strings(value: unknown, min?: number, max?: number): string[];
export declare function time(value: unknown): string;
export declare function hash(value: unknown): string;
export declare function canonical(value: unknown): string;
export declare function digest(value: unknown): string;
export interface Verified {
    payload: Obj;
    key: string;
    evidence_class: EvidenceClass;
    observed_at: string;
    receipt_digest: string;
}
export declare function attestation(context: ComponentContext, value: unknown, kind: string): Verified;
export interface Artifact<T = Obj> {
    schema_version: 1;
    kind: string;
    payload: T;
}
export declare class EvaluationStore {
    private context;
    constructor(context: ComponentContext);
    private directory;
    put<T>(kind: string, payload: T): Promise<string>;
    get<T = Obj>(identity: unknown, kind: string): Promise<T>;
}
export interface Packet {
    case_id: string;
    incident_id: string;
    feature_id: string;
    repository_id: string;
    purpose: string;
    decision_at: string;
    watermark: string;
    choices: string[];
    language: string;
    task_family: string;
    context_tokens: number;
    sources: {
        source_id: string;
        available_at: string;
        event_sequence: string;
        content_digest: string;
        content: string;
        kind: string;
    }[];
}
export interface DatasetRow {
    packet: Packet;
    target: string | null;
    split: 'train' | 'calibration' | 'holdout';
    packet_digest: string;
    label_digest: string;
    evidence_class: EvidenceClass;
    label_kind: string;
    label_key: string;
    group_id: string;
}
export interface Dataset {
    name: string;
    purpose: string;
    split_seed: string;
    rows: DatasetRow[];
    holdout_digest: string;
    evidence_class: 'live' | 'synthetic' | 'mixed';
    counts: Record<string, number>;
    group_count: number;
}
export declare function buildDataset(input: unknown, context: ComponentContext): Promise<Obj>;
export declare function createComponent(_context: ComponentContext): Component;
