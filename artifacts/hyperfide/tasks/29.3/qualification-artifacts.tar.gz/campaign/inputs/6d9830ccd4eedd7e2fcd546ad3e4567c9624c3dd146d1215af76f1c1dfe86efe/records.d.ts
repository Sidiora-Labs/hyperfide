/**
 * Wire contracts for PostgreSQL authority metadata. Git and object storage retain
 * payload ownership; these records identify the exact objects being admitted.
 */
export type UUID = string;
export type Digest = string;
export type Generation = string;
export interface Scope {
    organisation_id: UUID;
    run_id: UUID;
}
export interface SourceReference extends Scope {
    repository_id: UUID;
    source_object_id: string;
}
export interface ArtifactReference extends Scope {
    id: UUID;
    digest: Digest;
    size_bytes: string;
    storage_key: string;
    status: 'PENDING' | 'COMPLETE' | 'QUARANTINED' | 'DELETED';
    storage_backend: string;
    retention_class: 'EPHEMERAL' | 'RUN' | 'RELEASE' | 'LEGAL_HOLD';
}
export interface ComputeAuthorityToken extends Scope {
    task_id: UUID;
    attempt_id: UUID;
    attempt_generation: Generation;
    authority_epoch: UUID;
    sandbox_id: UUID;
    sandbox_boot_generation: Generation;
}
export interface CustodyAuthorityToken extends Scope {
    task_id: UUID;
    submission_id: UUID;
    custody_generation: Generation;
    authority_epoch: UUID;
}
export interface OrganisationRecord {
    id: UUID;
    name: string;
}
export interface ProjectRecord {
    organisation_id: UUID;
    id: UUID;
    name: string;
}
export interface RepositoryRecord extends ProjectRecord {
    project_id: UUID;
    url: string;
    object_format: 'sha1' | 'sha256';
}
export interface SpecRevisionRecord {
    organisation_id: UUID;
    project_id: UUID;
    id: UUID;
    source_digest: Digest;
    source_content: string;
    document: Record<string, unknown>;
    schema_version: number;
    repository_id?: UUID;
    git_object_id?: string;
}
export interface RunRecord {
    organisation_id: UUID;
    id: UUID;
    project_id: UUID;
    spec_revision_id: UUID;
    policy_digest: Digest;
    authority_epoch: UUID;
    state: string;
    spec_generation: Generation;
    state_version: Generation;
}
export interface TaskRecord extends Scope {
    id: UUID;
    task_key: string;
    feature_package_id: UUID;
    spec_revision_id: UUID;
    spec_generation: Generation;
    criteria_digest: Digest;
    definition: Record<string, unknown>;
    wave: number;
    state: string;
    generation: string;
    state_version: Generation;
}
export interface AttemptRecord extends Scope {
    id: UUID;
    task_id: UUID;
    generation: Generation;
    authority_epoch: UUID;
    input_packet_digest: Digest;
    kind?: string;
    execution_state?: string;
    compute_authority?: string;
    sandbox_id?: UUID | null;
    slot_id?: UUID | null;
    sandbox_boot_generation?: Generation | null;
    lease_expires_at?: string | null;
    state_version?: Generation;
}
export interface ComputeLeaseRecord extends Scope {
    id: UUID;
    attempt_id: UUID;
    attempt_generation: Generation;
    authority_epoch: UUID;
    sandbox_boot_generation: Generation;
    expires_at: string;
    state?: string;
    state_version?: Generation;
}
export interface SubmissionCustodyRecord extends Scope {
    id: UUID;
    task_id: UUID;
    source_attempt_id: UUID;
    source_generation: Generation;
    custody_generation: Generation;
    authority_epoch: UUID;
    repository_id: UUID;
    source_object_id: string;
    source_manifest_digest: Digest;
    evidence_manifest_digest: Digest;
    criteria_digest: Digest;
    authority?: string;
    qualification_outcome?: string;
    state_version?: Generation;
}
export interface EvidenceRecord extends SourceReference {
    id: UUID;
    attempt_id: UUID;
    attempt_generation: Generation;
    criteria_digest: Digest;
    manifest_digest: Digest;
    artifact_id: UUID;
    admission_state?: string;
    state_version?: Generation;
}
export interface QualificationJobRecord extends Scope {
    id: UUID;
    custody_id: UUID;
    custody_generation: Generation;
    rubric_digest: Digest;
    state?: string;
    lease_generation?: string;
    lease_owner?: UUID | null;
    lease_expires_at?: string | null;
    outcome?: string;
    state_version?: Generation;
}
export interface PublicationOperationRecord extends Scope {
    repository_id: UUID;
    id: UUID;
    publication_intent_id: UUID;
    candidate_id: UUID;
    branch_authority_id: UUID;
    branch_generation: Generation;
    authority_epoch: UUID;
    expected_old_head?: string | null;
    candidate_head: string;
    request_id: UUID;
    operation_generation?: Generation;
    state?: string;
    observed_head?: string | null;
    state_version?: Generation;
}
export declare class AuthorityRecordError extends Error {
    readonly code = "INVALID_RECORD";
    constructor(message: string);
}
type Validator = (value: unknown, path: string) => unknown;
export declare function recordObject(value: unknown, path?: string): Record<string, unknown>;
interface Definition {
    table: string;
    fields: Record<string, Validator>;
    required: string[];
}
export declare const CREATE_RECORDS: Readonly<Record<string, Definition>>;
export declare function parseCreateRecord(kind: unknown, value: unknown): {
    table: string;
    record: Record<string, unknown>;
};
export declare function validateAuthorityRecord(kind: unknown, value: unknown): Record<string, unknown>;
export declare function operationInput(value: unknown): {
    kind: unknown;
    record: unknown;
};
export interface ProviderPoolRecord {
    organisation_id: UUID;
    id: UUID;
    provider: string;
    account_key: string;
    environment_key: string;
    region: string;
    profile_id: UUID | null;
    state: 'ACTIVE' | 'DRAINING' | 'DISABLED';
    state_version: Generation;
}
export interface ReservationRecord extends Scope {
    id: UUID;
    request_id: UUID;
    capacity_account_id: UUID;
    quantity: string;
    attempt_id: UUID | null;
    expires_at: string;
    state: 'PROVISIONING' | 'ALLOCATED' | 'RELEASE_PENDING' | 'RELEASED';
    released_at: string | null;
    release_reason: string | null;
    state_version: Generation;
}
export interface SandboxRecord {
    organisation_id: UUID;
    id: UUID;
    pool_id: UUID;
    native_sandbox_id: string | null;
    desired_state: 'RUNNING' | 'STOPPED' | 'DESTROYED';
    observed_state: 'UNKNOWN' | 'CREATING' | 'RUNNING' | 'SUSPENDED' | 'STOPPED' | 'DESTROYING' | 'DESTROYED' | 'FAILED';
    boot_generation: Generation;
    preparation_digest: Digest | null;
    state_version: Generation;
}
export interface WorkerSlotRecord {
    organisation_id: UUID;
    id: UUID;
    sandbox_id: UUID;
    slot_key: string;
    boot_generation: Generation;
    capacity_kind: 'AGENT' | 'BUILD' | 'TEST' | 'INDEX' | 'REVIEW' | 'INTEGRATION';
    state: 'READY' | 'ALLOCATED' | 'DRAINING' | 'RETIRED';
    state_version: Generation;
}
export interface AgentSessionRecord extends Scope {
    id: UUID;
    role: 'LEADER' | 'FEATURE_MANAGER' | 'WORKER' | 'COMMIT_WATCHER' | 'ISSUE_WATCHER' | 'VERIFIER' | 'INTEGRATOR' | 'INDEXER';
    parent_session_id: UUID | null;
    connector: string;
    account_key: string;
    native_session_id: string;
    slot_id: UUID | null;
    sandbox_id: UUID | null;
    sandbox_boot_generation: Generation | null;
    attempt_id: UUID | null;
    state: 'REGISTERED' | 'RUNNING' | 'DISCONNECTED' | 'STOPPED' | 'FAILED';
    state_version: Generation;
}
export interface GraphBuildRecord extends Scope {
    id: UUID;
    input_digest: Digest;
    source_manifest_digest: Digest;
    parser_digest: Digest;
    schema_digest: Digest;
    config_digest: Digest;
    parent_build_id: UUID | null;
    state: 'STAGING' | 'RESOLVING' | 'VALIDATING' | 'READY' | 'PUBLISHED' | 'FAILED';
    state_version: Generation;
}
export interface GraphManifestRecord extends Scope {
    id: UUID;
    build_id: UUID;
    manifest_digest: Digest;
    source_manifest_digest: Digest;
    file_count: string;
    symbol_count: string;
    reference_count: string;
    edge_count: string;
    published_at: string;
}
export interface FindingRecord extends SourceReference {
    id: UUID;
    dedup_digest: Digest;
    owner_package_id: UUID;
    contract_id: UUID | null;
    severity: 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
    summary: string;
    state: 'OPEN' | 'ACKNOWLEDGED' | 'RESOLVED' | 'DISMISSED';
    state_version: Generation;
}
export {};
