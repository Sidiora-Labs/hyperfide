import type { InvocationContext, Principal } from '../transport/protocol.js';
import type { Component, ComponentContext } from '../components/registry.js';
import type { PrimaryTransaction } from '../storage/transactions.js';
import type { NativeReceiptReader } from '../scheduler/dispatch.js';
import type { Scope } from './outbox.js';
export { lookupNativeLaunch } from './outbox.js';
export interface Instruction extends Scope {
    id: string;
    attempt_id: string;
    attempt_generation: string;
    authority_epoch: string;
    sandbox_boot_generation: string;
    kind: 'START' | 'STEER' | 'CANCEL';
    body: Record<string, unknown>;
}
export declare function instruction(value: unknown): Instruction;
export interface RunnerConsumerBinding extends Scope {
    consumer_id: string;
    sandbox_id: string;
    boot_id: string;
    boot_generation: string;
    consumer_key: string;
    consumer_state: string;
    registered_credential_id: string;
    bootstrap_receipt_id: string;
}
export declare function resolveRunnerConsumer(tx: PrimaryTransaction, input: unknown): Promise<RunnerConsumerBinding | null>;
export declare function registerRunnerConsumer(tx: PrimaryTransaction, input: unknown, invocation: InvocationContext): Promise<unknown>;
export declare function instructionRecipient(tx: PrimaryTransaction, s: Scope, target: {
    sandbox_id: string;
    boot_id: string;
}, generation: string, active: boolean): Promise<string>;
export declare function issue(tx: PrimaryTransaction, input: unknown): Promise<unknown>;
export declare function acceptInstruction(tx: PrimaryTransaction, input: unknown): Promise<unknown>;
export declare function handoff(tx: PrimaryTransaction, input: unknown, principal?: Principal): Promise<unknown>;
export declare function replayInstructions(tx: PrimaryTransaction, input: unknown): Promise<unknown>;
export declare function runnerMatches(principal: Principal, i: Instruction, target: {
    sandbox_id: string;
    boot_id: string;
}): void;
export declare function recordRunnerAcknowledgement(tx: PrimaryTransaction, input: unknown, invocation: InvocationContext): Promise<unknown>;
export declare const readDispatchReceipt: NativeReceiptReader;
export declare function createComponent(context: ComponentContext): Component;
