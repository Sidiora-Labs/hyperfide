import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { PrimaryTransaction } from '../storage/transactions.js';
export interface AuthProfileSnapshot {
    schema_version: 1;
    profile_id: string;
    profile_revision: string;
    profile_digest: string;
    connector: 'codex' | 'claude';
    auth_mode: 'account_session' | 'api_credential';
    binary: {
        path: string;
        digest: string;
        version: string;
    };
    credential_reference: string;
    configured_provider_id: string;
    observed_provider_id: string | null;
    configured_model_alias: string;
    requested_model_id: string;
    observed_model_id: string | null;
    permission_profile_id: string;
    capabilities: {
        unattended: boolean;
        refresh: boolean;
        concurrent_account: boolean;
        portable_session: boolean;
        explicit_resume: boolean;
    };
    qualification: {
        state: 'UNQUALIFIED' | 'QUALIFIED' | 'STALE';
        live_qualified: boolean;
        receipt_digest: string | null;
    };
}
export interface NativeAuthAuthority {
    resolve(profileId: string): AuthProfileSnapshot;
    privateRuntimeInTransaction(tx: PrimaryTransaction, i: InvocationContext, profileId: string): Promise<{
        snapshot: AuthProfileSnapshot;
        runtime_home: string;
        target_uid: number;
        configured_account_key: string;
        observed_account_id: null;
    }>;
    privateRuntime(i: InvocationContext, profileId: string): Promise<{
        snapshot: AuthProfileSnapshot;
        runtime_home: string;
        target_uid: number;
        configured_account_key: string;
        observed_account_id: null;
    }>;
    probe(i: InvocationContext, profileId: string): Promise<unknown>;
}
export declare function isNativeAuthAuthority(v: unknown): v is NativeAuthAuthority;
export declare function createComponent(ctx: ComponentContext): Promise<Component>;
