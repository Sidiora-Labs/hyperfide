import type { ComponentContext } from '../components/registry.js';
import type { PrimaryTransaction } from '../storage/transactions.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { RunnerEnvironmentRequest, RunnerExpectedInputs, RunnerInputReader } from './bridge.js';
export interface ReproductionJobInputRequest {
    job_id: string;
    lease_generation: string;
    reservation_id: string;
    input_manifest_digest: string;
}
/** This is semantic job authority, never physical readiness. The actual17 reader
 * owns the lease, allocation, accepted registry and source-currentness checks. */
export interface ReproductionExpectedAuthority {
    authority: 'EXPECTED_AUTHORITY';
    namespace: 'REPRODUCTION';
    organisation_id: string;
    run_id: string;
    job_id: string;
    lease_generation: string;
    reservation_id: string;
    input_manifest_digest: string;
    input_packet_digest: string;
    input_manifest: Record<string, unknown>;
    repository_id: string;
    source_manifest_digest: string;
    source_object_id: string;
    source_tree_id: string;
    profile_id: string;
    profile_digest: string;
    environment_digest: string;
    sandbox_id: string;
    sandbox_boot_generation: string;
    slot_id: string;
    recorded_runner_session_id: string | null;
    recorded_runner_boot_id: string | null;
    recorded_runner_slot_generation?: string | null;
    custody_id: string;
    custody_generation: string;
}
export type ReproductionAuthorityReader = (tx: PrimaryTransaction, i: InvocationContext, request: ReproductionJobInputRequest) => Promise<ReproductionExpectedAuthority | null>;
export interface ReproductionPreparedInputs extends RunnerExpectedInputs {
    sandbox_id: string;
    boot_id: string;
    boot_generation: string;
    slot_id: string;
    slot_generation: string;
}
export type ReproductionPreparationReader = (tx: PrimaryTransaction, i: InvocationContext, authority: ReproductionExpectedAuthority) => Promise<ReproductionPreparedInputs | null>;
export declare function reproductionJobRequest(request: RunnerEnvironmentRequest): ReproductionJobInputRequest;
/** The join is explicit: every semantic identity must agree with the retained
 * preparation receipt. Current measurements are checked separately by12.1. */
export declare function bindReproductionInputs(authority: ReproductionExpectedAuthority, prepared: ReproductionPreparedInputs | null, request: RunnerEnvironmentRequest, scope: {
    organisation_id: string;
    run_id: string;
}): ReproductionPreparedInputs | null;
export declare function createReproductionJobInputReader(readAuthority: ReproductionAuthorityReader, readPreparation: ReproductionPreparationReader): RunnerInputReader;
export declare function registerReproductionJobInputs(ctx: ComponentContext, readAuthority: ReproductionAuthorityReader, readPreparation?: ReproductionPreparationReader): () => void;
