import type { Component, ComponentContext } from '../components/registry.js';
import type { PrimaryTransaction } from '../storage/transactions.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { CapacityDimension, CapacityRequest, SchedulerScope, PacketResourceRequirements } from './claim.js';
export interface EligibleTask {
    task_id: string;
    task_key: string;
    task_state_version: string;
    spec_revision_id: string;
    spec_generation: string;
    criteria_digest: string;
    profile_id: string;
    profile_version: string;
    packet_digest: string;
    mandatory_digest: string;
    attempt_id: string;
    attempt_generation: string;
    resource_requirements: PacketResourceRequirements;
    execution_packet: unknown;
}
export interface EligibleResult {
    availability: 'AVAILABLE' | 'UNAVAILABLE';
    reason?: string;
    authority: 'CANDIDATE_DISCOVERY';
    observed_at: string;
    spec_revision_id: string;
    spec_generation: string;
    eligible: EligibleTask[];
    excluded: {
        task_id: string;
        reason: string;
    }[];
}
export declare function eligibleTasks(tx: PrimaryTransaction, input: SchedulerScope & {
    pool_id: string;
    profile_id?: string;
    limit?: number;
    preparation?: boolean;
}, invocation?: InvocationContext): Promise<EligibleResult>;
export declare function eligibleDemand(tx: PrimaryTransaction, input: SchedulerScope & {
    pool_id: string;
    profile_id: string;
    job_class: 'PREPARATION' | 'INDEX';
    warm_spare: boolean;
}, invocation: InvocationContext): Promise<{
    eligible_count: number;
    reservation_dimensions: CapacityDimension[];
    spec_version: string;
    profile_version: string;
    observed_at: string;
    truncated: boolean;
    candidate_scan_limit: number;
    preparation_task_id: string | null;
    execution_dimensions: CapacityDimension[];
}>;
export interface QuiescenceReceipt {
    id: string;
    digest: string;
    observed_at: string;
}
export type ProofReader = (tx: PrimaryTransaction, input: SchedulerScope & {
    reservation_id: string;
}) => Promise<QuiescenceReceipt | null>;
export interface DynamicCapacityRequest extends CapacityRequest {
    pool_id: string;
}
/** Rate receipts are separate from occupied-resource reservations and never inferred from worker TTL. */
export declare function reserveDynamic(tx: PrimaryTransaction, input: DynamicCapacityRequest): Promise<unknown>;
export interface AdmissionLimit {
    capacity_account_id: string;
    dimension: string;
    resource_key: string;
    capacity_class: string;
    configured_limit: string;
    occupied: string;
    requested: string;
    wait_reason: string;
    window_start?: string;
}
/** Locks the exact accounts in UUID order and names the first declared dimension that cannot admit the vector. Writes nothing. */
export declare function limitingResource(tx: PrimaryTransaction, input: SchedulerScope & {
    pool_id: string;
    dimensions: CapacityDimension[];
    request_id?: string;
}): Promise<AdmissionLimit | null>;
export interface Backpressure {
    active: boolean;
    limiting_resource: string | null;
    dimensions: {
        dimension: string;
        configured_limit: string;
        occupied: string;
        queued: string;
        saturated: boolean;
    }[];
}
/**
 * Review/integration backpressure. The declared REVIEW and INTEGRATION limits are the policy: once occupied plus live
 * queued downstream work reaches the declared limit, new coding (AGENT) admissions wait with REVIEW instead of
 * producing more unreviewable work. Pools with no outstanding downstream work never apply pressure.
 */
export declare function reviewBackpressure(tx: PrimaryTransaction, scope: {
    organisation_id: string;
}, pool_id: string): Promise<Backpressure>;
export declare class ResourceScheduler {
    private readonly readers;
    registerProofReader(source: string, reader: ProofReader): () => void;
    close(): void;
    release(tx: PrimaryTransaction, input: SchedulerScope & {
        reservation_ids: string[];
    }): Promise<unknown>;
}
export declare function createComponent(_startup: ComponentContext): Component;
