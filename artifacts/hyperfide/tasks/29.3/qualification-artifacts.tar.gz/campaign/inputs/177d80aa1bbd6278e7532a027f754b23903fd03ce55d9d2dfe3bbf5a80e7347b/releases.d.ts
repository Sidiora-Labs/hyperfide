import type { Component, ComponentContext } from '../components/registry.js';
/** Byte verification is separately reusable by a trusted operator installer.
 * Only configured detached Ed25519 trust material authenticates provenance;
 * request hashes or an installation receipt cannot establish authentication. */
export declare function inspectPrebuiltRelease(env: Readonly<NodeJS.ProcessEnv>, relativeManifest: unknown): Promise<unknown>;
export declare function createComponent(_startup: ComponentContext): Component;
