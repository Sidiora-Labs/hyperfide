import type { ComponentContext } from '../components/registry.js';
import type { Data } from './submission.js';
export declare function resultInputProducer(ctx: ComponentContext): {
    close: () => void;
    execute: (requestContext: ComponentContext, raw: unknown) => Promise<Data>;
};
