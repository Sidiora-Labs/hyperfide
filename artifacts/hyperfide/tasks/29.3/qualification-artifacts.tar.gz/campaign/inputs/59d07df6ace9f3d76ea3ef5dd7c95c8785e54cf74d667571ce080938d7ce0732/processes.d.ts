import type { InvocationContext } from '../../transport/protocol.js';
import type { Component, ComponentContext } from '../../components/registry.js';
import type { ProviderAdapter, ProviderOperation, ProviderOutcome, ProviderScope, ResourceRef } from '../contract.js';
import type { BlaxelLifetimePolicy } from './lifetime.js';
type Obj = Record<string, unknown>;
export interface CapturedBlaxelOutput {
    stdout: Uint8Array;
    stderr: Uint8Array;
    exit_code: number;
    complete: true;
    spool_digest: string;
    capture: {
        schema_version: 1;
        scheme: 'STREAM_DIGESTS_CANONICAL_JSON';
    };
}
export interface BlaxelProcessRecord {
    native_process_ref?: string | null;
    process_ref: string;
    payload_digest: string;
    resource: ResourceRef;
    state: 'SUBMITTED' | 'RUNNING' | 'EXITED' | 'UNKNOWN';
    provider_metadata: Record<string, unknown>;
}
export interface BlaxelPersistenceHooks {
    persistEarlyProcess(operation: ProviderOperation<'execute'>, nativeProcessRef: string): Promise<void>;
    readonly invocation: InvocationContext;
    resolveResourceBinding(operation: ProviderOperation): Promise<{
        organisation_id: string;
        run_id: string;
        sandbox_id: string;
        boot_id: string;
        boot_generation: string;
    }>;
    resolvePreparation(operation: ProviderOperation<'create'>): Promise<{
        purpose: 'PREPARATION' | 'EXECUTION';
        scope: ProviderScope;
        preparation_digest: string;
        parameters: ProviderOperation<'create'>['parameters'];
        prepared_base: Obj | null;
        adapter_policy_digest?: string | null;
    }>;
    claimProcess(operation: ProviderOperation<'execute'>, record: BlaxelProcessRecord): Promise<{
        disposition: 'NEW' | 'EXISTING';
        record: BlaxelProcessRecord;
    }>;
    resolveProcess(operation: ProviderOperation, processRef: string): Promise<BlaxelProcessRecord | null>;
    assignedBootGeneration(operation: ProviderOperation<'create'>): Promise<string>;
    persistEarlyResource(operation: ProviderOperation<'create'>, nativeSandboxId: string): Promise<ResourceRef>;
    recordObservation(operation: ProviderOperation, outcome: ProviderOutcome): Promise<void>;
    assertResourceBinding(operation: ProviderOperation): Promise<void>;
}
export interface QualifiedBlaxelBase {
    qualification_status: 'QUALIFIED' | 'TRUSTED_PREPARATION_SEED';
    purpose?: 'PREPARATION' | 'EXECUTION';
    preparation_digest: string;
    provider_prepared_digest: string;
    preparation_reference: string;
    scope: ProviderScope;
    resources: import('../contract.js').ResourceVector;
    lifecycle: BlaxelLifetimePolicy;
    network_mode: 'ISOLATED' | 'PRIVATE';
    network: Obj;
    volumes: Obj[];
    runtime_extra_args: Record<string, string>;
}
/** These closures are installed by authenticated controller components. Action
 * input cannot provide a resolver, enrollment token, prepared base or transport. */
export interface BlaxelTrustedDependencies {
    resolvePreparedBase(operation: ProviderOperation<'create'>): Promise<QualifiedBlaxelBase>;
    resolveCredentialReferences(operation: ProviderOperation<'execute'>, refs: Record<string, string>, signal: AbortSignal): Promise<Record<string, string>>;
    assertPreparedResource(operation: ProviderOperation): Promise<void>;
}
interface BlaxelProcess {
    get(id: string, options?: {
        signal?: AbortSignal;
        retry?: boolean;
    }): Promise<Obj>;
    exec(request: Obj): Promise<Obj>;
    stop(id: string): Promise<Obj>;
    kill(id: string): Promise<Obj>;
    writeStdin(id: string, data: Uint8Array): Promise<void>;
    closeStdin(id: string): Promise<void>;
}
export declare function boundedBlaxelOperation<T>(fn: (signal: AbortSignal) => Promise<T>, parent: AbortSignal, deadline: number): Promise<T>;
/** One capture shares the original deadline and every cancellation owner. */
export declare function blaxelCaptureControl(operation: ProviderOperation, contextSignal: AbortSignal, requestSignal: AbortSignal, identitySignal: AbortSignal): {
    deadline: number;
    signal: AbortSignal;
};
export declare function blaxelCreateName(operation: ProviderOperation<'create'>, generation: string): string;
export declare function planBlaxelCreate(operation: ProviderOperation<'create'>, generation: string, base: QualifiedBlaxelBase): Obj;
export declare function verifyBlaxelCreate(observation: unknown, expected: Obj, scope: ProviderScope): {
    matches: true;
    native_sandbox_id: string;
};
/** Record candidate identity before validating ownership. This callback boundary
 * carries no readiness authority; persistence failures still retain the known ID. */
export declare function retainBlaxelCreateCandidate(actual: {
    metadata: Obj;
    spec: Obj;
    status: string | undefined;
}, expected: Obj, scope: ProviderScope, generation: string, remember: (resource: ResourceRef) => void, persist: (nativeId: string) => Promise<ResourceRef>): Promise<ResourceRef>;
export declare const BLAXEL_CAPTURE_SUPERVISOR: string;
export declare function planBlaxelProcess(operation: ProviderOperation<'execute'>): {
    process_ref: string;
    spool_path: string;
    launch_digest: string;
    request: Obj;
};
export declare function verifyBlaxelCapturedOutput(input: {
    receipt: unknown;
    stdout: Uint8Array;
    stderr: Uint8Array;
    scope: ProviderScope;
    resource: ResourceRef;
    process_ref: string;
    expected: {
        operation_id: string;
        payload_digest: string;
        launch_digest: string;
        spool_path: string;
        scope_digest: string;
    };
    maxBytes: number;
}): CapturedBlaxelOutput;
export interface BlaxelAdapter extends ProviderAdapter {
    readCapturedOutput(scope: ProviderScope, resource: ResourceRef, processRef: string, maxBytes: number): Promise<CapturedBlaxelOutput>;
}
export declare function createBlaxelAdapter(scope: ProviderScope, hooks: BlaxelPersistenceHooks, deps: Partial<BlaxelTrustedDependencies>, ctx: ComponentContext): BlaxelAdapter;
export interface BlaxelStdinLedger {
    assertWritable(resource: ResourceRef, processRef: string): Promise<void>;
    beginWrite(resource: ResourceRef, processRef: string, instructionId: string, bytesDigest: string, byteCount: number): Promise<'NEW' | 'CONFIRMED' | 'UNKNOWN'>;
    finishWrite(resource: ResourceRef, processRef: string, instructionId: string, state: 'CONFIRMED' | 'UNKNOWN'): Promise<void>;
}
/** A transport failure may occur after a prefix was delivered. Never replay an
 * instruction or assume atomic stdin writes from an empty HTTP response. */
export declare function writeBlaxelStdin(process: Pick<BlaxelProcess, 'writeStdin' | 'closeStdin'>, ledger: BlaxelStdinLedger, resource: ResourceRef, processRef: string, instructionId: string, bytes: Uint8Array, signal: AbortSignal, deadline: number): Promise<{
    state: 'CONFIRMED' | 'UNKNOWN';
    replay_allowed: false;
}>;
export declare function createBlaxelIsolationTransport(scope: ProviderScope, ctx: Pick<ComponentContext, 'env' | 'signal'>): Readonly<{
    destroy(raw: ProviderOperation<'destroy'>, signal?: AbortSignal): Promise<ProviderOutcome<'destroy'>>;
    observe(raw: ProviderOperation<'observe'>, signal?: AbortSignal): Promise<ProviderOutcome<'observe'>>;
}>;
export declare function createComponent(ctx: ComponentContext): Component;
export {};
