import { type QuerySession } from '../storage/transactions.js';
import type { Component, ComponentContext } from '../components/registry.js';
export type Data = Record<string, unknown>;
export interface Scope {
    organisation_id: string;
    run_id: string;
}
export interface Revision {
    spec_revision_id: string;
    spec_generation: string;
    state_version: string;
    authority_epoch: string;
    policy_digest: string;
    repositories: Data[];
    graph_channels: Data[];
    contract_revisions: Data[];
}
export interface Packet {
    schema_version: 1;
    id: string;
    purpose: string;
    packet_hash: string;
    revision: RevisionVector;
    state: Data;
    created_at: string;
    expires_at: string;
    authority: 'NONE';
}
export declare const STATUSES: readonly ['accepted_advice', 'abstained', 'invalid_response', 'unsupported', 'expired', 'cancelled', 'unavailable', 'budget_exhausted'];
export declare function fail(code: string, message: string): never;
export declare function obj(value: unknown, label?: string): Data;
export declare function exact(value: unknown, keys: string[], required?: string[]): Data;
export declare function str(value: unknown, label?: string, max?: number): string;
export declare function uuid(value: unknown): string;
export declare function list(value: unknown, max?: number): unknown[];
export declare function canonical(value: unknown): string;
export declare function digest(value: unknown): string;
export declare function safe(value: unknown, max?: number): void;
export declare function scope(value: unknown): Scope;
export interface Invocation {
    operation: unknown;
    payload: {
        action: string;
        run_id: string;
    };
    principal: {
        organisation_id: string;
        run_id: string;
        allowed_actions: string[];
    };
    signal: AbortSignal;
    guard(tx: QuerySession): Promise<void>;
}
export declare function withAuthority<T>(ctx: ComponentContext, s: Scope, action: string, work: (client: QuerySession) => Promise<T>): Promise<T>;
export declare function currentRevision(client: QuerySession, s: Scope, includeDocument?: boolean): Promise<{
    revision: Revision;
    document?: Data;
    source_digest: string;
}>;
export declare function loadPacket(client: QuerySession, s: Scope, id: string, requireFresh?: boolean): Promise<Packet>;
export declare function storePacket(client: QuerySession, s: Scope, purpose: string, state: Data, id?: `${string}-${string}-${string}-${string}-${string}`, ttl?: number): Promise<Packet>;
export declare function grantFree(value: unknown): void;
export declare function validateAudit(value: unknown): Data;
export declare function recordAudit(client: QuerySession, s: Scope, value: unknown): Promise<Data>;
export declare function input(value: unknown, fields: string[], optional?: string[]): {
    scope: Scope;
    data: Data;
};
export declare function auditFor(client: QuerySession, s: Scope, id: unknown, purpose: string): Promise<{
    audit: Data;
    packet: Awaited<ReturnType<typeof loadPacket>>;
}>;
export declare function persistProposal(client: QuerySession, s: Scope, auditId: unknown, payload: Data, state?: string): Promise<Data>;
export interface RevisionVector {
    spec_revision: string;
    repository_commits: Record<string, string>;
    graph_revision: string | null;
    contract_revisions: Record<string, string>;
    event_watermark: string;
    ownership_generation: string | null;
}
export declare function registerAdvisoryPurpose(ctx: ComponentContext, purpose: string, check?: (tx: QuerySession, s: Scope, packet: Packet, invocation: Invocation) => Promise<void>): void;
export declare function answers(value: unknown): Data;
export declare function noul(value: unknown): number;
export declare const LEGACY_PURPOSES: {
    readonly guard: 'Does the observation indicate the guarded change needs closer human review before anything proceeds?';
    readonly readiness: 'Does the observation indicate the fleet is ready for the next measured step?';
    readonly triage: 'Does the observation indicate the specification item needs triage attention?';
    readonly memory: 'Should the observation be retained as durable project memory?';
    readonly recap: 'Is the observation significant enough to include in a recap?';
};
export type LegacyPurpose = keyof typeof LEGACY_PURPOSES;
export declare const LEGACY_BUDGET_MS = 2000, LEGACY_JOB_DEADLINE_MS = 1500;
export declare const LEGACY_ACTIONS: string[];
export declare function createComponent(ctx: ComponentContext): Component;
