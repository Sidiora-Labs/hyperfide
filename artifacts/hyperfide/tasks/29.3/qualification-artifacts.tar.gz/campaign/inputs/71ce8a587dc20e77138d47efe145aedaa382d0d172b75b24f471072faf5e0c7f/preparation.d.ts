import { type ConnectOptions, type SandboxTemplate } from 'railway';
import type { Component, ComponentContext } from '../../components/registry.js';
import { type PreparationManifest } from '../../preparation/manifests.js';
import type { ProviderScope } from '../contract.js';
/** Public SDK/API revision pin. Credentials belong only to the provisioner. */
export declare const RAILWAY_PIN: Readonly<{
    sdk_name: "railway";
    sdk_version: "3.16.0";
    api_revision: "97fdb4f61d351319d5633c2c92a86ca2ff0062d8";
    node_version: "24.22.0";
}>;
export type JsonObject = Record<string, unknown>;
export declare function object(value: unknown, keys?: readonly string[]): JsonObject;
export declare function text(value: unknown, max?: number): string;
export declare function digest(value: unknown): string;
export declare function hash(value: unknown): string;
export declare function absolute(value: unknown): string;
export declare function integer(value: unknown, min?: number, max?: number): number;
export declare function instant(value: unknown): string;
export declare function scope(value: unknown): ProviderScope;
export declare function sameScope(a: ProviderScope, b: ProviderScope): boolean;
export interface RailwayConfiguration {
    schema_version: 1;
    mode: 'live' | 'component-fixture';
    endpoint: string;
    environment_id: string;
    region: string;
    account_id: string;
    token_env: string;
    auth_type: 'bearer' | 'project-token';
    preparation_root: string;
    request_timeout_ms: number;
    exec_ws_endpoint: string | null;
}
export declare class RailwayRequestError extends Error {
    readonly code: 'REJECTED' | 'UNKNOWN' | 'PROTOCOL';
    readonly providerCode: string | null;
    constructor(code: 'REJECTED' | 'UNKNOWN' | 'PROTOCOL', providerCode?: string | null);
}
export declare class RailwayClient {
    private readonly transport;
    readonly config: RailwayConfiguration;
    private readonly token;
    constructor(value: unknown, env: Readonly<NodeJS.ProcessEnv>, transport?: typeof fetch);
    assertScope(s: ProviderScope): void;
    sdkOptions(capture?: (stream: 'stdout' | 'stderr', bytes: Uint8Array) => void): ConnectOptions;
    request<T>(query: string, variables: JsonObject, signal?: AbortSignal): Promise<T>;
    provenance(): {
        mode: RailwayConfiguration['mode'];
        sdk: typeof RAILWAY_PIN;
        live_qualification: 'NOT_EVALUATED';
    };
}
export declare function configuredClient(context: Pick<ComponentContext, 'env'>): RailwayClient;
export interface PreparedRailwayBase {
    schema_version: 1;
    provider: 'railway';
    scope: ProviderScope;
    preparation_digest: string;
    checkpoint: {
        id: string;
        key: string;
    };
    disk_only: true;
    source_native_sandbox_id: string;
    source_boot_id: string;
    captured_at: string;
}
export declare function validatePreparedBase(value: unknown, expected: ProviderScope, expectedDigest: string): PreparedRailwayBase;
export interface PreparationCaptureHooks {
    /** Authenticated runner must stop all preparation writers and revoke live credentials.
     * A caller-supplied boolean is never a quiescence receipt. */
    quiesceAndVerify(sandboxId: string, manifest: PreparationManifest, signal: AbortSignal): Promise<{
        boot_id: string;
        preparation_digest: string;
        assertHeld: () => Promise<void>;
        release: () => Promise<void>;
    }>;
    persistCheckpoint(base: PreparedRailwayBase): Promise<void>;
    /** Coordinator serializes this immutable key across provisioner instances. */
    withPreparationLock<T>(digest: string, action: () => Promise<T>): Promise<T>;
}
export declare function capturePreparedBase(client: RailwayClient, input: {
    sandbox_id: string;
    scope: ProviderScope;
    manifest: PreparationManifest;
    candidate_path: string;
    scan_policy: unknown;
}, context: ComponentContext, hooks: PreparationCaptureHooks): Promise<PreparedRailwayBase>;
export declare function buildRailwayTemplate(client: RailwayClient, input: {
    candidate_path: string;
    manifest: PreparationManifest;
    scan_policy: unknown;
    scope: ProviderScope;
    commands: string[];
    build_env: Record<string, string>;
}, context: ComponentContext): Promise<SandboxTemplate>;
export declare function freshRestoreObservation(base: PreparedRailwayBase, child: {
    native_sandbox_id: string;
    boot_id: string;
    environment_id: string;
    region: string;
    preparation_digest: string;
}): {
    enrollment_required: true;
    process_memory_restored: false;
    authority: 'NONE';
    boot_id: string;
};
export declare function checkpointByKey(client: RailwayClient, key: string, signal?: AbortSignal): Promise<{
    id: string;
    key: string;
}>;
export interface RestoredSentinelObservation {
    native_sandbox_id: string;
    boot_id: string;
    environment_id: string;
    region: string;
    preparation_digest: string;
    sentinel_file_digest: string | null;
    sentinel_process_alive: boolean;
}
/** Disk-only restore proof: sentinel bytes must survive, the sentinel process must not, and the boot must be fresh. */
export declare function verifySentinelRestore(base: PreparedRailwayBase, sentinel: {
    path: string;
    sha256: string;
    process_marker: string;
}, child: RestoredSentinelObservation): ReturnType<typeof freshRestoreObservation> & {
    sentinel_file: 'IDENTICAL';
    sentinel_process: 'ABSENT';
};
/** Exported for the Railway adapter (9.4) to bind with coordinator lock, authenticated runner quiescence and durable persistence. */
export declare const RAILWAY_PREPARATION_CAPABILITY: Readonly<{
    capturePreparedBase: typeof capturePreparedBase;
    buildRailwayTemplate: typeof buildRailwayTemplate;
    checkpointByKey: typeof checkpointByKey;
    validatePreparedBase: typeof validatePreparedBase;
    freshRestoreObservation: typeof freshRestoreObservation;
    verifySentinelRestore: typeof verifySentinelRestore;
}>;
export declare function createComponent(_context: ComponentContext): Component;
