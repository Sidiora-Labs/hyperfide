import type { ServiceResources } from './storage/runtime.js';
import { FileExternalAuthorityJournal } from './storage/authority_journal.js';
import type { ExternalAuthorityAttestation } from './storage/authority_journal.js';
import type { AuthorityTransaction } from './transport/protocol.js';
export interface BootstrapPolicy {
    deployment_id: string;
    max_ttl_ms: number;
    journal_dir: string;
}
export interface OperatorBinding {
    credential_id: string;
    organisation_id: string;
    run_id: string;
    actor_id: string;
    role: 'OPERATOR';
    credential_version: string;
    deployment_epoch: string;
    expires_at: string;
    accepted_revision_digest: string;
    replayed: boolean;
}
export declare function assertBootstrapExternalAuthority(resources: ServiceResources, policy: BootstrapPolicy, signal?: AbortSignal): Promise<{
    journal: FileExternalAuthorityJournal;
    attestation: ExternalAuthorityAttestation;
}>;
export declare function assertFreshAttestation(tx: AuthorityTransaction, deploymentId: string, epoch: string, attestation: ExternalAuthorityAttestation): Promise<void>;
export declare function issueOfflineOperator(resources: ServiceResources, value: unknown, policy: BootstrapPolicy, signal?: AbortSignal): Promise<OperatorBinding>;
