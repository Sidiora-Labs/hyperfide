import type { Component, ComponentContext } from '../components/registry.js';
import { FoundationError } from '../policy/programme.js';
import { type PrimaryTransaction } from '../storage/transactions.js';
export type ReviewDb = Pick<PrimaryTransaction, 'query'>;
export interface ReviewScope {
    organisation_id: string;
    run_id: string;
}
export interface ReviewCoverageQuery {
    repository_id: string;
    source_object_id: string;
    candidate_digest?: string;
    input_manifest_digest?: string;
    policy_digest?: string;
}
export declare function fail(code: string, message: string): never;
export declare function obj(value: unknown, fields: string[], optional?: string[]): Record<string, unknown>;
export declare function uuid(value: unknown): string;
export declare function digest(value: unknown): string;
export declare function oid(value: unknown): string;
export declare function text(value: unknown, max?: number): string;
export declare function decimal(value: unknown): string;
export declare function scope(value: Record<string, unknown>): ReviewScope;
export declare function canonical(value: unknown, depth?: number): string;
export declare function hash(value: unknown): string;
export declare function strings(value: unknown, max?: number): string[];
export declare function primary(db: ReviewDb): Promise<void>;
interface ReviewInvocation {
    principal: {
        organisation_id: string;
        run_id: string;
        actor_id: string;
        role: string;
        allowed_actions: readonly string[];
        sandbox_id: string | null;
        boot_generation: string | null;
    };
    payload: {
        action: string;
    };
    signal: AbortSignal;
    guard: (db: ReviewDb) => Promise<void>;
}
interface ReviewGateway {
    withPrimaryTransaction<T>(options: {
        timeoutMs: number;
        signal: AbortSignal;
        guard: (db: ReviewDb) => Promise<void>;
    }, operation: (db: ReviewDb) => Promise<T>): Promise<T>;
}
export declare function authorizeReview(context: ComponentContext, binding: ReviewScope, roles?: readonly string[]): {
    invocation: ReviewInvocation;
    gateway: ReviewGateway;
    scope: ReviewScope;
};
export declare function lockReviewDisposition(db: ReviewDb, binding: ReviewScope, exclusive?: boolean): Promise<void>;
export declare function transaction<T>(context: ComponentContext, binding: ReviewScope, operation: (db: ReviewDb) => Promise<T>, exclusive?: boolean): Promise<T>;
export declare function reviewError(error: unknown): FoundationError;
export declare function configureReviewPolicy(context: ComponentContext, value: unknown): Promise<unknown>;
export declare function discoverReviewCommits(context: ComponentContext, value: unknown): Promise<unknown>;
export declare function dependencyDigest(db: ReviewDb, binding: ReviewScope): Promise<string>;
export declare function relevantContracts(db: ReviewDb, binding: ReviewScope, repositories: string[]): Promise<Array<{
    id: string;
    revision: string;
    criteria_digest: string;
    definition: Record<string, unknown>;
}>>;
export declare function reviewTaskVersions(db: ReviewDb, binding: ReviewScope, sources: unknown[]): Promise<Array<Record<string, unknown>>>;
export declare function reviewInputCurrent(db: ReviewDb, binding: ReviewScope, snapshot: Record<string, unknown>): Promise<boolean>;
export interface ReviewCoverageSummary {
    status: 'COMPLETE' | 'INCOMPLETE' | 'STALE';
    policy_digest: string;
    repository_id: string;
    source_object_id: string;
    required: number;
    complete: number;
    missing: Array<Record<string, unknown>>;
    receipt_ids: string[];
    limitations: string[];
    authority: 'POSTGRESQL_REVIEW_OBLIGATIONS';
    authority_generation: string;
    input_bindings: Record<string, unknown> | null;
}
export declare function inspectReviewCoverage(db: ReviewDb, binding: ReviewScope, query: ReviewCoverageQuery): Promise<ReviewCoverageSummary>;
export declare function createComponent(_context: ComponentContext): Component;
export interface ReviewControl {
    scope_kind: 'RUN' | 'PACKAGE' | 'ATTEMPT' | 'SANDBOX';
    scope_id: string;
    task_ids: string[];
    mode: 'STOP' | 'CANCEL';
    operation_id: string;
    control_generation: string;
}
export declare function assertReviewExecutionAllowed(context: ComponentContext, db: ReviewDb, binding: ReviewScope, sourceSet: readonly {
    repository_id: string;
    source_object_id: string;
}[], sandboxId: string | null, operation: 'ADMISSION' | 'RENEWAL' | 'CHECKPOINT', knownTaskIds?: string[]): Promise<void>;
export declare function reviewControlMatches(db: ReviewDb, binding: ReviewScope, control: ReviewControl, taskIds: readonly string[], sandboxId: string | null): Promise<boolean>;
export declare function reviewAttributionComplete(db: ReviewDb, binding: ReviewScope, sources: unknown[]): Promise<boolean>;
/** Trusted same-primary freshness observation; callers retain their invocation guard. */
export declare function reviewGraphCustodyCurrent(db: ReviewDb, binding: ReviewScope, manifestId: string): Promise<boolean>;
export {};
