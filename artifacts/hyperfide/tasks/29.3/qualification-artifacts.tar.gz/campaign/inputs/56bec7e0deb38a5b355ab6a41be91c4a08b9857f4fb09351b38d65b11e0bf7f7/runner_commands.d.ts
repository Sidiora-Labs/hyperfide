import type { ComponentContext } from '../components/registry.js';
export declare function pollRunnerCommands(context: ComponentContext, input: unknown): Promise<unknown>;
