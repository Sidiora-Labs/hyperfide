import { authority, object, text, uuid, digest, timestamp, hash, fail, lockRun, requireArtifact, numbers, requireCollector, integratedProof } from './views.js';
const METRICS = { readiness_to_start: 'milliseconds', provisioning: 'milliseconds', preparation: 'milliseconds', lease_latency: 'milliseconds', result_latency: 'milliseconds', event_lag: 'milliseconds', replica_lag: 'milliseconds', graph_publication_age: 'milliseconds', source_to_graph: 'milliseconds', recovery_loss: 'bytes', recovery_elapsed: 'milliseconds', qualification: 'count', retry: 'count', cost: 'microcurrency', queue_wait: 'milliseconds', api_latency: 'milliseconds', db_lock_wait: 'milliseconds', db_pool_wait: 'milliseconds' };
const PHASES = ['READINESS', 'PROVISIONING', 'PREPARATION', 'IMPLEMENTATION', 'BUILD', 'LINK', 'TEST', 'REVIEW', 'INTEGRATION', 'GRAPH', 'RECOVERY', 'MODEL', 'API', 'INFRASTRUCTURE'];
function value(raw) { const s = text(raw, 32); if (!/^(0|[1-9][0-9]{0,23})(\.[0-9]{1,6})?$/.test(s))
    fail('OBSERVABILITY_INPUT_INVALID', 'Bounded nonnegative decimal string required'); return s.includes('.') ? s.replace(/0+$/, '').replace(/\.$/, '') : s; }
function fixed(s) { const [a, b = ''] = s.split('.'); return BigInt(a) * 1000000n + BigInt(b.padEnd(6, '0')); }
function display(n) { const whole = n / 1000000n, f = (n % 1000000n).toString().padStart(6, '0').replace(/0+$/, ''); return whole.toString() + (f ? '.' + f : ''); }
function parseSeries(raw) {
    const v = object(raw, ['id', 'name', 'phase', 'profile_key', 'variant', 'currency', 'provenance_digest', 'bucket_bounds']);
    const name = text(v.name), phase = text(v.phase), variant = text(v.variant), currency = v.currency === undefined ? null : text(v.currency, 3);
    if (!Object.hasOwn(METRICS, name) || !PHASES.includes(phase) || !['BASELINE', 'CURRENT'].includes(variant) || currency !== null && !/^[A-Z]{3}$/.test(currency) || name === 'cost' && currency === null || name !== 'cost' && currency !== null)
        fail('OBSERVABILITY_INPUT_INVALID', 'Metric name, phase, variant or currency is invalid');
    if (!Array.isArray(v.bucket_bounds) || v.bucket_bounds.length < 1 || v.bucket_bounds.length > 32)
        fail('OBSERVABILITY_INPUT_INVALID', 'One to thirty-two histogram bounds required');
    const bounds = v.bucket_bounds.map(value);
    if (bounds.some((b, i) => i > 0 && fixed(b) <= fixed(bounds[i - 1])))
        fail('OBSERVABILITY_INPUT_INVALID', 'Histogram bounds must strictly increase');
    return { id: uuid(v.id), name, phase, profile_key: text(v.profile_key), variant, unit: METRICS[name], currency, provenance_digest: digest(v.provenance_digest), bucket_bounds: bounds };
}
export async function recordMetrics(tx, p, input) {
    requireCollector(p, p.sandbox_id);
    const v = object(input, ['receipt_id', 'series', 'source_artifact_id', 'measurement_kind', 'samples']), id = uuid(v.receipt_id), series = parseSeries(v.series), artifact = uuid(v.source_artifact_id), kind = text(v.measurement_kind);
    if (!['MEASUREMENT_REPORT', 'PROVIDER_INVOICE_REPORT', 'REPLAY'].includes(kind) || kind === 'PROVIDER_INVOICE_REPORT' && series.name !== 'cost')
        fail('OBSERVABILITY_INPUT_INVALID', 'Measurement origin does not match metric');
    if (!Array.isArray(v.samples) || v.samples.length < 1 || v.samples.length > 100)
        fail('OBSERVABILITY_INPUT_INVALID', 'One to one hundred samples required');
    const samples = v.samples.map(raw => { const q = object(raw, ['observed_at', 'value']); return { observed_at: timestamp(q.observed_at), value: value(q.value) }; });
    const body = { series, source_artifact_id: artifact, measurement_kind: kind, samples }, identity = hash(body);
    await lockRun(tx, p, 'metrics');
    await requireArtifact(tx, p, artifact);
    const prior = await tx.query('SELECT payload_digest FROM hyperfide.observability_metric_receipts WHERE organisation_id=$1 AND run_id=$2 AND id=$3', [p.organisation_id, p.run_id, id]);
    if (prior.rows.length) {
        if (prior.rows[0].payload_digest !== identity)
            fail('OBSERVABILITY_CONFLICT', 'Metric receipt identity reused with different content');
        return { recorded: 0, replayed: true };
    }
    const now = await tx.query('SELECT clock_timestamp() AS now');
    const at = new Date(now.rows[0].now).getTime();
    if (samples.some(s => Date.parse(s.observed_at) > at + 5000 || Date.parse(s.observed_at) < at - 72 * 3600000))
        fail('OBSERVABILITY_INPUT_INVALID', 'Metric observation outside retained seventy-two-hour window');
    const previous = await tx.query('SELECT * FROM hyperfide.observability_metric_series WHERE organisation_id=$1 AND run_id=$2 AND id=$3', [p.organisation_id, p.run_id, series.id]);
    if (previous.rows.length) {
        const r = previous.rows[0];
        if (r.name !== series.name || r.phase !== series.phase || r.profile_key !== series.profile_key || r.variant !== series.variant || r.unit !== series.unit || r.currency !== series.currency || r.provenance_digest !== series.provenance_digest || r.measurement_kind !== kind || JSON.stringify(r.bucket_bounds) !== JSON.stringify(series.bucket_bounds))
            fail('OBSERVABILITY_CONFLICT', 'Metric series identity reused with different provenance');
    }
    else {
        const counts = await tx.query('SELECT count(*) AS n FROM hyperfide.observability_metric_series WHERE organisation_id=$1 AND run_id=$2', [p.organisation_id, p.run_id]);
        if (BigInt(counts.rows[0].n) >= 128n)
            fail('OBSERVABILITY_BACKPRESSURE', 'Metric series cardinality budget exhausted');
        // Under SERIALIZABLE a concurrent first writer is invisible to this snapshot; ON CONFLICT turns that race into a retryable 40001 instead of a raw unique violation.
        const inserted = await tx.query('INSERT INTO hyperfide.observability_metric_series(organisation_id,run_id,id,name,phase,profile_key,variant,unit,currency,provenance_digest,bucket_bounds,measurement_kind) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb,$12) ON CONFLICT DO NOTHING', [p.organisation_id, p.run_id, series.id, series.name, series.phase, series.profile_key, series.variant, series.unit, series.currency, series.provenance_digest, JSON.stringify(series.bucket_bounds), kind]);
        if (inserted.rowCount !== 1)
            fail('OBSERVABILITY_CONFLICT', 'Metric series identity already registered under another id');
    }
    const receipts = await tx.query('SELECT count(*) AS n FROM hyperfide.observability_metric_receipts WHERE organisation_id=$1 AND run_id=$2', [p.organisation_id, p.run_id]);
    if (BigInt(receipts.rows[0].n) >= 100000n)
        fail('OBSERVABILITY_BACKPRESSURE', 'Metric receipt budget exhausted; producer must retain and retry');
    const buckets = new Map();
    for (const s of samples) {
        const minute = new Date(Math.floor(Date.parse(s.observed_at) / 60000) * 60000).toISOString(), old = buckets.get(minute), n = fixed(s.value), bin = series.bucket_bounds.findIndex(b => n <= fixed(b)), slot = bin < 0 ? series.bucket_bounds.length : bin;
        if (!old) {
            const histogram = Array(series.bucket_bounds.length + 1).fill('0');
            histogram[slot] = '1';
            buckets.set(minute, { bucket_start: minute, sample_count: '1', value_sum: s.value, value_min: s.value, value_max: s.value, histogram, first_observed_at: s.observed_at, last_observed_at: s.observed_at });
        }
        else {
            old.sample_count = (BigInt(old.sample_count) + 1n).toString();
            old.value_sum = display(fixed(old.value_sum) + n);
            if (n < fixed(old.value_min))
                old.value_min = s.value;
            if (n > fixed(old.value_max))
                old.value_max = s.value;
            old.histogram[slot] = (BigInt(old.histogram[slot]) + 1n).toString();
            if (s.observed_at < old.first_observed_at)
                old.first_observed_at = s.observed_at;
            if (s.observed_at > old.last_observed_at)
                old.last_observed_at = s.observed_at;
        }
    }
    const earliest = [...buckets.keys()].sort()[0];
    const receipt = await tx.query('INSERT INTO hyperfide.observability_metric_receipts(organisation_id,run_id,id,series_id,payload_digest,source_artifact_id,bucket_start,producer_actor_id) VALUES($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT DO NOTHING', [p.organisation_id, p.run_id, id, series.id, identity, artifact, earliest, p.actor_id]);
    if (receipt.rowCount !== 1)
        fail('OBSERVABILITY_CONFLICT', 'Metric receipt identity already recorded');
    await tx.query("INSERT INTO hyperfide.observability_metric_buckets(organisation_id,run_id,series_id,bucket_start,sample_count,value_sum,value_min,value_max,histogram,first_observed_at,last_observed_at) SELECT $1,$2,$3,x.bucket_start::timestamptz,x.sample_count::bigint,x.value_sum::numeric,x.value_min::numeric,x.value_max::numeric,x.histogram,x.first_observed_at::timestamptz,x.last_observed_at::timestamptz FROM jsonb_to_recordset($4::jsonb) AS x(bucket_start text,sample_count text,value_sum text,value_min text,value_max text,histogram jsonb,first_observed_at text,last_observed_at text) ON CONFLICT(organisation_id,run_id,series_id,bucket_start) DO UPDATE SET sample_count=hyperfide.observability_metric_buckets.sample_count+EXCLUDED.sample_count,value_sum=hyperfide.observability_metric_buckets.value_sum+EXCLUDED.value_sum,value_min=LEAST(hyperfide.observability_metric_buckets.value_min,EXCLUDED.value_min),value_max=GREATEST(hyperfide.observability_metric_buckets.value_max,EXCLUDED.value_max),histogram=hyperfide.observability_add_histogram(hyperfide.observability_metric_buckets.histogram,EXCLUDED.histogram),first_observed_at=LEAST(hyperfide.observability_metric_buckets.first_observed_at,EXCLUDED.first_observed_at),last_observed_at=GREATEST(hyperfide.observability_metric_buckets.last_observed_at,EXCLUDED.last_observed_at)", [p.organisation_id, p.run_id, series.id, JSON.stringify([...buckets.values()])]);
    // Old aggregates are rebuildable observation data. Receipt identities stay until the bounded run history is archived.
    await tx.query("DELETE FROM hyperfide.observability_metric_buckets WHERE organisation_id=$1 AND run_id=$2 AND bucket_start<date_trunc('minute',clock_timestamp()-interval '72 hours')", [p.organisation_id, p.run_id]);
    return { recorded: samples.length, replayed: false, buckets: buckets.size, measurement_kind: kind, provenance: 'AUTHENTICATED_REPORT', independently_verified: false, cost_is_provider_billing_proof: false };
}
async function distribution(tx, p, id) {
    const s = await tx.query('SELECT * FROM hyperfide.observability_metric_series WHERE organisation_id=$1 AND run_id=$2 AND id=$3', [p.organisation_id, p.run_id, id]);
    if (!s.rows.length)
        return { status: 'UNKNOWN', reason: 'SERIES_MISSING', id };
    const series = s.rows[0], rows = await tx.query("SELECT * FROM hyperfide.observability_metric_buckets WHERE organisation_id=$1 AND run_id=$2 AND series_id=$3 AND bucket_start>=date_trunc('minute',clock_timestamp()-interval '72 hours') ORDER BY bucket_start LIMIT 4322", [p.organisation_id, p.run_id, id]);
    if (!rows.rows.length)
        return { status: 'UNKNOWN', reason: 'NO_RETAINED_MEASUREMENTS', series };
    const bounds = series.bucket_bounds, hist = Array(bounds.length + 1).fill(0n);
    let count = 0n, sum = 0n, min, max = 0n;
    for (const r of rows.rows) {
        count += BigInt(r.sample_count);
        sum += fixed(r.value_sum);
        const lo = fixed(r.value_min), hi = fixed(r.value_max);
        min = min === undefined ? lo : min < lo ? min : lo;
        max = max > hi ? max : hi;
        const h = r.histogram;
        if (h.length !== hist.length)
            fail('OBSERVABILITY_DATA_INVALID', 'Stored histogram shape changed');
        for (let i = 0; i < h.length; i++)
            hist[i] = hist[i] + BigInt(h[i]);
    }
    const quantile = (numerator, denominator) => { let seen = 0n; for (let i = 0; i < hist.length; i++) {
        seen += hist[i];
        if (seen * denominator >= count * numerator)
            return bounds[i] ?? null;
    } return null; };
    const refs = await tx.query('SELECT id,source_artifact_id,payload_digest,producer_actor_id,received_at FROM hyperfide.observability_metric_receipts WHERE organisation_id=$1 AND run_id=$2 AND series_id=$3 ORDER BY received_at DESC,id LIMIT 11', [p.organisation_id, p.run_id, id]);
    if (hist.reduce((a, b) => a + b, 0n) !== count)
        fail('OBSERVABILITY_DATA_INVALID', 'Histogram count mismatch');
    const proof = await integratedProof(tx, p);
    const reportedPerOutcome = series.name === 'cost' && series.measurement_kind === 'PROVIDER_INVOICE_REPORT' && proof.status === 'CURRENT' && BigInt(proof.count) > 0n ? display(sum / BigInt(proof.count)) : null;
    return numbers({ status: 'AVAILABLE', series, sample_count: count.toString(), sum: display(sum), mean: display(sum / count), min: display(min), max: display(max), histogram: hist.map(n => n.toString()), p50_upper_bound: quantile(1n, 2n), p95_upper_bound: quantile(95n, 100n), p99_upper_bound: quantile(99n, 100n), quantile_method: 'HISTOGRAM_UPPER_BOUND', source_receipts: refs.rows.slice(0, 10), source_receipts_truncated: refs.rows.length > 10, cost_report: series.name === 'cost' ? { kind: series.measurement_kind, reported_microcurrency_sum: display(sum), currency: series.currency, provider_billing_independently_verified: false } : null, overflow_quantile: null, first_observed_at: rows.rows[0].first_observed_at, last_observed_at: rows.rows.at(-1).last_observed_at, provenance: 'AUTHENTICATED_REPORT', independently_verified: false, actual_cost_per_current_qualified_integrated_outcome: null, reported_microcurrency_per_current_qualified_integrated_outcome: reportedPerOutcome, cost_denominator_proof: proof, cost_denominator_status: proof.status });
}
// Server-derived collection: the control plane measures these itself from durable rows, PostgreSQL lock state and its own bounded pool.
// Names, phases and bounds are fixed; values are run- or database-wide aggregates with no per-task/worker labels.
const DERIVED_BOUNDS = ['1', '10', '100', '1000', '10000', '60000', '600000', '3600000', '86400000'], DERIVED_ROWS = 10000;
function poolState(resources) { const d = resources?.describe?.(), v = d?.primary; return v && Number.isSafeInteger(v.maxActive) && Number.isSafeInteger(v.active) && Number.isSafeInteger(v.queued) ? { maxActive: v.maxActive, maxQueued: v.maxQueued, active: v.active, queued: v.queued } : null; }
class PoolPressure {
    resources;
    window = [];
    timer;
    samples_total = 0;
    saturated_total = 0;
    queued_total = 0;
    last_saturated_at = null;
    admission = [];
    constructor(resources) {
        this.resources = resources;
        const s = poolState(resources);
        if (s) {
            this.timer = setInterval(() => this.sample(), 100);
            this.timer.unref();
        }
    }
    sample() { const s = poolState(this.resources); if (!s)
        return; this.samples_total++; if (s.active >= s.maxActive) {
        this.saturated_total++;
        this.last_saturated_at = new Date().toISOString();
    } if (s.queued > 0)
        this.queued_total++; this.window.push({ at: Date.now(), active: s.active, queued: s.queued, max: s.maxActive }); while (this.window.length > 600)
        this.window.shift(); }
    admitted(ms) { this.admission.push(ms); while (this.admission.length > 256)
        this.admission.shift(); }
    describe() { if (!this.timer)
        return null; const w = this.window.filter(x => x.at >= Date.now() - 60000); return { interval_ms: 100, window_ms: 60000, window_samples: w.length, window_saturated_samples: w.filter(x => x.active >= x.max).length, window_queued_samples: w.filter(x => x.queued > 0).length, window_max_active: w.length ? Math.max(...w.map(x => x.active)) : null, window_max_queued: w.length ? Math.max(...w.map(x => x.queued)) : null, samples_total: this.samples_total, saturated_samples_total: this.saturated_total, queued_samples_total: this.queued_total, last_saturated_at: this.last_saturated_at }; }
    close() { if (this.timer)
        clearInterval(this.timer); this.timer = undefined; }
}
function summary(values, truncated) {
    if (!values.length)
        return { sample_count: '0', sum: null, mean: null, min: null, max: null, p50: null, p95: null, p99: null, histogram: null, truncated };
    const sorted = [...values].sort((a, b) => a - b), f = (n) => display(BigInt(Math.round(n * 1000)) * 1000n), q = (x) => f(sorted[Math.min(sorted.length - 1, Math.ceil(x * sorted.length) - 1)]), sum = sorted.reduce((a, b) => a + b, 0);
    const hist = Array(DERIVED_BOUNDS.length + 1).fill(0);
    for (const v of sorted) {
        const i = DERIVED_BOUNDS.findIndex(b => v <= Number(b));
        hist[i < 0 ? DERIVED_BOUNDS.length : i]++;
    }
    return { sample_count: String(sorted.length), sum: f(sum), mean: f(sum / sorted.length), min: f(sorted[0]), max: f(sorted.at(-1)), p50: q(0.5), p95: q(0.95), p99: q(0.99), histogram: hist.map(String), truncated };
}
function derived(name, phase, scope, basis, values, truncated, unknown, extra = {}) {
    return { name, phase, unit: METRICS[name], provenance: 'SERVER_DERIVED', scope, basis, bucket_bounds: DERIVED_BOUNDS, quantile_method: 'EXACT_NEAREST_RANK', status: values.length ? 'AVAILABLE' : 'UNKNOWN', reason: values.length ? null : unknown, ...summary(values, truncated), ...extra, independently_verified: false };
}
async function millis(tx, sql, values) {
    const r = await tx.query(sql, values), out = r.rows.map(x => Number(x.ms)).filter(n => Number.isFinite(n));
    return { values: out.slice(0, DERIVED_ROWS), truncated: out.length > DERIVED_ROWS };
}
async function serverDerived(tx, p, pressure, request) {
    const scope = [p.organisation_id, p.run_id, DERIVED_ROWS + 1];
    const ready = await millis(tx, "SELECT extract(epoch FROM a.first_at-t.created_at)*1000 AS ms FROM hyperfide.tasks t JOIN LATERAL (SELECT min(a.created_at) AS first_at FROM hyperfide.attempts a WHERE a.organisation_id=t.organisation_id AND a.run_id=t.run_id AND a.task_id=t.id AND a.kind='IMPLEMENTATION') a ON a.first_at IS NOT NULL WHERE t.organisation_id=$1 AND t.run_id=$2 AND a.first_at>=t.created_at ORDER BY a.first_at DESC LIMIT $3", scope);
    const tasks = (await tx.query("SELECT count(*) FILTER(WHERE NOT EXISTS(SELECT 1 FROM hyperfide.attempts a WHERE a.organisation_id=t.organisation_id AND a.run_id=t.run_id AND a.task_id=t.id AND a.kind='IMPLEMENTATION'))::text AS unstarted FROM hyperfide.tasks t WHERE t.organisation_id=$1 AND t.run_id=$2", [p.organisation_id, p.run_id])).rows[0];
    const lease = await millis(tx, "SELECT extract(epoch FROM min(l.created_at)-a.created_at)*1000 AS ms FROM hyperfide.compute_leases l JOIN hyperfide.attempts a ON a.organisation_id=l.organisation_id AND a.run_id=l.run_id AND a.id=l.attempt_id WHERE l.organisation_id=$1 AND l.run_id=$2 GROUP BY a.id,a.created_at HAVING min(l.created_at)>=a.created_at ORDER BY min(l.created_at) DESC LIMIT $3", scope);
    const lag = await millis(tx, "SELECT extract(epoch FROM d.acknowledged_at-e.created_at)*1000 AS ms FROM hyperfide.event_deliveries d JOIN hyperfide.outbox_events e ON e.organisation_id=d.organisation_id AND e.run_id=d.run_id AND e.id=d.event_id WHERE d.organisation_id=$1 AND d.run_id=$2 AND d.state='ACKNOWLEDGED' AND d.acknowledged_at>=e.created_at ORDER BY d.acknowledged_at DESC LIMIT $3", scope);
    const backlog = (await tx.query("SELECT count(*) FILTER(WHERE d.state IN ('PENDING','DELIVERING'))::text AS pending,count(*) FILTER(WHERE d.state='DEAD_LETTER')::text AS dead_letter,(extract(epoch FROM clock_timestamp()-min(e.created_at) FILTER(WHERE d.state IN ('PENDING','DELIVERING')))*1000)::numeric(20,3)::text AS oldest_pending_age_ms,coalesce(sum(greatest(d.attempt_count-1,0)),0)::text AS redeliveries FROM hyperfide.event_deliveries d JOIN hyperfide.outbox_events e ON e.organisation_id=d.organisation_id AND e.run_id=d.run_id AND e.id=d.event_id WHERE d.organisation_id=$1 AND d.run_id=$2", [p.organisation_id, p.run_id])).rows[0];
    const locks = await millis(tx, "SELECT extract(epoch FROM clock_timestamp()-l.waitstart)*1000 AS ms FROM pg_catalog.pg_locks l JOIN pg_catalog.pg_stat_activity s ON s.pid=l.pid WHERE NOT l.granted AND l.waitstart IS NOT NULL AND s.datname=current_database() AND l.pid<>pg_backend_pid() ORDER BY l.waitstart LIMIT $1", [DERIVED_ROWS + 1]);
    const db = (await tx.query("SELECT deadlocks::text AS deadlocks,stats_reset FROM pg_catalog.pg_stat_database WHERE datname=current_database()")).rows[0];
    const blocked = (await tx.query("SELECT count(DISTINCT l.pid)::text AS n FROM pg_catalog.pg_locks l JOIN pg_catalog.pg_stat_activity s ON s.pid=l.pid WHERE NOT l.granted AND s.datname=current_database() AND l.pid<>pg_backend_pid()")).rows[0];
    const pool = pressure.describe();
    return numbers({ provenance: 'SERVER_DERIVED', as_of: (await tx.query('SELECT clock_timestamp() AS now')).rows[0].now, cardinality: 'FIXED_NAMES_NO_ENTITY_LABELS', row_limit: DERIVED_ROWS, metrics: {
            readiness_to_start: derived('readiness_to_start', 'READINESS', 'RUN', 'TASK_RECORDED_TO_FIRST_IMPLEMENTATION_ATTEMPT_UPPER_BOUND', ready.values, ready.truncated, 'NO_STARTED_TASKS', { unstarted_tasks: tasks.unstarted }),
            lease_latency: derived('lease_latency', 'INFRASTRUCTURE', 'RUN', 'ATTEMPT_CREATED_TO_FIRST_COMPUTE_LEASE', lease.values, lease.truncated, 'NO_COMPUTE_LEASES'),
            event_lag: derived('event_lag', 'INFRASTRUCTURE', 'RUN', 'OUTBOX_CREATED_TO_DELIVERY_ACKNOWLEDGED', lag.values, lag.truncated, 'NO_ACKNOWLEDGED_DELIVERIES', { pending_deliveries: backlog.pending, dead_letter_deliveries: backlog.dead_letter, oldest_pending_age_ms: backlog.oldest_pending_age_ms ?? null, redeliveries: backlog.redeliveries }),
            db_lock_wait: derived('db_lock_wait', 'INFRASTRUCTURE', 'DATABASE', 'CURRENT_UNGRANTED_LOCK_WAITS', locks.values, locks.truncated, 'NO_CURRENT_LOCK_WAITS', { blocked_backends: blocked.n, deadlocks_total: db?.deadlocks ?? null, deadlock_counter_reset_at: db?.stats_reset ?? null }),
            db_pool_wait: derived('db_pool_wait', 'INFRASTRUCTURE', 'PROCESS', 'COMPONENT_REQUEST_TO_PRIMARY_TRANSACTION_ADMISSION', pressure.admission, false, 'NO_ADMISSIONS_OBSERVED', { pool_at_request_entry: request.pool_at_entry, pool_sampler: pool, pressure_status: pool === null ? 'UNKNOWN' : pool.window_queued_samples > 0 ? 'EXHAUSTED' : pool.window_saturated_samples > 0 ? 'SATURATED' : 'NONE_OBSERVED' })
        }, request: { queue_wait_ms: display(BigInt(Math.round(request.queue_wait_ms * 1000)) * 1000n), queue_wait_basis: 'COMPONENT_ENTRY_TO_PRIMARY_TRANSACTION_ADMISSION_EXCLUDES_GATEWAY_AUTHENTICATION', api_latency_ms: null, api_latency_basis: 'MEASURED_BY_CALLER_NOT_COMPONENT', queue_wait_is_api_latency: false } });
}
export function createComponent(startup) {
    const pressure = new PoolPressure(startup.resources);
    const timed = (ctx, operation, fn) => { const entered = performance.now(), pool_at_entry = poolState(ctx.resources); return authority(ctx, operation, (tx, p) => { const queue_wait_ms = performance.now() - entered; pressure.admitted(queue_wait_ms); return fn(tx, p, { queue_wait_ms, pool_at_entry }); }); };
    return { apiVersion: 1, close: () => pressure.close(), actions: {
            'fleet.metrics.describe': async (input) => { object(input, []); return { schema_version: 1, metrics: METRICS, phases: PHASES, series_limit: 128, receipt_limit: 100000, batch_limit: 100, retained_hours: 72, queue_wait_is_api_latency: false, unknown: 'NULL_OR_EXPLICIT_UNKNOWN', server_derived: ['readiness_to_start', 'lease_latency', 'event_lag', 'db_lock_wait', 'db_pool_wait'], resource_pressure: startup.resources?.describe() ?? null }; },
            'fleet.metrics.record': (input, ctx) => timed(ctx, 'fleet.metrics.record', (tx, p) => recordMetrics(tx, p, input)),
            'fleet.metrics.snapshot': (input, ctx) => timed(ctx, 'fleet.metrics.snapshot', async (tx, p, request) => { const v = object(input, ['series_id', 'server_derived']); if ((v.series_id === undefined) === (v.server_derived === undefined) || v.server_derived !== undefined && v.server_derived !== true)
                fail('OBSERVABILITY_INPUT_INVALID', 'Exactly one of series_id or server_derived:true required'); return v.series_id === undefined ? serverDerived(tx, p, pressure, request) : distribution(tx, p, uuid(v.series_id)); }),
            'fleet.metrics.compare': (input, ctx) => timed(ctx, 'fleet.metrics.compare', async (tx, p) => { const v = object(input, ['baseline_series_id', 'current_series_id']), baseline = await distribution(tx, p, uuid(v.baseline_series_id)), current = await distribution(tx, p, uuid(v.current_series_id)); if (baseline.status !== 'AVAILABLE' || current.status !== 'AVAILABLE')
                return { comparable: false, reason: 'MEASUREMENTS_UNAVAILABLE', baseline, current }; const a = baseline.series, b = current.series, comparable = a.variant === 'BASELINE' && b.variant === 'CURRENT' && a.name === b.name && a.phase === b.phase && a.profile_key === b.profile_key && a.unit === b.unit && a.currency === b.currency && a.provenance_digest === b.provenance_digest && a.measurement_kind === b.measurement_kind && JSON.stringify(a.bucket_bounds) === JSON.stringify(b.bucket_bounds); return { comparable, reason: comparable ? 'MATCHED_DECLARED_WORKLOAD_AND_ENVIRONMENT' : 'PROVENANCE_OR_MEASUREMENT_MISMATCH', baseline, current, improvement_claim: comparable ? 'DESCRIPTIVE_COMPARISON_ONLY' : 'NOT_COMPARABLE', uncertainty: 'NO_CAUSAL_OR_STATISTICAL_SIGNIFICANCE_CLAIM' }; })
        } };
}
//# sourceMappingURL=metrics.js.map