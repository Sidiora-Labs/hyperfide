import type { Component, ComponentContext } from '../components/registry.js';
/** Each response observes one primary snapshot; continuation pages observe fresh snapshots. */
export declare function createComponent(context: ComponentContext): Component;
