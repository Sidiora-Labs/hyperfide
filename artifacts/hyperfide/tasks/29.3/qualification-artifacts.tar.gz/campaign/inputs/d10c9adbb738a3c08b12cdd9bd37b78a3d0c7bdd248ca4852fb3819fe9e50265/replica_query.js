import { FoundationError, object } from '../policy/programme.js';
import { assertPrimaryTransaction, assertTransactionStatement, StorageError } from '../storage/transactions.js';
import { canonical, exact, fail } from './extraction.js';
import { graphTransaction } from './ingestion.js';
import { publishedGraph } from './publication.js';
import { readPublishedManifest } from './projection_extract.js';
export function graphReadOptions(value) {
    const v = exact(value, ['route'], ['fallback', 'wait_ms', 'cache']);
    const route = v.route, fallback = v.fallback ?? 'NONE', wait = v.wait_ms ?? 250, cache = v.cache ?? 'BYPASS';
    if ((route !== 'PRIMARY' && route !== 'REPLICA') || (fallback !== 'NONE' && fallback !== 'PRIMARY') || (cache !== 'BYPASS' && cache !== 'USE') || !Number.isSafeInteger(wait) || Number(wait) < 0 || Number(wait) > 5000)
        fail('GRAPH_INVALID', 'Invalid graph read options');
    if (route === 'PRIMARY' && fallback !== 'NONE')
        fail('GRAPH_INVALID', 'Primary reads have no fallback route');
    return { route, fallback, wait_ms: Number(wait), cache };
}
const LSN = /^[0-9A-F]{1,8}\/[0-9A-F]{1,8}$/;
function lsn(value) { if (!LSN.test(value))
    throw new StorageError('REPLICA_TOPOLOGY_MISMATCH', 'Canonical WAL position is required'); const [high, low] = value.split('/'); return (BigInt('0x' + high) << 32n) + BigInt('0x' + low); }
const REPLICA_CODES = ['DATABASE_CONFIG_INVALID', 'REPLICA_REQUIRED', 'REPLICA_LAG', 'REPLICA_TOPOLOGY_MISMATCH', 'REPLICA_TOPOLOGY_PRIVILEGE_REQUIRED', 'REPLICA_VERSION_MISMATCH', 'DB_UNAVAILABLE', 'DB_OVERLOADED', 'TX_TIMEOUT', 'REPLICA_UNAVAILABLE'];
const OFFLINE_CODES = ['DB_UNAVAILABLE', 'DB_OVERLOADED', 'TX_TIMEOUT'];
// Bounded by entry count and total bytes; least recently used entries are evicted first.
export class GraphQueryCache {
    capacity;
    maxBytes;
    entries = new Map();
    bytes = 0;
    hits = 0;
    misses = 0;
    evictions = 0;
    constructor(capacity, maxBytes = 16 * 1024 * 1024) {
        this.capacity = capacity;
        this.maxBytes = maxBytes;
    }
    get(key) { const entry = this.entries.get(key); if (entry === undefined) {
        this.misses++;
        return undefined;
    } this.hits++; this.entries.delete(key); this.entries.set(key, entry); return entry.value; }
    set(key, value) {
        const bytes = Buffer.byteLength(JSON.stringify(value)) + Buffer.byteLength(key);
        if (this.capacity === 0 || bytes > this.maxBytes)
            return;
        this.remove(key);
        this.entries.set(key, { value, bytes });
        this.bytes += bytes;
        while (this.entries.size > this.capacity || this.bytes > this.maxBytes) {
            this.remove(this.entries.keys().next().value);
            this.evictions++;
        }
    }
    remove(key) { const entry = this.entries.get(key); if (entry) {
        this.bytes -= entry.bytes;
        this.entries.delete(key);
    } }
    describe() { return { capacity: this.capacity, max_bytes: this.maxBytes, entries: this.entries.size, bytes: this.bytes, hits: this.hits, misses: this.misses, evictions: this.evictions, authority: 'NONE' }; }
}
export function cacheCapacity(env) {
    const raw = env.HYPERFIDE_GRAPH_QUERY_CACHE_ENTRIES;
    if (raw === undefined)
        return 64;
    if (!/^(0|[1-9][0-9]{0,3})$/.test(raw) || Number(raw) > 1024)
        throw new FoundationError('GRAPH_CONFIG_INVALID', 'Graph query cache capacity must be 0..1024');
    return Number(raw);
}
function route(manifest, value) { return { ...manifest, query_route: { exact_version: true, authority: 'NONE', ...value } }; }
function replicaCode(error) {
    if (error instanceof FoundationError)
        return REPLICA_CODES.includes(error.code) ? error.code : null;
    return 'REPLICA_UNAVAILABLE';
}
async function admit(ctx, s, manifestId, barrier) {
    try {
        return await graphTransaction(ctx, s, async (tx) => {
            assertPrimaryTransaction(tx);
            const manifest = await publishedGraph(tx, s, manifestId);
            if (!barrier)
                return { manifest, barrier: null };
            const row = (await tx.query("SELECT pg_current_wal_lsn()::text AS lsn,has_function_privilege(current_user,'pg_catalog.pg_control_system()','EXECUTE') AS privileged")).rows[0];
            if (!row.privileged)
                return { manifest, barrier: { lsn: row.lsn, system_id: '' } };
            const system = (await tx.query('SELECT system_identifier::text AS id FROM pg_control_system()')).rows[0].id;
            return { manifest, barrier: { lsn: row.lsn, system_id: system } };
        }, false);
    }
    catch (error) {
        if (error instanceof FoundationError && !OFFLINE_CODES.includes(error.code))
            throw error;
        throw new FoundationError('GRAPH_AUTHORITY_OFFLINE', 'Primary admission is unavailable; replicas and caches are never consulted without current exact-version admission');
    }
}
async function replicaRead(ctx, s, manifestId, admitted, options, operation) {
    const barrier = admitted.barrier;
    if (!barrier.system_id)
        throw new StorageError('REPLICA_TOPOLOGY_PRIVILEGE_REQUIRED', 'Trusted operator must grant pg_control_system observation to the runtime role');
    const signal = ctx.invocation?.signal;
    return ctx.resources.withReplicaConnection({ timeoutMs: Math.min(30000, options.wait_ms + 15000), ...(signal ? { signal } : {}) }, async (session) => {
        const privileged = (await session.query("SELECT has_function_privilege(current_user,'pg_catalog.pg_control_system()','EXECUTE') AS ok")).rows[0]?.ok;
        if (!privileged)
            throw new StorageError('REPLICA_TOPOLOGY_PRIVILEGE_REQUIRED', 'Replica runtime role cannot observe cluster identity');
        const started = performance.now(), until = started + options.wait_ms;
        let replayed = null, observations = 0;
        for (;;) {
            observations++;
            const state = (await session.query('SELECT s.system_identifier::text AS system_id,pg_last_wal_replay_lsn()::text AS replay_lsn,pg_is_in_recovery() AS recovery FROM pg_control_system() s')).rows[0];
            if (!state.recovery || state.system_id !== barrier.system_id)
                throw new StorageError('REPLICA_TOPOLOGY_MISMATCH', 'Replica is not a standby of the admitting primary cluster');
            if (state.replay_lsn && lsn(state.replay_lsn) >= lsn(barrier.lsn)) {
                replayed = state.replay_lsn;
                break;
            }
            if (performance.now() >= until)
                throw new StorageError('REPLICA_LAG', 'Replica has not replayed the primary admission barrier within the requested wait');
            await new Promise(resolve => setTimeout(resolve, Math.max(1, Math.min(25, until - performance.now()))));
        }
        const waited = Math.floor(performance.now() - started);
        await session.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');
        let valid = true;
        const snapshot = Object.freeze({
            query: async (sql, values) => { if (!valid)
                throw new StorageError('TX_CLOSED', 'Replica graph snapshot expired'); assertTransactionStatement(sql); return session.query(sql, values); },
            remainingMs: () => session.remainingMs(), signal: session.signal
        });
        try {
            const manifest = await readPublishedManifest(snapshot, s, manifestId).catch((error) => { if (error instanceof FoundationError && error.code === 'GRAPH_VERSION_UNAVAILABLE')
                throw new StorageError('REPLICA_VERSION_MISMATCH', 'Replica snapshot lacks the admitted exact manifest'); throw error; });
            if (manifest.manifest_digest !== admitted.manifest.manifest_digest || manifest.build_id !== admitted.manifest.build_id)
                throw new StorageError('REPLICA_VERSION_MISMATCH', 'Replica manifest identity differs from primary admission');
            const result = await operation(snapshot, route(manifest, { route: 'REPLICA', cache: options.cache === 'USE' ? 'MISS' : 'NONE', snapshot: 'REPEATABLE_READ_REPLICA_AFTER_PRIMARY_BARRIER',
                barrier_lsn: barrier.lsn, replay_lsn: replayed, replay_wait_ms: waited, observations, fallback: null }));
            const after = (await snapshot.query('SELECT pg_is_in_recovery() AS recovery')).rows[0];
            if (!after.recovery)
                throw new StorageError('REPLICA_TOPOLOGY_MISMATCH', 'Replica was promoted while reading');
            await session.query('COMMIT');
            return result;
        }
        finally {
            valid = false;
        }
    });
}
export function routedGraphQueryExecutor(primary, cache) {
    return async (ctx, s, manifestId, query, operation) => {
        if (query.read_options === undefined)
            return primary(ctx, s, manifestId, query, operation);
        const options = graphReadOptions(query.read_options);
        const admitted = await admit(ctx, s, manifestId, options.route === 'REPLICA');
        const key = canonical({ manifest_id: manifestId, manifest_digest: admitted.manifest.manifest_digest, build_id: admitted.manifest.build_id, kind: query.kind, input: query.input, max_bytes: query.max_bytes });
        if (options.cache === 'USE') {
            const hit = cache.get(key);
            if (hit) {
                const original = object(hit.provenance) ? hit.provenance : {};
                return { ...hit, provenance: { ...original, route: 'CACHE', cached_route: original.route ?? null, cache: 'HIT', cache_authority: 'NONE', admitted_by: 'PRIMARY_EXACT_MANIFEST_THIS_REQUEST' } };
            }
        }
        const store = (value) => { if (options.cache === 'USE' && value.complete === true)
            cache.set(key, value); return value; };
        const primaryRead = (fallback) => primary(ctx, s, manifestId, query, (session, manifest) => operation(session, route(manifest, { route: 'PRIMARY', cache: options.cache === 'USE' ? 'MISS' : 'NONE', snapshot: 'SERIALIZABLE_PRIMARY', fallback })));
        if (options.route === 'PRIMARY')
            return store(await primaryRead(null));
        try {
            return store(await replicaRead(ctx, s, manifestId, admitted, options, operation));
        }
        catch (error) {
            const code = replicaCode(error);
            if (!code)
                throw error;
            if (options.fallback === 'PRIMARY')
                return store(await primaryRead({ requested: 'REPLICA', reason: code }));
            if (code === 'REPLICA_LAG')
                throw new FoundationError('GRAPH_REPLICA_LAG', 'Replica is behind the primary admission barrier; no primary fallback was declared');
            throw new FoundationError('GRAPH_REPLICA_UNAVAILABLE', 'Replica read refused (' + code + '); no primary fallback was declared');
        }
    };
}
//# sourceMappingURL=replica_query.js.map