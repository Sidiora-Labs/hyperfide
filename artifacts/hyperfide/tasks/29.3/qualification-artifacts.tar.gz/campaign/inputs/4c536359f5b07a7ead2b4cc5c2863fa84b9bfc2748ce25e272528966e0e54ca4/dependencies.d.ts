import type { AuthorityTransaction } from '../transport/protocol.js';
import type { Component, ComponentContext } from '../components/registry.js';
type Tx = AuthorityTransaction;
export interface DependencyScope {
    organisation_id: string;
    run_id: string;
}
export interface PlanPins {
    run_id: string;
    spec_revision_id: string;
    spec_generation: string;
    state_version: string;
}
export interface DependencyDiagnostic {
    code: string;
    run_id: string;
    task_key?: string;
    section?: string | undefined;
    key?: string | undefined;
    line?: number | undefined;
    target?: string | undefined;
    path?: string[] | undefined;
    path_truncated?: boolean;
    cycle_length?: number;
    qualified_target?: string;
    candidates?: string[];
    scope_path?: string;
    owners?: string[];
    excerpt?: string;
}
export interface AcceptedDependency {
    task_id: string;
    source_spec_generation: string;
    predecessor_run_id: string;
    predecessor_task_id: string;
    predecessor_spec_generation: string;
    predecessor_spec_revision_id: string;
    predecessor_repository_id: string | null;
    integration_ref: string | null;
    milestone: 'QUALIFIED' | 'INTEGRATED';
}
export interface ProposedDependencyTask {
    package_key: string;
    package_wave: number;
    id: string;
    task_key: string;
    definition: Record<string, any>;
    wave: number;
    state: string;
    state_version: string;
    spec_generation: string;
    spec_revision_id: string;
    criteria_digest: string;
    run_id: string;
}
export interface DependencyReport {
    status: 'STRUCTURALLY_VALID' | 'INVALID';
    authority: 'STRUCTURAL_VALIDATION';
    spec_revision_id: string;
    spec_generation: string;
    state_version: string;
    task_count: number;
    edge_count: number;
    diagnostic_count: number;
    diagnostics_truncated: boolean;
    diagnostics: DependencyDiagnostic[];
    coordination_count: number;
    coordination_diagnostics: DependencyDiagnostic[];
    edges: AcceptedDependency[];
    edge_summary: {
        qualified_revision: number;
        integrated_target: number;
        cross_feature: number;
        cross_run: number;
        cross_repository: number;
    };
}
export declare function validateProposedDependencies(tx: Tx, scope: DependencyScope, input: PlanPins, tasks: ProposedDependencyTask[]): Promise<DependencyReport>;
export declare function validateDependencies(tx: Tx, scope: DependencyScope, input: PlanPins): Promise<DependencyReport>;
export interface AdmissionOptions {
    exempt_task_ids?: readonly string[];
}
export declare function admitDependencies(tx: Tx, scope: DependencyScope, input: PlanPins, options?: AdmissionOptions): Promise<Omit<DependencyReport, 'edges'> & {
    admitted: boolean;
    proof_obligations: 'ENFORCED_AT_DISPATCH_ADMISSION';
}>;
export declare function resolveTask(tx: Tx, scope: DependencyScope, input: unknown): Promise<unknown>;
export declare function structuralFrontier(tx: Tx, scope: DependencyScope, input: unknown): Promise<unknown>;
export declare function createComponent(_startup: ComponentContext): Component;
export {};
