import type { AuthorityTransaction } from '../transport/protocol.js';
import type { Component, ComponentContext } from '../components/registry.js';
export interface ProofPins {
    organisation_id: string;
    run_id: string;
    task_id: string;
    spec_generation: string;
    spec_revision_id: string;
}
export interface ProofCheck {
    id: string;
    argv: string[];
    executable_digest: string;
    timeout_ms: number;
    required_artifacts: string[];
    input_keys: string[];
}
export interface ProofClause {
    id: string;
    mode: 'EXECUTABLE' | 'REVIEW';
    acceptance_ids: string[];
    checks?: string[];
    reviewers?: string[];
    rubric_digest?: string;
}
export interface ProofPolicy {
    schema_version: 1;
    criteria_digest: string;
    spec_revision_id: string;
    spec_generation: string;
    repository_id: string;
    source_object_id: string;
    rubric_digest: string;
    checks: ProofCheck[];
    clauses: ProofClause[];
    inputs: Record<string, string>;
    contract_digests: string[];
}
export interface ProofObligations {
    registry_digest: string;
    criteria_digest: string;
    spec_revision_id: string;
    spec_generation: string;
    policy: ProofPolicy;
    obligations: {
        clause_id: string;
        acceptance_ids: string[];
        required_checks: string[];
        review_rubric?: {
            reviewers: string[];
            rubric_digest: string;
        };
    }[];
}
export type PrimaryClient = AuthorityTransaction;
export declare function validateProofPolicy(value: unknown): ProofPolicy;
export declare function loadProofObligations(db: PrimaryClient, scope: ProofPins): Promise<ProofObligations>;
export declare function registerProofPolicy(client: PrimaryClient, scope: {
    organisation_id: string;
    run_id: string;
}, input: unknown, allowReview?: boolean, maximumMs?: number): Promise<ProofObligations>;
export declare function createComponent(_startup: ComponentContext): Component;
