import type { ComponentContext } from '../components/registry.js';
import type { GraphQueryExecutor } from './query.js';
export declare function contracts(input: unknown, ctx: ComponentContext, executor?: GraphQueryExecutor): Promise<unknown>;
