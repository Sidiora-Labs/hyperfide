import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { PrimaryTransaction, TransactionGateway } from '../storage/transactions.js';
export type SessionRole = 'LEADER' | 'FEATURE_MANAGER' | 'WORKER' | 'COMMIT_WATCHER' | 'ISSUE_WATCHER' | 'VERIFIER' | 'INTEGRATOR' | 'INDEXER';
export interface Scope {
    organisation_id: string;
    run_id: string;
}
export interface AuthorityRequest extends Scope {
    authority_epoch: string;
    session_id: string;
    leader_generation: string;
    package_id?: string;
    package_generation?: string;
    roles: readonly SessionRole[];
}
export interface Leadership extends Scope {
    authority_epoch: string;
    leader_session_id: string;
    leader_generation: string;
}
export interface AuthorityView extends Leadership {
    session_id: string;
    role: SessionRole;
    package_id?: string;
    package_generation?: string;
}
export interface HierarchyAuthority {
    leadership(tx: PrimaryTransaction, scope: Scope): Promise<Leadership>;
    requireAuthority(tx: PrimaryTransaction, input: AuthorityRequest): Promise<AuthorityView>;
    requireLeaderReplacement(tx: PrimaryTransaction, input: LeaderReplacementRequest): Promise<Record<string, unknown>>;
}
export interface LeaderReplacementRequest extends Scope {
    actor_session_id: string;
    current_leader_generation: string;
    predecessor_session_id: string;
    predecessor_generation: string;
    predecessor_authority_epoch: string;
}
/** Immutable replacement proof for adopting an already-persisted leader-targeted intent. */
export declare function requireLeaderReplacement(tx: PrimaryTransaction, input: LeaderReplacementRequest): Promise<Record<string, unknown>>;
type Data = Record<string, unknown>;
export declare function refuse(code: string, message: string): never;
export declare function record(value: unknown, keys: readonly string[], required?: readonly string[]): Data;
export declare function text(value: unknown, max?: number): string;
export declare function uuid(value: unknown): string;
export declare function decimal(value: unknown, zero?: boolean): string;
export declare function digest(value: unknown): string;
export declare function canonical(value: unknown, depth?: number): string;
export declare function hash(value: unknown): string;
export declare function strings(value: unknown, max?: number): string[];
export declare function isGateway(value: unknown): value is TransactionGateway;
export declare function gateway(context: ComponentContext): TransactionGateway;
export declare function isHierarchyAuthority(value: unknown): value is HierarchyAuthority;
export declare function leadership(tx: PrimaryTransaction, scope: Scope): Promise<Leadership>;
export declare function requireAuthority(tx: PrimaryTransaction, input: AuthorityRequest): Promise<AuthorityView>;
export interface TrustedActor extends Scope {
    session_id: string;
    authority_epoch: string;
    guard: (tx: PrimaryTransaction) => Promise<void>;
    signal: AbortSignal;
    invocation: InvocationContext;
}
export declare function trustedActor(context: ComponentContext): TrustedActor;
export declare const HIERARCHY_TABLES: readonly string[];
export declare function ready(tx: PrimaryTransaction): Promise<void>;
export declare function event(tx: PrimaryTransaction, actor: TrustedActor, generation: string, kind: string, payload: Data): Promise<void>;
export declare function hierarchyReadGuard(actor: TrustedActor): (tx: PrimaryTransaction) => Promise<void>;
export declare function hierarchyWriteGuard(actor: TrustedActor): (tx: PrimaryTransaction) => Promise<void>;
export declare function operation<T>(g: TransactionGateway, actor: TrustedActor, name: string, input: Data, fn: (tx: PrimaryTransaction) => Promise<T>): Promise<T>;
export declare const PACKAGE_STATES: readonly string[];
/** Explicit lifecycle moves (the migration trigger enforces the same graph). HANDOFF_PENDING is entered and left only by propose, acknowledge and withdraw. */
export declare const PACKAGE_LIFECYCLE: Readonly<Record<string, readonly string[]>>;
export declare function createComponent(context: ComponentContext): Promise<Component>;
export {};
