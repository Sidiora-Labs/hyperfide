import pg from 'pg';
import { FoundationError } from '../policy/programme.js';
export declare class StorageError extends FoundationError {
    readonly outcome: 'aborted' | 'unknown';
    readonly attempts: number;
    readonly retryable: boolean;
    constructor(code: string, message: string, outcome?: 'aborted' | 'unknown', attempts?: number, retryable?: boolean);
}
export interface QuerySession {
    query<R extends pg.QueryResultRow = pg.QueryResultRow>(text: string, values?: readonly unknown[]): Promise<pg.QueryResult<R>>;
    remainingMs(): number;
    readonly signal: AbortSignal;
}
declare const primaryBrand: unique symbol;
export interface PrimaryTransaction extends QuerySession {
    readonly [primaryBrand]: true;
    copyFrom(sql: string, bytes: Uint8Array): Promise<{
        rowCount: number;
    }>;
}
export declare function assertPrimaryTransaction(value: unknown): asserts value is PrimaryTransaction;
export interface TransactionOptions {
    timeoutMs?: number;
    maxRetries?: number;
    signal?: AbortSignal;
    guard?: (transaction: PrimaryTransaction) => void | Promise<void>;
}
export interface DatabaseLease {
    client: pg.PoolClient;
    signal: AbortSignal;
    release(destroy?: boolean): void;
}
export interface PrimaryConnectionSource {
    commitMode?(): 'on' | 'remote_apply';
    validateCommit?(client: pg.PoolClient): Promise<void>;
    acquirePrimary(deadline: number, signal?: AbortSignal): Promise<DatabaseLease>;
}
export declare function deadlineFrom(timeoutMs?: number): number;
export declare function bounded<T>(promise: Promise<T>, deadline: number, signal?: AbortSignal): Promise<T>;
export declare function assertTransactionStatement(sql: string): void;
export declare class TransactionGateway {
    private readonly source;
    constructor(source: PrimaryConnectionSource);
    withPrimaryTransaction<T>(options: TransactionOptions, operation: (tx: PrimaryTransaction) => Promise<T> | T): Promise<T>;
}
export {};
