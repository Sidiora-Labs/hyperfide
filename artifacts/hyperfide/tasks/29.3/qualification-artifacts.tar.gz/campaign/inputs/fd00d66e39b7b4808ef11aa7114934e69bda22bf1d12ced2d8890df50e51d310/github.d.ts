interface GitHubProfile {
    owner: string;
    repository: string;
    repository_numeric_id: number;
    app_id: number;
    installation_id: number;
    app_private_key_file: string;
    audit_token_file: string;
    denial_receipt_file: string;
    denial_signer_public_key_file: string;
    expected_rules_digest: string;
    credential_directory: string;
    target_ref: string;
}
export interface GitHubProtection {
    provider: 'GITHUB';
    repository_identity: string;
    repository_numeric_id: number;
    protected_ref: string;
    observed_head: string;
    rules_digest: string;
    publisher_identity: string;
    direct_push_denial_receipt_digest: string;
    policy_observed_at: string;
}
export interface GitHubIntent {
    organisation_id: string;
    run_id: string;
    operation_id: string;
    operation_generation: string;
    repository_id: string;
    target_ref: string;
    expected_old_head: string;
    candidate_head: string;
    candidate_digest: string;
}
export interface HostedResult {
    outcome: 'PUBLISHED' | 'REJECTED' | 'UNKNOWN';
    observed_head: string;
    credential_revocation: 'CONFIRMED' | 'UNKNOWN';
    rules_digest: string;
    push_issued?: boolean;
    credential_expires_at?: string | null;
    credential_custody?: 'PERSISTED' | 'ORPHANED';
    failure_stage?: string;
}
export type GitHubTransport = (route: string, token: string, method?: string, body?: unknown) => Promise<{
    status: number;
    body: unknown;
}>;
export declare function githubHTTP(route: string, token: string, method?: string, body?: unknown): Promise<{
    status: number;
    body: unknown;
}>;
export declare function loadGitHubProfile(env: Readonly<NodeJS.ProcessEnv>, repositoryId: string): Promise<GitHubProfile>;
export declare function validateGitHubProtection(profile: GitHubProfile, repository: unknown, activeRules: unknown, rulesets: unknown[], classic: unknown): string;
export declare class GitHubPublicationAdapter {
    private readonly profile;
    private readonly env;
    private readonly request;
    constructor(profile: GitHubProfile, env: Readonly<NodeJS.ProcessEnv>, request?: GitHubTransport);
    private base;
    private audit;
    private jwt;
    observeHead(): Promise<string>;
    private denial;
    inspectProtection(): Promise<GitHubProtection>;
    private credentialPath;
    private persistCredential;
    revokeCredential(intent: GitHubIntent): Promise<boolean>;
    private preflightCustody;
    publish(intent: GitHubIntent, repositoryPath: string): Promise<HostedResult>;
    reconcile(intent: GitHubIntent): Promise<HostedResult>;
}
export declare function githubAdapter(env: Readonly<NodeJS.ProcessEnv>, repositoryId: string): Promise<GitHubPublicationAdapter>;
export {};
