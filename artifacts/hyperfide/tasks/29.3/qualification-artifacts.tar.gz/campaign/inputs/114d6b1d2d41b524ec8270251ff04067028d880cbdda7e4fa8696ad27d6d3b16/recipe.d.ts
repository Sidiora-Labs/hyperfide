import type { PreparationRecipePolicy } from './effective.js';
export type PreparationJobClass = 'PREPARATION' | 'INDEX';
/** Deterministic remote job plan; the 11.1 manifest digest is the reusable preparation identity. */
export interface PreparationPlan {
    schema_version: 1;
    kind: 'hyperfide.preparation-plan';
    job_class: PreparationJobClass;
    placement: {
        job_class: 'dependency_preparation' | 'indexing';
        location: 'REMOTE_EXECUTION';
    };
    profile_id: string;
    profile_version: string;
    preparation_digest: string;
    configuration_digest: string;
    recipe_digest: string;
    toolchain_digest: string;
    lock_digest: string;
    source_digest: string;
    repositories: {
        id: string;
        commit: string;
        submodules: {
            path: string;
            commit: string;
        }[];
        lfs: boolean;
    }[];
    policy: PreparationRecipePolicy;
}
export interface ResolvedPreparation {
    identity: string;
    plan: PreparationPlan;
    plan_digest: string;
    recipe_digest: string;
}
export declare const planDigest: (plan: PreparationPlan) => string;
/** Bytes come from the operator-owned recipe store and must match the digest pinned by the manifest. */
export declare function readTrustedRecipe(env: Readonly<NodeJS.ProcessEnv>, digest: string): Promise<Uint8Array>;
/**
 * Pure resolution: the same manifest, recipe bytes, pool configuration and job class always yield
 * the same plan digest. A changed recipe, toolchain, lock or source pin changes the manifest digest.
 */
export declare function resolvePreparationPlan(input: {
    manifest: unknown;
    recipe: Uint8Array;
    configuration_digest: string;
    job_class: PreparationJobClass;
}): ResolvedPreparation;
