import { runService } from './components/service.js';
await runService('dispatch');
//# sourceMappingURL=dispatch.js.map