import type { ComponentContext } from '../components/registry.js';
import type { ReviewDb, ReviewScope } from './coverage.js';
type Data = Record<string, any>;
/** Index actual observations already made by the independent native recipe and
 * checker. This does not invent a second execution lease or relabel a custody. */
export declare function recordRepairReproduction(ctx: ComponentContext, raw: unknown): Promise<unknown>;
export declare function inspectRepairReproduction(db: ReviewDb, s: ReviewScope, id: string): Promise<Data | null>;
export {};
