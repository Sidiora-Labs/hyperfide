import type { Component, ComponentContext } from '../components/registry.js';
export declare function publicationBlocked(tx: {
    query: (sql: string, values: unknown[]) => Promise<{
        rows: Record<string, unknown>[];
    }>;
}, org: string, run: string): Promise<boolean>;
export declare function createComponent(_context: ComponentContext): Component;
