import type { Component, ComponentContext } from '../components/registry.js';
import { type Data } from './audit.js';
export interface RankingSource {
    eligibleTasks(tx: unknown, query: {
        organisation_id: string;
        run_id: string;
        pool_id: string;
        profile_id?: string;
        limit?: number;
    }): Promise<Data>;
}
export declare function rankingSource(value: unknown): value is RankingSource;
export declare function findingSnapshot(value: unknown, scope: {
    organisation_id: string;
    run_id: string;
}): Data;
export declare function findingAdviceEntries(value: unknown): Data[];
export declare function rankingState(value: unknown): Data;
export declare function rankAdvice(value: unknown, state: Data): Data;
export declare function rankTyped(value: unknown, state: Data): Data;
export declare function rankingQuestions(state: Data): Data;
export declare function deterministicRanking(state: Data): Data;
export declare const consumerPurposes: Readonly<{
    [k: string]: Readonly<{
        actions: readonly string[];
        fallback: "COLLECTED_ORDER" | "OMITTED" | "UNCLASSIFIED" | "UNDECIDED";
        authority: "NONE";
    }>;
}>;
export declare function createComponent(ctx: ComponentContext): Component;
