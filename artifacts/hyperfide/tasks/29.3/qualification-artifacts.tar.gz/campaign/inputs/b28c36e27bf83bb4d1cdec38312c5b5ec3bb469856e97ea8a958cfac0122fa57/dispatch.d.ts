import type { Component, ComponentContext } from '../components/registry.js';
import type { PrimaryTransaction } from '../storage/transactions.js';
import { receive } from '../events/inbox.js';
import type { ComputeToken, SchedulerScope } from './claim.js';
export interface NativeDispatchObservation {
    central_receipt_id: string;
    command_id: string;
    token: ComputeToken;
    state: 'ACCEPTED' | 'EXECUTING' | 'TERMINAL' | 'UNCERTAIN';
    terminal_kind?: 'ABSENT' | 'STOPPED' | 'SUCCEEDED' | 'FAILED';
    native_session_id?: string;
    payload_digest: string;
}
export type NativeReceiptReader = (tx: PrimaryTransaction, input: SchedulerScope & {
    operation_id: string;
    token: ComputeToken;
    payload_digest: string;
}) => Promise<NativeDispatchObservation | null>;
export declare class DispatchReconciler {
    private reader;
    registerReceiptReader(reader: NativeReceiptReader): () => void;
    close(): void;
    reconcile(tx: PrimaryTransaction, scope: SchedulerScope, request_id: string): Promise<unknown>;
}
export declare function ensureDispatch(tx: PrimaryTransaction, token: ComputeToken, request: string, recipients: {
    consumer_ids: string[];
}): Promise<unknown>;
export declare function consumeDispatchEvent(tx: PrimaryTransaction, input: SchedulerScope & {
    event_id: string;
    consumer_id: string;
    native_recipients: {
        consumer_ids: string[];
    };
}): Promise<Awaited<ReturnType<typeof receive>>>;
export declare function createComponent(startup: ComponentContext): Component;
