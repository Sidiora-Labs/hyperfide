import type { Component, ComponentContext } from '../components/registry.js';
import { type Obj } from './datasets.js';
export declare function assessPromotion(input: unknown, context: ComponentContext): Promise<Obj>;
export declare function checkDrift(input: unknown, context: ComponentContext): Promise<Obj>;
export declare function createComponent(_context: ComponentContext): Component;
