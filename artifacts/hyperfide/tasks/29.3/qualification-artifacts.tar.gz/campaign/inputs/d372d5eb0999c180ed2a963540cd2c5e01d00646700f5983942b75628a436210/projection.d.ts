import type { ComponentContext } from '../components/registry.js';
import type { GraphQueryExecutor } from './query.js';
import type { NormalisedFile, RepositoryFacts } from './projection_extract.js';
export declare const MAX_PROJECTION_FILES = 2000;
type Origin = 'BASE_REUSED' | 'TARGET';
export interface Delta {
    invalidation: 'FILE_CONTENT_AND_DEPENDENTS' | 'FULL_PARSER_CONFIGURATION_CHANGE';
    added: string[];
    deleted: string[];
    changed: string[];
    dependents: string[];
    reused: string[];
    origin: Map<string, Origin>;
}
export declare function computeDelta(base: RepositoryFacts, target: RepositoryFacts): Delta;
export declare function compose(base: RepositoryFacts, target: RepositoryFacts, delta: Delta): NormalisedFile[];
export declare function projectionFacts(input: unknown, ctx: ComponentContext, executor?: GraphQueryExecutor): Promise<unknown>;
export declare function projectionDelta(input: unknown, ctx: ComponentContext, executor?: GraphQueryExecutor): Promise<unknown>;
export declare function projectionView(input: unknown, ctx: ComponentContext, executor?: GraphQueryExecutor): Promise<unknown>;
export {};
