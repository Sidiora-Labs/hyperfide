import type pg from 'pg';
import type { Component, ComponentContext } from '../components/registry.js';
export type Data = Record<string, any>;
export declare const INPUT_KEYS: readonly ['source', 'dependency', 'toolchain', 'configuration', 'graph', 'contract'];
export declare function fail(code: string, message: string): never;
export declare function canonical(value: unknown): string;
export declare function hash(value: unknown): string;
export declare function fields(input: unknown, required: string[], optional?: string[]): Data;
export declare function uuid(value: unknown): string;
export declare function decimal(value: unknown): string;
export declare function digest(value: unknown): string;
export declare function invocation(ctx: ComponentContext): Data;
export declare function roles(ctx: ComponentContext, allowed: string[]): Data;
export declare function scope(ctx: ComponentContext, input: Data): [string, string];
export interface PrimaryClient {
    query<R extends pg.QueryResultRow = any>(text: string, values?: readonly unknown[]): Promise<pg.QueryResult<R>>;
}
export declare function assuranceBarrier(db: PrimaryClient, s: {
    organisation_id: string;
    run_id: string;
}, mode: 'SHARED' | 'EXCLUSIVE'): Promise<void>;
export declare function transaction<T>(ctx: ComponentContext, operation: (client: PrimaryClient) => Promise<T>, identityOnly?: boolean, mode?: 'READ' | 'WRITE'): Promise<T>;
export declare function executionGate(ctx: ComponentContext, db: PrimaryClient, s: [string, string], operation: 'ADMISSION' | 'RENEWAL' | 'ADVANCE' | 'CLEANUP', options?: Data): Promise<void>;
export declare function taskLock(client: PrimaryClient, s: [string, string], taskId: string): Promise<Data>;
export declare function loadPolicy(ctx: ComponentContext, task: Data, client: PrimaryClient): Promise<Data>;
export declare function artifact(ctx: ComponentContext, action: string, input: Data): Promise<Data>;
export declare function completeArtifact(ctx: ComponentContext, s: [string, string], id: string): Promise<Data>;
export declare function custodyLock(client: PrimaryClient, s: [string, string], id: string): Promise<Data>;
export declare function currentCustody(c: Data, generation: string, version?: string): void;
export declare function loadPacketInputs(db: PrimaryClient, s: [string, string], packetDigest: string): Promise<Data>;
export declare function resultInputs(facts: Data, sourceManifestDigest: string, derived: Data): Data;
/** Glob matching cannot grant paths beyond the scheduler's reserved ownership prefix. */
export declare function submittedGitFacts(ctx: ComponentContext, v: Data, policy: Data, workspace: Data, ownedScope: string[]): Promise<Data>;
/** STOP/CANCEL callers retain their guarded transaction and reconcile publication effects separately. */
export declare function revokeCustodies(db: PrimaryClient, s: {
    organisation_id: string;
    run_id: string;
}, submissionIds: string[], disposition: {
    actor_id: string;
    reason: string;
}): Promise<Data>;
export declare function fenceQualificationJobs(db: PrimaryClient, s: {
    organisation_id: string;
    run_id: string;
}, submissionIds: string[], reason: string): Promise<Data>;
/** Immutable admission provenance; consumers must independently re-read the COMPLETE object through15.2. */
export declare function inspectSubmittedResult(db: PrimaryClient, scopeValue: {
    organisation_id: string;
    run_id: string;
}, query: {
    custody_id: string;
}): Promise<Data>;
export declare function rawDigest(bytes: Uint8Array): string;
export declare function retainArtifactBytes(ctx: ComponentContext, s: [string, string], bytes: Buffer): Promise<Data>;
export declare function createComponent(ctx: ComponentContext): Component & {
    capabilities: Record<string, unknown>;
};
