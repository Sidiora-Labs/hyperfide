import type { ComponentContext } from '../components/registry.js';
import type { DecisionRequest, PreparedRequest, Question, RouteProfile, TransportResult } from './adapters.js';
export declare const PROBABILITY_TOLERANCE = 0.001;
export interface RevisionVector {
    spec_revision: string;
    repository_commits: Record<string, string>;
    graph_revision: string | null;
    contract_revisions: Record<string, string>;
    event_watermark: string;
    ownership_generation: string | null;
}
export interface DecisionIdentity {
    decision_id: string;
    packet_hash: string;
    purpose: string;
    rubric_version: string;
    revision: RevisionVector;
}
export interface ValidatedAnswer {
    type: Question['type'];
    value: unknown;
    raw_probabilities: Record<string, number> | null;
    normalized_probabilities: Record<string, number> | null;
    provider_confidence: number | null;
    confidence_semantics: string;
    derived: {
        decision_probability?: number;
        legacy_margin?: number;
        maximum_probability?: number;
        probability_sum?: number;
    };
    normalization: {
        applied: boolean;
        original_sum: number;
    } | null;
    raw: Record<string, unknown>;
}
export interface ResponseValidation {
    schema_version: 1;
    route_id: string;
    requested_model: string;
    returned_model: string;
    answers: Record<string, ValidatedAnswer>;
    usage: Record<string, unknown>;
    response_hash: string;
    non_authoritative: true;
}
export interface ValidatedDecision extends ResponseValidation {
    identity: DecisionIdentity;
    status: 'accepted_advice' | 'abstained';
    abstention_reason: string | null;
    calibration_version: string | null;
    transport: Omit<TransportResult, 'response'>;
    raw_response: Record<string, unknown>;
    authority: 'advisory-only';
}
export declare function parseIdentity(input: unknown): DecisionIdentity;
export declare function validateResponse(profile: RouteProfile, request: DecisionRequest, input: unknown): ResponseValidation;
export declare function assertValidatedDecision(value: unknown, expected: {
    decision_id: string;
    packet_hash: string;
}): asserts value is ValidatedDecision;
export declare function evaluateDecision(input: {
    route_id: unknown;
    request: unknown;
    identity: unknown;
    timeout_ms: number;
}, env: Readonly<NodeJS.ProcessEnv>, signal?: AbortSignal): Promise<ValidatedDecision>;
/** Internal capability preserves qualified media/reasoning; invokePrepared enforces private request provenance. */
export declare function evaluatePreparedDecision(request: PreparedRequest, identityInput: unknown, env: Readonly<NodeJS.ProcessEnv>, options: {
    timeout_ms: number;
    signal?: AbortSignal;
}): Promise<ValidatedDecision>;
export declare function createComponent(ctx: ComponentContext): unknown;
