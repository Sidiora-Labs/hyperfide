import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { PrimaryTransaction } from '../storage/transactions.js';
import type { ReviewControl, ReviewDb, ReviewScope } from './coverage.js';
export declare function planReproduction(ctx: ComponentContext, value: unknown): Promise<unknown>;
export declare function assignReproduction(ctx: ComponentContext, value: unknown): Promise<unknown>;
export declare function renewReproduction(ctx: ComponentContext, value: unknown): Promise<unknown>;
export interface ReproductionJobInputRequest {
    job_id: string;
    lease_generation: string;
    reservation_id: string;
    input_manifest_digest: string;
}
export interface ReproductionExpectedInputs {
    authority: 'EXPECTED_AUTHORITY';
    namespace: 'REPRODUCTION';
    organisation_id: string;
    run_id: string;
    job_id: string;
    lease_generation: string;
    reservation_id: string;
    input_manifest_digest: string;
    input_packet_digest: string;
    input_manifest: Record<string, unknown>;
    execution_inputs: Record<string, unknown>;
    task_id: string;
    worker_session_id: string;
    sandbox_id: string;
    sandbox_boot_generation: string;
    slot_id: string;
    allocation_id: string;
    allocation_generation: string;
    recorded_runner_session_id: string | null;
    recorded_runner_boot_id: string | null;
    recorded_runner_slot_generation: string | null;
    repository_id: string;
    source_manifest_digest: string;
    source_object_id: string;
    source_tree_id: string;
    profile_id: string;
    profile_digest: string;
    environment_digest: string;
    toolchain_digest: string;
    registry_digest: string;
    criteria_digest: string;
    check: Record<string, unknown>;
    custody_id: string;
    custody_generation: string;
    source_attempt_id: string;
    source_attempt_generation: string;
    source_origin: 'SUBMITTED_RESULT' | 'INTEGRATED_PUBLICATION';
    publication_operation_id: string | null;
}
/** Expected authority only. The12 adapter must independently resolve retained11
 * preparation receipts and measured08 runtime facts; these semantic role pins
 * must never be returned as VERIFIED measurements by themselves.
 */
export declare function readReproductionJobInputs(tx: PrimaryTransaction, invocation: InvocationContext, request: ReproductionJobInputRequest): Promise<ReproductionExpectedInputs>;
export declare function executeReproduction(ctx: ComponentContext, value: unknown): Promise<unknown>;
export declare function inspectReproduction(db: ReviewDb, binding: ReviewScope, planId: string): Promise<unknown>;
export declare function fenceReproductionJobs(db: ReviewDb, binding: ReviewScope, control: ReviewControl): Promise<unknown>;
export declare function planCurrentSourceReproduction(ctx: ComponentContext, value: unknown): Promise<unknown>;
export declare function createComponent(context: ComponentContext): Component;
