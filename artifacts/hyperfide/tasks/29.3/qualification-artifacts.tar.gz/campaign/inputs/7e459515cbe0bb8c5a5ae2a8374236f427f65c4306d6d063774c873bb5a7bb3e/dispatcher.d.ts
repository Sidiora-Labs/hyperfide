import type { ComponentContext } from '../components/registry.js';
export interface ContinuousDispatch {
    describe(): Readonly<Record<string, unknown>>;
    close(): Promise<void>;
}
/** A standing service signs new requests; only the receiving14 server creates an invocation or grants authority. */
export declare function startContinuousDispatch(context: ComponentContext): Promise<ContinuousDispatch | undefined>;
