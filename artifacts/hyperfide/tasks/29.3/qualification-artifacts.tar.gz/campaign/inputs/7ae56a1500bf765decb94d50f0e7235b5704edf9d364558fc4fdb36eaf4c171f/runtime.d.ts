import pg from 'pg';
import { TransactionGateway } from './transactions.js';
import type { DatabaseLease, QuerySession } from './transactions.js';
import type { ServiceRole } from '../policy/programme.js';
export interface ObservationOptions {
    timeoutMs?: number;
    signal?: AbortSignal;
    preferReplica?: boolean;
}
export interface ListenerSession extends QuerySession {
    onNotification(listener: (event: {
        channel: string;
        payload?: string | undefined;
        processId: number;
    }) => void): () => void;
}
export interface ServiceResources {
    readonly gateway: TransactionGateway;
    observe<T>(options: ObservationOptions, operation: (session: QuerySession) => Promise<T> | T): Promise<{
        value: T;
        route: 'primary' | 'replica';
        observedAt: string;
    }>;
    withReplicaConnection<T>(options: {
        timeoutMs?: number;
        signal?: AbortSignal;
    }, operation: (session: QuerySession) => Promise<T> | T): Promise<T>;
    withMigrationConnection<T>(options: {
        timeoutMs?: number;
        signal?: AbortSignal;
    }, operation: (session: QuerySession) => Promise<T> | T): Promise<T>;
    withListener<T>(options: {
        timeoutMs?: number;
        signal?: AbortSignal;
    }, operation: (session: ListenerSession) => Promise<T> | T): Promise<T>;
    describe(): unknown;
    close(): Promise<void>;
}
export declare class ResourceContainer implements ServiceResources {
    private readonly role;
    private readonly env;
    readonly gateway: TransactionGateway;
    readonly resourceId: `${string}-${string}-${string}-${string}-${string}`;
    private controller;
    private pools;
    private unbind;
    private revocations;
    private closed;
    constructor(role: ServiceRole, env: Readonly<NodeJS.ProcessEnv>, signal: AbortSignal);
    validateCommit(client: pg.PoolClient): Promise<void>;
    private config;
    private pool;
    private compatibilityPool;
    commitMode(): 'on' | 'remote_apply';
    acquirePrimary(deadline: number, signal?: AbortSignal): Promise<DatabaseLease>;
    private session;
    private connection;
    withReplicaConnection<T>(options: {
        timeoutMs?: number;
        signal?: AbortSignal;
    }, operation: (session: QuerySession) => Promise<T> | T): Promise<T>;
    withMigrationConnection<T>(options: {
        timeoutMs?: number;
        signal?: AbortSignal;
    }, operation: (session: QuerySession) => Promise<T> | T): Promise<T>;
    withListener<T>(options: {
        timeoutMs?: number;
        signal?: AbortSignal;
    }, operation: (session: ListenerSession) => Promise<T> | T): Promise<T>;
    observe<T>(options: ObservationOptions, operation: (session: QuerySession) => Promise<T> | T): Promise<{
        value: T;
        route: 'primary' | 'replica';
        observedAt: string;
    }>;
    describe(): unknown;
    close(): Promise<void>;
}
export declare function createResourceContainer(context: {
    role: ServiceRole;
    env: Readonly<NodeJS.ProcessEnv>;
    signal: AbortSignal;
}): ResourceContainer;
export declare function createComponent(context: {
    resources: ServiceResources;
}): {
    apiVersion: 1;
    actions: {
        'storage.runtime.describe': () => Promise<unknown>;
    };
    capabilities: Readonly<{
        'storage.resources.v1': ServiceResources;
        'storage.transactions.v1': TransactionGateway;
    }>;
};
