import type { Component, ComponentContext } from '../components/registry.js';
export interface LegacyWriterInput {
    deployment_id: string;
    operation_id: string;
    source_epoch: string | null;
    signal?: AbortSignal;
}
export interface LegacyAdmissionReceipt {
    deployment_id: string;
    operation_id: string;
    source_epoch: string | null;
    status: 'ADMISSION_DISABLED';
    topology_digest: string;
    observed_at: string;
    evidence_digest: string;
    visibility: {
        scope: 'CONFIGURED_PID_NAMESPACE';
        pid_namespace: string;
        mount_namespace: string;
    };
}
export interface LegacyIsolationReceipt {
    deployment_id: string;
    operation_id: string;
    source_epoch: string | null;
    status: 'ISOLATED';
    topology_digest: string;
    isolated_writer: string;
    observed_at: string;
    expires_at: string;
    evidence_digest: string;
    visibility: {
        scope: 'CONFIGURED_PID_NAMESPACE';
        pid_namespace: string;
        mount_namespace: string;
        checked_processes: number;
        checked_mount_namespaces: number;
    };
    admission_disabled: true;
    writable_fds: 0;
    writable_shared_mappings: 0;
    read_only_aliases: number;
}
export interface LegacyRestoreReceipt {
    deployment_id: string;
    operation_id: string;
    source_epoch: string | null;
    status: 'ADMISSION_RESTORED';
    topology_digest: string;
    restored_descriptor_digest: string;
    observed_at: string;
    evidence_digest: string;
}
export interface LegacyWriterCapability {
    disableAdmission(input: LegacyWriterInput): Promise<LegacyAdmissionReceipt>;
    observeIsolation(input: LegacyWriterInput): Promise<LegacyIsolationReceipt>;
    restoreAdmission(input: LegacyWriterInput): Promise<LegacyRestoreReceipt>;
}
/** This is a configured-namespace observation, never a claim about invisible
 * hosts/containers. The recovery controller must match topology and provider
 * isolation coverage before constructing a deployment-wide 4.4 fence receipt. */
export declare class LegacyWriterAdmission {
    private readonly env;
    constructor(env: Readonly<NodeJS.ProcessEnv>);
    disableAdmission(input: LegacyWriterInput): Promise<LegacyAdmissionReceipt>;
    /** Rollback before any new authoritative PostgreSQL write is the only caller. The exact
    * descriptor bound to this deployment/epoch is removed atomically; an unrelated or changed
    * descriptor is refused, and an already-absent descriptor is an idempotent replay. */
    restoreAdmission(input: LegacyWriterInput): Promise<LegacyRestoreReceipt>;
    private binding;
    observeIsolation(input: LegacyWriterInput): Promise<LegacyIsolationReceipt>;
}
export declare function createLegacyWriterAdmission(env: Readonly<NodeJS.ProcessEnv>): LegacyWriterAdmission;
export declare function createLegacyComponent(ctx: ComponentContext): Component;
