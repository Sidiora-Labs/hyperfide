import type { Component, ComponentContext } from '../../components/registry.js';
import { type ProviderOperation, type ResourceRef, type ProcessResult } from '../contract.js';
import { type RailwayClient } from './preparation.js';
import type { CredentialResolver } from './profile.js';
export interface RailwaySessionRecord {
    schema_version: 1;
    operation_id: string;
    payload_digest: string;
    scope_digest: string;
    resource: ResourceRef;
    session_name: string | null;
    phase: 'STARTING' | 'RUNNING' | 'EXITED' | 'UNKNOWN';
    exit_code: number | null;
    timed_out: boolean;
    termination_confirmed: boolean;
    stdin_open: boolean;
    detached: boolean;
    observation_gap: boolean;
    output_complete: boolean;
    chunk_count: number;
    byte_count: string;
    stream_bytes: {
        stdout: string;
        stderr: string;
    };
    updated_at: string;
}
/** Local durable spool is transport evidence, never global task ownership.
 * Artifacts15.2 must upload/ack these verified chunks before sandbox disposal. */
export interface RailwayChunkReceipt {
    artifact_id: string;
    receipt_id: string;
    digest: string;
    size_bytes: string;
}
export interface RailwayOutputChunk {
    operation_id: string;
    scope_digest: string;
    resource: ResourceRef;
    sequence: number;
    stream: 'stdout' | 'stderr';
    offset: string;
    digest: string;
    bytes: Uint8Array;
}
export type RailwayChunkSink = (chunk: RailwayOutputChunk) => Promise<RailwayChunkReceipt>;
export declare class RailwayArtifactUploadUnknown extends Error {
    readonly candidateArtifactId: string | null;
    constructor(candidateArtifactId: string | null);
}
export interface RailwayArchiveBinding {
    organisation_id: string;
    run_id: string;
    sandbox_id: string;
    boot_id: string;
    boot_generation: string;
    logical_process_ref: string;
    retention_class: 'EPHEMERAL' | 'RUN' | 'RELEASE' | 'LEGAL_HOLD';
    retention_until: string | null;
    retention_hold: boolean;
}
export interface RailwayArchiveReference {
    artifact_id: string;
    receipt_id: string;
    digest: string;
    size_bytes: string;
}
export interface RailwaySegmentReference extends RailwayArchiveReference {
    sequence: number;
    offset_bytes: string;
    content_digest: string;
    content_size_bytes: string;
    chunk_count: number;
}
export interface RailwayStreamIndex {
    schema_version: 1;
    kind: 'railway-session-stream-index';
    organisation_id: string;
    run_id: string;
    sandbox_id: string;
    boot_id: string;
    boot_generation: string;
    resource: ResourceRef;
    logical_process_ref: string;
    native_process_ref: string;
    operation_id: string;
    payload_digest: string;
    scope_digest: string;
    spool_digest: string;
    byte_count: string;
    complete: true;
    truncated: false;
    streams: {
        stdout: {
            size_bytes: string;
            digest: string;
            segments: RailwaySegmentReference[];
        };
        stderr: {
            size_bytes: string;
            digest: string;
            segments: RailwaySegmentReference[];
        };
    };
}
export type RailwayArtifactInvoke = (action: string, input: unknown) => Promise<unknown>;
interface UploadState {
    schema_version: 1;
    acknowledged: number;
    index_offset: number;
    pending: null | {
        sequence: number;
        digest: string;
        size_bytes: string;
        candidate_artifact_id?: string | null;
    };
}
export interface RailwayCaptureProof {
    schema_version: 1;
    scheme: 'ORDERED_CHUNKS_SHA256';
    chunks: Array<{
        stream: 'stdout' | 'stderr';
        offset_bytes: string;
        size_bytes: string;
        digest: string;
    }>;
}
export declare class RailwaySessionSpool {
    private readonly maxBytes;
    private readonly chunkSink?;
    readonly directory: string;
    private readonly handles;
    private readonly uploadPumps;
    private readonly operationSinks;
    private readonly sessionIndex;
    constructor(directory: string, maxBytes?: number, chunkSink?: RailwayChunkSink | undefined);
    private key;
    private folder;
    private sessionKey;
    private indexSession;
    private save;
    read(operationId: string): RailwaySessionRecord;
    private append;
    private index;
    verify(operationId: string): {
        complete: boolean;
        byte_count: string;
        digest: string;
        chunks: number;
    };
    private uploadState;
    private saveUploadState;
    private receipt;
    private kickUploads;
    uploadPending(operationId: string, sink: RailwayChunkSink): Promise<void>;
    private performUploads;
    uploadStatus(operationId: string): {
        uploaded_chunks: number;
        total_chunks: number;
        pending_unknown: boolean;
        all_chunks_uploaded: boolean;
        manifest_required: true;
        durable_upload_qualified: false;
    };
    reconcilePendingUpload(operationId: string, reconcile: (pending: NonNullable<UploadState['pending']>) => Promise<RailwayChunkReceipt | null>): Promise<boolean>;
    private archiveJournal;
    private archiveEffect;
    /** Seal terminal verified bytes in bounded segments. This method must receive the
     * original authenticated15 invocation and08's actual resource/boot binding. */
    sealStreams(operationId: string, invoke: RailwayArtifactInvoke, binding: RailwayArchiveBinding, maxSegmentChunks?: number): Promise<{
        index: RailwayStreamIndex;
        reference: RailwayArchiveReference;
        segment_references: RailwayArchiveReference[];
        complete: true;
        authority: 'NONE';
    }>;
    reconcileArtifactUploads(operationId: string, invoke: RailwayArtifactInvoke, binding: Pick<RailwayArchiveBinding, 'organisation_id' | 'run_id'>): Promise<boolean>;
    private result;
    start(client: RailwayClient, operation: ProviderOperation<'execute'>, resolve: CredentialResolver, signal: AbortSignal, artifactSink?: RailwayChunkSink, persistSession?: (nativeSessionName: string) => Promise<void>): Promise<{
        record: RailwaySessionRecord;
        result: ProcessResult;
    }>;
    find(resource: ResourceRef, sessionName: string): RailwaySessionRecord;
    inspect(resource: ResourceRef, sessionName: string): ProcessResult;
    stdin(resource: ResourceRef, sessionName: string, bytes: Uint8Array): Promise<void>;
    detach(resource: ResourceRef, sessionName: string): Promise<void>;
    readCapturedOutput(resource: ResourceRef, sessionName: string, maxBytes: number): {
        stdout: Uint8Array;
        stderr: Uint8Array;
        exit_code: number;
        complete: true;
        spool_digest: string;
        capture: RailwayCaptureProof;
    };
    detachAll(): Promise<void>;
    stop(client: RailwayClient, resource: ResourceRef, sessionName: string, signal: 'TERM' | 'KILL'): Promise<ProcessResult>;
}
/** Bind invoke to artifact.store.v1 with its actual authenticated request context.
 * Never accept an invocation guard, principal, or retention policy from a model request. */
export declare function createRailwayArtifactChunkSink(invoke: (action: string, input: unknown) => Promise<unknown>, binding: {
    organisation_id: string;
    run_id: string;
    retention_class: 'EPHEMERAL' | 'RUN' | 'RELEASE' | 'LEGAL_HOLD';
    retention_until: string | null;
    retention_hold: boolean;
}): RailwayChunkSink;
/** Verify archive bytes through the actual store, including every underlying chunk.
 * The index is domain metadata, never a15 manifest claiming concatenated log bytes. */
export declare function verifyRailwayStreamArchive(invoke: RailwayArtifactInvoke, reference: RailwayArchiveReference, expected: Pick<RailwayStreamIndex, 'organisation_id' | 'run_id' | 'sandbox_id' | 'boot_id' | 'boot_generation' | 'resource' | 'logical_process_ref' | 'native_process_ref' | 'operation_id' | 'payload_digest' | 'scope_digest'>): Promise<{
    index: RailwayStreamIndex;
    complete: true;
    authority: 'NONE';
}>;
export declare function createComponent(_context: ComponentContext): Component;
export {};
