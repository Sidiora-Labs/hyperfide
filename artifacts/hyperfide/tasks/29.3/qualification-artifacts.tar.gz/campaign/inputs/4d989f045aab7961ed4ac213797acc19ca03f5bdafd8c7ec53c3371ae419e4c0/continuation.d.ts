import type { PrimaryTransaction } from '../storage/transactions.js';
import type { InvocationContext } from '../transport/protocol.js';
export interface CheckpointArtifactBinding {
    readonly artifact_id: string;
    readonly artifact_digest: string;
    readonly artifact_size_bytes: string;
    readonly storage_kind: 'object' | 'manifest';
    readonly content_digest: string;
    readonly content_size_bytes: string;
}
export interface CheckpointContinuation {
    readonly schema_version: 1;
    readonly checkpoint_id: string;
    readonly artifact: CheckpointArtifactBinding;
    readonly source: {
        readonly attempt_id: string;
        readonly attempt_generation: string;
        readonly task_id: string;
        readonly workspace_id: string;
        readonly repository_id: string;
        readonly source_object_id: string;
        readonly input_packet_digest: string;
        readonly preparation_digest: string;
        readonly source_metadata_digest: string;
        readonly dependency_digest: string;
        readonly agent_session_id: string | null;
        readonly support_level: 'NATIVE_RESUME' | 'SOURCE_ONLY' | 'UNSUPPORTED';
    };
    readonly context_artifacts: {
        readonly dependency: CheckpointArtifactBinding;
        readonly summary: CheckpointArtifactBinding;
        readonly findings: CheckpointArtifactBinding;
    };
    readonly instruction_cursor: string;
    readonly authority: 'NONE';
    readonly context_restored: false;
}
/** Called only inside the packet producer's guarded primary transaction.
 * COMPLETE pins registered byte identities; this performs no external health
 * check and does not grant restore, process or target-attempt authority. */
export declare function readCheckpointContinuation(tx: PrimaryTransaction, input: {
    organisation_id: string;
    run_id: string;
    checkpoint_id: string;
}, invocation: InvocationContext): Promise<CheckpointContinuation>;
