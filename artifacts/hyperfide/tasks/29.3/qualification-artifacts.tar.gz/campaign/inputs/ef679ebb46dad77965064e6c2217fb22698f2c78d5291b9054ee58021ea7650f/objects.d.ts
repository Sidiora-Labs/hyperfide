import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { PrimaryTransaction, QuerySession } from '../storage/transactions.js';
export declare const ARTIFACT_ACTIONS: readonly ["artifact.object.put", "artifact.object.read", "artifact.object.inspect", "artifact.object.reconcile", "artifact.manifest.commit", "artifact.manifest.read", "artifact.pending.list", "artifact.object.locate"];
export type ArtifactScope = {
    organisation_id: string;
    run_id: string;
};
export interface ArtifactReference {
    artifact_id: string;
    receipt_id: string;
    digest: string;
    size_bytes: string;
}
export interface ArtifactReceipt extends ArtifactScope {
    schema_version: 1;
    receipt_id: string;
    artifact_id: string;
    digest: string;
    size_bytes: string;
    storage_backend: string;
    storage_key: string;
    completed_at: string;
}
type Invocation = {
    principal: {
        organisation_id: string;
        run_id: string;
        role: string;
    };
    guard: (tx: QuerySession) => Promise<void>;
    signal: AbortSignal;
};
type RequestContext = ComponentContext & {
    invocation?: Invocation;
};
/**
 * Pins a durable metadata binding in the caller's guarded primary transaction.
 * Physical byte verification remains a separate artifact-store operation.
 */
export declare function assertCompleteArtifactReferences(tx: PrimaryTransaction, scope: ArtifactScope, references: readonly ArtifactReference[]): Promise<readonly Readonly<ArtifactReceipt>[]>;
export declare function assertCompleteArtifactReference(tx: PrimaryTransaction, scope: ArtifactScope, reference: ArtifactReference): Promise<Readonly<ArtifactReceipt>>;
export declare class ArtifactStore {
    private readonly context;
    private configValue;
    constructor(context: RequestContext);
    private config;
    private scope;
    private backend;
    private transaction;
    private load;
    private same;
    private intent;
    private complete;
    private store;
    private put;
    private object;
    private parseManifest;
    private parseManifestBytes;
    private verifyChunks;
    private edges;
    private sameEdges;
    private commit;
    private locate;
    private pending;
    invoke(action: string, input: unknown, context?: ComponentContext | InvocationContext): Promise<unknown>;
    destroyTombstoned(input: unknown, context?: ComponentContext): Promise<unknown>;
    close(): void;
}
export interface ArtifactStoreCapability {
    invoke(action: string, input: unknown, context: ComponentContext | InvocationContext): Promise<unknown>;
}
export declare function isArtifactStoreCapability(value: unknown): value is ArtifactStoreCapability;
export declare function createArtifactStore(context: ComponentContext): ArtifactStore;
export declare function createComponent(context: ComponentContext): Component;
export {};
