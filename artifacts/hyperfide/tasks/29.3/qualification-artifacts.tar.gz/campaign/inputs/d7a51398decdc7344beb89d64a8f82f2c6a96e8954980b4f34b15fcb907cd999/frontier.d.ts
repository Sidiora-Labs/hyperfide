import type { Component, ComponentContext } from '../components/registry.js';
import type { IdentityTransaction } from '../identity/enrollment.js';
interface NativeProfileSnapshot {
    schema_version: 1;
    profile_id: string;
    profile_revision: string;
    profile_digest: string;
    connector: 'codex' | 'claude';
    auth_mode: 'account_session' | 'api_credential';
    binary: {
        path: string;
        digest: string;
        version: string;
    };
    credential_reference: string;
    configured_model_alias: string;
    requested_model_id: string;
    observed_model_id: string | null;
    configured_provider_id: string;
    observed_provider_id: string | null;
    permission_profile_id: string;
    capabilities: {
        unattended: boolean;
        refresh: boolean;
        concurrent_account: boolean;
        portable_session: boolean;
        explicit_resume: boolean;
    };
    qualification: {
        state: 'QUALIFIED';
        live_qualified: true;
        receipt_digest: string;
    };
}
interface Measurements {
    evidence_digest: string;
    sample_count: number;
    qualified_results: number;
    failed_results: number;
    p95_latency_ms: number | null;
    observed_at: string;
}
export interface QualifiedDeployment {
    native_profile: NativeProfileSnapshot;
    frontier: true;
    engineering: true;
    expected_profile_digest: string;
    expected_snapshot_digest: string;
    expires_at: string;
    measurements: Measurements | null;
}
export interface FrontierPolicy {
    schema_version: 1;
    programme_id: string;
    repository: string;
    spec_revision: string;
    policy_revision: number;
    short_critical_complex_alias: string;
    sustained_complex_alias: string;
    default_alias: string;
    deployments: QualifiedDeployment[];
}
export interface SelectionInput {
    task_id: string;
    duration: 'SHORT' | 'SUSTAINED';
    critical: boolean;
    complex: boolean;
    required_capabilities: string[];
    requested_alias: string | null;
    input_evidence_digest: string;
}
export declare function validateFrontierPolicy(input: unknown, context: ComponentContext): FrontierPolicy;
export declare function validateSelection(input: unknown): SelectionInput;
/** Selection is an attributable route proposal. Capacity, current task ownership and launch are separate admissions. */
export declare function selectFrontierRoute(policy: FrontierPolicy, input: SelectionInput): Record<string, unknown>;
/** Bounded V-044 policy; every limit is reported with each decision so retries are attributable. */
export declare const OUTCOME_LIMITS: Readonly<{
    error_retries: 2;
    limit_backoffs: 3;
    consecutive_no_op: 3;
    consecutive_waiting: 6;
    consecutive_idle: 2;
    selections_per_task: 3;
    error_backoff_ms: 1000;
    limit_backoff_ms: 30000;
    max_backoff_ms: 900000;
}>;
declare const SIGNALS: readonly ['PROGRESS', 'NO_OP', 'PROCESS_ALIVE', 'MODEL_WAITING', 'IDLE', 'MODEL_ERROR', 'TOOL_ERROR', 'AUTH_FAILURE', 'QUOTA_LIMITED', 'RATE_LIMITED'];
type OutcomeSignal = typeof SIGNALS[number];
/** Liveness, model waiting and useful progress are separate signals; verbose activity never becomes success. */
export declare function decideOutcome(prior: OutcomeSignal[], signal: OutcomeSignal): {
    decision: string;
    reason: string;
    retry_after_ms: number | null;
    retries_used: number;
    retry_limit: number | null;
};
interface QualificationReceipt {
    schema_version: 1;
    qualifier: string;
    profile_id: string;
    profile_digest: string;
    binary_digest: string;
    binary_version: string;
    configured_model_alias: string;
    requested_model_id: string;
    configured_provider_id: string;
    observed_model_id: string;
    observed_provider_id: string;
    qualified_at: string;
    expires_at: string;
    evidence_digest: string;
}
/** Live connector qualification receipts are signed by the configured 13.1 qualifier key; flags in routing config never qualify a route. */
export declare function qualificationReceipts(env: NodeJS.ProcessEnv): Promise<Map<string, {
    receipt: QualificationReceipt;
    receipt_digest: string;
}>>;
/** Bind the actual 14.3 configuration to its signed live qualification; any drift requires requalification. */
export declare function qualifiedSnapshot(actual: unknown, receipts: Map<string, {
    receipt: QualificationReceipt;
    receipt_digest: string;
}>): NativeProfileSnapshot;
type Tx = IdentityTransaction;
interface Scope {
    organisation_id: string;
    run_id: string;
}
/** Measured selection input: the current 5.4 resource admission for this request, observed on the primary clock. */
export declare function admissionMeasurement(tx: Tx, scope: Scope, request_id: string): Promise<Record<string, unknown>>;
/** Launch admission seam: a 13.x launcher consumes only a durable, non-terminal 1.3 selection. */
export interface FrontierRouteAuthority {
    selectedRoute(tx: Tx, scope: Scope, selection_id: string): Promise<Record<string, unknown>>;
}
export declare function isFrontierRouteAuthority(v: unknown): v is FrontierRouteAuthority;
export declare function createComponent(context: ComponentContext): Component;
export {};
