import type { Component, ComponentContext } from '../components/registry.js';
import { type RecordValue } from '../docs/closure.js';
import { type ReleaseContract } from './traceability.js';
export interface VerifiedReleaseEvidence {
    reference: string;
    receipt_digest: string;
    scope: 'task-component' | 'full-case' | 'campaign';
    case_ids: string[];
    assertion_ids: string[];
    outcome: 'PASS';
    full_case_status: string;
    implementation_revision: string;
    source_manifest_digest: string;
    gate_kinds: string[];
    resources: {
        id: string;
        state: 'CLEANED' | 'RETAINED';
        owner: string | null;
        expires_at: string | null;
        retention_authorised: boolean;
        observed_at: string;
    }[];
}
export interface ReleaseInventory {
    schema_version: 1;
    contract_digest: string;
    implementation_revision: string;
    source_manifest_digest: string;
    clause_evidence: {
        clause: string;
        task_ids: string[];
        case_ids: string[];
        evidence_refs: string[];
    }[];
    case_evidence: {
        case_id: string;
        evidence_ref: string;
    }[];
    gate_evidence: {
        kind: string;
        evidence_refs: string[];
    }[];
    resource_ids: string[];
    unsupported_features: {
        feature: string;
        reason: string;
    }[];
}
export declare const RELEASE_GATES: readonly string[];
export declare function validateReadinessInventory(contract: ReleaseContract, value: unknown, evidence: ReadonlyMap<string, VerifiedReleaseEvidence>): RecordValue;
interface CampaignReference {
    reference: string;
    evidence_root: string;
    campaign: string;
    receipt_id: string;
    receipt_digest: string;
    gate_kinds: string[];
}
/** Byte consistency only. The deployment owns both the admission stage and the
 * qualified assets; no request may choose executable code or grant release authority. */
export declare function checkReleaseCampaign(evidenceRoot: string, campaign: string, receipt: string, context: Pick<ComponentContext, 'env' | 'signal'>): Promise<RecordValue>;
export declare function loadReleaseAdmissionIndex(context: Pick<ComponentContext, 'env'>, scope: {
    organisation_id: string;
    run_id: string;
}): Promise<CampaignReference[]>;
export declare function assessReleaseReadiness(input: unknown, context: ComponentContext): Promise<RecordValue>;
export declare function sealReleaseReadiness(input: unknown, context: ComponentContext): Promise<RecordValue>;
export declare function createComponent(_context: ComponentContext): Component;
export declare function pinnedCampaignManifest(receipt: unknown, bytes: Uint8Array): RecordValue;
export {};
