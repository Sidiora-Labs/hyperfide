import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { PrimaryTransaction } from '../storage/transactions.js';
import type { ProviderOperation, ProviderOutcome } from './contract.js';
import type { ProviderDatabase, DeploymentConfig, ProviderPersistenceHooks, ProviderRunnerBindingVerifier, ProviderProcessRecord, ProviderDestructionRequest, ProviderDestructionProof, ProviderDestructionPreflight, ProviderOutputArchive } from './pools.js';
export interface Intent {
    organisation_id: string;
    run_id: string;
    id: string;
    pool_id: string;
    sandbox_id: string;
    configuration_digest: string;
    profile_id: string | null;
    kind: 'CREATE' | 'DESTROY';
    preparation_purpose: 'PREPARATION' | 'EXECUTION' | null;
    request_key: string;
    request_digest: string;
    payload_digest: string;
    operation: ProviderOperation;
    state: string;
    native_sandbox_id: string | null;
    boot_generation: string;
    provider_request_id: string | null;
    last_outcome: ProviderOutcome | null;
    state_version: string;
    new_submission?: boolean;
}
export interface PreparationSelection {
    run_id: string;
    pool_id: string;
    profile_id: string;
    preparation_digest: string;
    purpose: 'PREPARATION' | 'EXECUTION';
}
export declare function preparationParameters(c: PrimaryTransaction, config: DeploymentConfig, value: unknown, invocation: InvocationContext): Promise<ProviderOperation<'create'>['parameters']>;
export declare function prepareCreate(pool: ProviderDatabase, config: DeploymentConfig, value: unknown): Promise<unknown>;
export declare function prepareCreateTx(c: PrimaryTransaction, config: DeploymentConfig, value: unknown, invocation: InvocationContext): Promise<unknown>;
export declare function destructionPreflight(tx: PrimaryTransaction, pool: ProviderDatabase, input: ProviderDestructionRequest): Promise<ProviderDestructionProof>;
export declare function prepareDestroy(pool: ProviderDatabase, config: DeploymentConfig, value: unknown): Promise<unknown>;
export declare function persistenceHooks(pool: ProviderDatabase, organisation: string, id: string): ProviderPersistenceHooks;
export declare function boundedProvider<T>(effect: Promise<T>, signal: AbortSignal, deadlineAt: string): Promise<T>;
export declare function executeIntent(pool: ProviderDatabase, config: DeploymentConfig, id: string, signal: AbortSignal): Promise<unknown>;
export declare function reconcileIntent(pool: ProviderDatabase, config: DeploymentConfig, id: string, signal: AbortSignal): Promise<unknown>;
export type ProviderCaptureProof = {
    schema_version: 1;
    scheme: 'STREAM_DIGESTS_CANONICAL_JSON';
} | {
    schema_version: 1;
    scheme: 'ORDERED_CHUNKS_SHA256';
    chunks: Array<{
        stream: 'stdout' | 'stderr';
        offset_bytes: string;
        size_bytes: string;
        digest: string;
    }>;
};
export interface CapturedProviderOutput {
    stdout: Uint8Array;
    stderr: Uint8Array;
    exit_code: number;
    complete: true;
    spool_digest: string;
    capture: ProviderCaptureProof;
}
export declare function verifyCapturedProviderOutput(result: import('./contract.js').ProcessResult, value: CapturedProviderOutput, maxBytes?: number): CapturedProviderOutput;
export declare function processObservationDisposition(previous: ProviderOutcome | null, next: ProviderOutcome): 'ACCEPT' | 'IGNORE' | 'CONFLICT';
export interface BoundProviderRequest {
    binding: {
        organisation_id: string;
        run_id: string;
        session_id: string;
        pool_id: string;
        sandbox_id: string;
        external_sandbox_id: string;
        boot_generation: string;
        preparation_digest: string;
    };
    operation_id: string;
    argv: string[];
    cwd: string;
    env_refs: Record<string, string>;
    timeout_ms: number;
}
export declare function remoteProcessHooks(pool: ProviderDatabase, organisation: string, run: string, id: string): {
    persistOutputArchive: (op: ProviderOperation<'execute'>, value: ProviderOutputArchive) => Promise<{
        archive_id: string;
        evidence_digest: string;
    }>;
    persistEarlyProcess: (op: ProviderOperation<'execute'>, nativeProcessRef: string) => Promise<void>;
    claimProcess: (op: ProviderOperation<'execute'>, value: ProviderProcessRecord) => Promise<{
        disposition: 'NEW' | 'EXISTING';
        record: ProviderProcessRecord;
    }>;
    resolveProcess: (op: ProviderOperation, processRef: string) => Promise<ProviderProcessRecord | null>;
};
export declare function executeBound(pool: ProviderDatabase, config: DeploymentConfig, value: unknown, signal: AbortSignal): Promise<unknown>;
export declare function observeKnownSandbox(pool: ProviderDatabase, config: DeploymentConfig, value: unknown, signal: AbortSignal): Promise<unknown>;
export declare function readConfirmedAbsence(tx: PrimaryTransaction, input: {
    organisation_id: string;
    run_id: string;
    reservation_id: string;
}): Promise<{
    id: string;
    digest: string;
    observed_at: string;
} | null>;
export interface ProviderIntentCapability {
    registerDestructionPreflight(reader: ProviderDestructionPreflight): () => void;
    preparationParameters(tx: PrimaryTransaction, input: unknown, invocation: InvocationContext): Promise<ProviderOperation<'create'>['parameters']>;
    prepareCreateTx(tx: PrimaryTransaction, input: unknown, invocation: InvocationContext): Promise<unknown>;
    getIntent(id: string, invocation: InvocationContext): Promise<Intent>;
    readConfirmedAbsence: typeof readConfirmedAbsence;
}
export interface ProviderExecutionCapability {
    registerDestructionPreflight(reader: ProviderDestructionPreflight): () => void;
    registerRunnerBindingVerifier(reader: ProviderRunnerBindingVerifier): () => void;
    executeIntent(id: string, signal: AbortSignal, invocation: InvocationContext): Promise<unknown>;
    reconcileIntent(id: string, signal: AbortSignal, invocation: InvocationContext): Promise<unknown>;
    executeBound(input: unknown, signal: AbortSignal, invocation: InvocationContext): Promise<unknown>;
    observeKnownSandbox(input: unknown, signal: AbortSignal, invocation: InvocationContext): Promise<unknown>;
}
export declare function isProviderExecutionCapability(value: unknown): value is ProviderExecutionCapability;
export declare function isProviderIntentCapability(value: unknown): value is ProviderIntentCapability;
export declare function createComponent(context: ComponentContext): Component;
/** Control composition installs a durable PG reader; provider effects stay in the provisioner. */
export declare function createAccountingComponent(context: ComponentContext): Component;
