import type { Component, ComponentContext } from '../components/registry.js';
import type { Session, Principal } from './views.js';
export declare function recordMetrics(tx: Session, p: Principal, input: unknown): Promise<unknown>;
export declare function createComponent(startup: ComponentContext): Component;
