import type { Component, ComponentContext } from '../components/registry.js';
import type { PrimaryTransaction } from '../storage/transactions.js';
import type { InvocationContext } from '../transport/protocol.js';
export interface AgentAdmissionCapability {
    readonly schema_version: 1;
    recoveryContext(input: unknown, invocation: InvocationContext): Promise<unknown>;
    recoveryContextInTransaction(tx: PrimaryTransaction, input: unknown, invocation: InvocationContext): Promise<unknown>;
    /** Trusted 13.4 dispatch only: the current admitted plan inputs for a bound session, or the refusal reason. */
    launchSelection(tx: PrimaryTransaction, scope: {
        organisation_id: string;
        run_id: string;
        session_id: string;
    }, invocation: InvocationContext): Promise<{
        selection: AdmissionPlanSelection | null;
        reason: string | null;
    }>;
}
export declare function isAgentAdmissionCapability(value: unknown): value is AgentAdmissionCapability;
export declare const MAX_ADMISSION_ESCALATIONS = 3;
export type NativeAdmissionReason = 'RATE_LIMIT' | 'QUOTA_LIMIT' | 'AUTH_EXPIRED' | 'APPROVAL_REQUIRED' | 'DELEGATION_UNSUPPORTED';
export interface NativeSignalClassification {
    connector: 'codex' | 'claude';
    /** Liveness/waiting/progress are distinct: no classification ever reports useful progress. */
    signal: 'RATE_LIMITED' | 'QUOTA_EXHAUSTED' | 'AUTH_FAILED' | 'APPROVAL_PROMPT' | 'DELEGATION_REQUESTED' | 'MODEL_WAITING' | 'MODEL_ERROR' | 'RATE_LIMIT_STATUS' | 'TURN_FINISHED' | 'IGNORED';
    reason: NativeAdmissionReason | null;
    code: string | null;
    resets_at: string | null;
    useful_progress: false;
}
/** Maps one native connector protocol message (Codex app-server JSON-RPC, Claude Code stream-json)
 * to an admission report reason. Only normalized codes survive; native message text never does. */
export declare function classifyNativeEvent(connector: 'codex' | 'claude', event: unknown): NativeSignalClassification;
export interface AdmissionPlanSelection {
    reservation_id: string;
    reservation_attempt: number;
    policy_digest: string;
    run_policy_digest: string;
    connector: 'codex' | 'claude';
    connector_version: string;
    provider: string;
    model: string;
    auth_profile: string;
    permission_profile: string;
    qualification_digest: string;
    native_delegation: false;
}
export declare function createComponent(ctx: ComponentContext): Component;
