import type { PrimaryTransaction } from './transactions.js';
export interface SemanticDispositionScope {
    readonly organisation_id: string;
    readonly run_id: string;
}
export interface SemanticDispositionReceipt extends SemanticDispositionScope {
    readonly generation: string;
    readonly mode: 'READ' | 'WRITE';
}
export declare function readSemanticDisposition(tx: PrimaryTransaction, scope: SemanticDispositionScope): Promise<SemanticDispositionReceipt>;
export declare function writeSemanticDisposition(tx: PrimaryTransaction, scope: SemanticDispositionScope): Promise<SemanticDispositionReceipt>;
