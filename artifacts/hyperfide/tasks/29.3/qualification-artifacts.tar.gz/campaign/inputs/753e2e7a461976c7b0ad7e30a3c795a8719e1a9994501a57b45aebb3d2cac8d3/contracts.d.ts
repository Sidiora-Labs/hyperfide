import type { Component, ComponentContext } from '../components/registry.js';
import type { ReviewDb, ReviewScope } from './coverage.js';
export declare const CONTRACT_FACETS: readonly ['schema', 'signatures', 'errors', 'authentication', 'state', 'units', 'precision', 'ordering', 'idempotency', 'compatibility', 'operational_invariants'];
export declare const BEHAVIOURAL_FACETS: ("authentication" | "compatibility" | "errors" | "idempotency" | "operational_invariants" | "ordering" | "precision" | "state" | "units")[];
export declare function publishContract(context: ComponentContext, value: unknown): Promise<unknown>;
export declare function analyseContractImpact(context: ComponentContext, value: unknown): Promise<unknown>;
export interface ContractCoverageBinding {
    repository_id: string;
    source_object_id: string;
    candidate_digest?: string;
    input_manifest_digest?: string;
}
export declare function inspectContractCoverage(db: ReviewDb, binding: ReviewScope, contractIds: string[], source: ContractCoverageBinding): Promise<unknown>;
export declare function createComponent(_context: ComponentContext): Component;
