import type { EnvironmentProfile, PreparationManifest } from './manifests.js';
type FilePin = {
    path: string;
    digest: string;
};
type SubmodulePin = {
    path: string;
    commit: string;
};
export interface EffectiveResultSource {
    custody_id: string;
    custody_generation: string;
    binding_digest: string;
    source_manifest_artifact_id: string;
    source_manifest_digest: string;
    repository_id: string;
    source_object_id: string;
    source_tree_id: string;
}
export interface RegisteredResultRepository {
    repository_id: string;
    repository_key: string;
    repository_url: string;
}
export interface MeasuredResultInputs {
    repository_id: string;
    source_object_id: string;
    source_tree_id: string;
    submodules: SubmodulePin[];
    file_pins: FilePin[];
    observation_artifact_digest: string;
}
export interface EffectiveProfileInput {
    parent: {
        profile_id: string;
        preparation_manifest: PreparationManifest;
    };
    result: EffectiveResultSource;
    repository_binding: RegisteredResultRepository;
    measured: MeasuredResultInputs;
    derived_profile_id: string;
}
/** Metadata transformation only. The caller must obtain the result through the
 * real custody inspector, re-read COMPLETE artifact bytes, and obtain measured
 * pins from actual preparation execution before persisting this derivation.
 * Neither an input digest nor this output grants execution or readiness. */
export declare function deriveEffectiveProfile(input: EffectiveProfileInput): {
    profile: EnvironmentProfile;
    profile_digest: string;
    lineage: Record<string, unknown>;
    lineage_digest: string;
    dependency_inputs_changed: boolean;
    requires_preparation: true;
    readiness_granted: false;
};
export interface PreparationRecipePolicy {
    schema_version: 1;
    kind: 'hyperfide.preparation-policy';
    commands: {
        repository: string;
        argv: string[];
        timeout_seconds: number;
    }[];
    cache_scope: string;
    cache_paths: {
        repository: string;
        path: string;
    }[];
    minimum_free_bytes: string;
    minimum_free_inodes: string;
    network_timeout_milliseconds: number;
}
/** The approved manifest pins these policy bytes; this pure parser grants no execution authority. */
export declare function readPreparationRecipePolicy(parent: PreparationManifest, recipeBytes: Uint8Array): PreparationRecipePolicy;
export {};
