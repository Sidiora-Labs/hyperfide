export declare const PROTOCOL_VERSION = 1;
export declare const MAX_BODY_BYTES: number;
export declare const MAX_PAYLOAD_BYTES: number;
export declare const UUID: RegExp;
export declare const DIGEST: RegExp;
export declare const NAME: RegExp;
export interface Principal {
    readonly credential_id: string;
    readonly actor_id: string;
    readonly organisation_id: string;
    readonly run_id: string;
    readonly role: string;
    readonly credential_version: string;
    readonly deployment_epoch: string;
    readonly sandbox_id: string | null;
    readonly boot_id: string | null;
    readonly boot_generation: string | null;
    readonly attempt_id: string | null;
    readonly attempt_generation: string | null;
    readonly allowed_actions: readonly string[];
    readonly expires_at: string;
}
export interface Operation {
    readonly protocol_version: 1;
    readonly operation_id: string;
    readonly idempotency_key: string;
    readonly payload_digest: string;
    readonly correlation_id: string;
    readonly causation_id: string | null;
}
export interface InvokePayload {
    readonly run_id: string;
    readonly component: string;
    readonly action: string;
    readonly input: unknown;
    readonly expected_version: string | null;
    readonly authority: Readonly<Record<string, unknown>> | null;
}
export interface AuthorityTransaction {
    query(sql: string, values?: unknown[]): Promise<{
        rows: Record<string, any>[];
        rowCount: number | null;
    }>;
}
export interface InvocationContext {
    readonly principal: Principal;
    readonly operation: Operation;
    readonly payload: InvokePayload;
    readonly signal: AbortSignal;
    readonly guard: (tx: AuthorityTransaction) => Promise<void>;
    readonly continuationGuard: (tx: AuthorityTransaction, validatePersistedAdmission: (tx: AuthorityTransaction, invocation: InvocationContext) => Promise<void>) => Promise<void>;
    readonly identityGuard: (tx: AuthorityTransaction) => Promise<void>;
}
export interface EnrollmentPayload {
    run_id: string;
    provisioning_intent_id: string;
    sandbox_id: string;
    boot_generation: string;
    boot_id: string;
    public_key_b64: string;
}
export interface DecodedRequest<T> {
    operation: Operation;
    payload: T;
    raw: Buffer;
}
export interface Proof {
    id: string;
    time: string;
    nonce: string;
    signature: Buffer;
}
export declare function fail(code: string, message: string): never;
export declare function exact(value: unknown, names: readonly string[]): asserts value is Record<string, unknown>;
export declare function uuid(value: unknown): value is string;
export declare function decimal(value: unknown, positive?: boolean): value is string;
export declare function hash(bytes: Buffer | string): string;
export declare function base64(value: unknown, size?: number): Buffer;
export declare function frozen<T>(value: T, depth?: number): T;
export declare function strictJSON(bytes: Buffer, limit?: number): unknown;
export declare function canonicalOrigin(value: unknown): string;
export declare function decodeInvoke(raw: Buffer): DecodedRequest<InvokePayload>;
export declare function decodeEnrollment(raw: Buffer): DecodedRequest<EnrollmentPayload>;
export declare function proof(headers: readonly string[], enrollment?: boolean): Proof;
export declare function enrollmentSecret(headers: readonly string[]): Buffer;
export declare function signingBytes(origin: string, endpoint: '/v1/invoke' | '/v1/enroll', item: Omit<Proof, 'signature'>, body: Buffer): Buffer;
export declare function verifyProof(publicKey: string, item: Proof, origin: string, endpoint: '/v1/invoke' | '/v1/enroll', body: Buffer): void;
export declare function authenticatedInvocation(value: InvocationContext): InvocationContext;
export declare function assertInvocation(value: unknown): asserts value is InvocationContext;
