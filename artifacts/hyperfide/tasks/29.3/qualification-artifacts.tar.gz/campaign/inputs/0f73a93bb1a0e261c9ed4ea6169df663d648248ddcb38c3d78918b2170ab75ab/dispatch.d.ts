import type { Component, ComponentContext } from '../components/registry.js';
import type { PrimaryTransaction } from '../storage/transactions.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { ComputeToken } from '../scheduler/claim.js';
export interface RunnerSpawnInput {
    organisation_id: string;
    run_id: string;
    command_id: string;
    token: ComputeToken;
    packet_digest: string;
    payload_digest: string;
}
export interface RunnerLaunchPlan {
    launch_id: string;
    slot_id: string;
    agent_session_id: string;
    connector_plan_digest: string;
}
/** Trusted13 startup code supplies the qualified model/connector plan. Models
 * cannot submit a callback or turn their own launch labels into authority. */
export type RunnerPlanReader = (tx: PrimaryTransaction, input: RunnerSpawnInput, invocation: InvocationContext) => Promise<RunnerLaunchPlan | null>;
export interface RunnerDispatch {
    registerPlanReader(reader: RunnerPlanReader): () => void;
    consume(tx: PrimaryTransaction, i: InvocationContext, input: {
        event_id: string;
        attempt_count: string;
    }): Promise<unknown>;
    describe(): {
        route_ready: boolean;
        status: 'READY' | 'NOT_READY';
        launch_authority: false;
        reason: string | null;
    };
}
export declare function isRunnerDispatch(v: unknown): v is RunnerDispatch;
export declare function requireRunnerDispatch(ctx: ComponentContext): RunnerDispatch;
export declare function createComponent(ctx: ComponentContext): Component;
