import type { Component, ComponentContext } from '../components/registry.js';
import type { PrimaryTransaction, TransactionGateway } from '../storage/transactions.js';
import type { Scope, DeliveryClaim } from './outbox.js';
export declare function inspectPending(tx: PrimaryTransaction, input: unknown): Promise<unknown>;
export declare function recoverySnapshot(tx: PrimaryTransaction, input: unknown): Promise<unknown>;
export interface DispatchConfig extends Scope {
    consumer_id: string;
    batch_size: number;
    lease_ms: number;
    poll_ms: number;
    retry_ms: number;
}
export type DeliveryAdapter = (claim: DeliveryClaim, signal: AbortSignal) => Promise<{
    inbox_id: string;
}>;
export interface DispatchPass {
    claimed: number;
    acknowledged: number;
    pending: number;
}
export declare class DurableDispatcher {
    private readonly g;
    private readonly config;
    private readonly deliver;
    private readonly context;
    private closed;
    private active;
    private loop;
    private wakeResolve;
    private readonly controller;
    constructor(g: TransactionGateway, config: DispatchConfig, deliver: DeliveryAdapter, context: ComponentContext);
    wake(): void;
    start(): void;
    pass(): Promise<DispatchPass>;
    private transaction;
    private execute;
    close(): Promise<void>;
}
export declare function createComponent(context: ComponentContext): Promise<Component>;
