import { runService } from './components/service.js';
await runService('control');
//# sourceMappingURL=control.js.map