import type { Component, ComponentContext } from '../components/registry.js';
import type { PrimaryTransaction, TransactionGateway } from '../storage/transactions.js';
import type { InvocationContext } from '../transport/protocol.js';
export type ExecutionMode = 'ACTIVE' | 'PAUSE' | 'DRAIN' | 'STOP';
export interface ExecutionControl {
    scope_kind: 'RUN' | 'PACKAGE' | 'ATTEMPT' | 'SANDBOX';
    scope_id: string;
    mode: ExecutionMode;
    operation_id: string;
    reason: string;
    expected_generation?: string;
    resume?: boolean;
    deadline_at?: string;
    fallback_mode?: 'PAUSE' | 'STOP';
}
export declare function applyExecutionControl(tx: PrimaryTransaction, scope: SchedulerScope, input: ExecutionControl): Promise<unknown>;
export interface ExecutionTarget {
    package_id?: string;
    attempt_id?: string;
    sandbox_id?: string;
    resource_allocation_id?: string;
    qualification_job_id?: string;
    publication_operation_id?: string;
    operation: 'ADMISSION' | 'RENEWAL' | 'CHECKPOINT' | 'ADVANCE' | 'CLEANUP';
}
export declare function assertNoExecutionHold(tx: PrimaryTransaction, scope: SchedulerScope, target: ExecutionTarget): Promise<void>;
export declare function assertExecutionContinuation(tx: PrimaryTransaction, scope: SchedulerScope, target: ExecutionTarget): Promise<void>;
export interface PacketResourceRequirements {
    agent_sessions: 1;
    cpu_millis: number;
    memory_bytes: string;
    disk_bytes: string;
    build_slots: number;
    test_slots: number;
    max_descendants: number;
    exclusive_services?: string[];
}
export declare function packetResources(value: unknown): PacketResourceRequirements;
export declare function packetPolicyResources(packet: unknown): PacketResourceRequirements;
export declare function approvedDimensions(tx: PrimaryTransaction, scope: SchedulerScope, pool_id: string, requirements: PacketResourceRequirements, job_class?: string, warm_spare?: boolean, physical_preparation?: boolean): Promise<CapacityDimension[]>;
export declare function approvedPhysicalDimensions(tx: PrimaryTransaction, scope: SchedulerScope, pool_id: string, resources: unknown, warm_spare?: boolean): Promise<CapacityDimension[]>;
export declare function requireProofRegistry(tx: PrimaryTransaction, scope: SchedulerScope, task: {
    id: string;
    spec_revision_id: string;
    spec_generation: string;
    criteria_digest: string;
}): Promise<{
    registry_digest: string;
    policy: unknown;
}>;
export interface SchedulerScope {
    organisation_id: string;
    run_id: string;
}
export interface SchedulerActor {
    session_id: string;
    leader_generation: string;
    package_generation?: string;
}
export interface CapacityDimension {
    capacity_account_id: string;
    quantity: string;
}
export interface CapacityRequest extends SchedulerScope {
    request_id: string;
    attempt_id?: string;
    dimensions: CapacityDimension[];
    expires_at: string;
}
export interface ComputeToken extends SchedulerScope {
    task_id: string;
    attempt_id: string;
    attempt_generation: string;
    authority_epoch: string;
    sandbox_id: string;
    slot_id: string;
    sandbox_boot_generation: string;
}
export declare const UUID: RegExp;
export declare const DIGEST: RegExp;
export declare function fail(code: string, message: string): never;
export declare function object(value: unknown): Record<string, unknown>;
export declare function fields(value: unknown, required: readonly string[], optional?: readonly string[]): Record<string, unknown>;
export declare function uuid(value: unknown, label: string): string;
export declare function decimal(value: unknown, label: string, zero?: boolean): string;
export declare function digest(value: unknown, label: string): string;
export declare function boundedInteger(value: unknown, label: string, min: number, max: number): number;
export declare function canonical(value: unknown): string;
export declare function requestDigest(value: unknown): string;
export declare function gatewayFor(context: ComponentContext, continuation?: (tx: PrimaryTransaction) => Promise<unknown>): Pick<TransactionGateway, 'withPrimaryTransaction'>;
export declare function invocationFor(context: ComponentContext): InvocationContext;
export declare function actorFor(context: ComponentContext, scope: SchedulerScope, request: Record<string, unknown>): SchedulerActor;
export declare function dispatchRecipients(context: ComponentContext, kind?: 'dispatch' | 'native'): {
    consumer_ids: string[];
};
export declare function requireSchedulerAuthority(tx: PrimaryTransaction, scope: SchedulerScope, actor: SchedulerActor, authority_epoch: string, package_id?: string): Promise<void>;
export declare function operationReplay(tx: PrimaryTransaction, scope: SchedulerScope, principal: string, operation: string, key: string, payload: unknown): Promise<unknown | undefined>;
export declare function recordOutcome(tx: PrimaryTransaction, scope: SchedulerScope, principal: string, operation: string, key: string, payload: unknown, result: unknown): Promise<void>;
export declare function dimensions(value: unknown): CapacityDimension[];
/** Caller holds shared run authority and acquires accounts in stable UUID order. */
export declare function reserveCapacity(tx: PrimaryTransaction, input: CapacityRequest): Promise<unknown[]>;
export interface ClaimRequest extends SchedulerScope {
    request_id: string;
    task_id: string;
    attempt_id: string;
    attempt_generation: string;
    run_spec_generation: string;
    spec_generation: string;
    spec_revision_id: string;
    authority_epoch: string;
    leader_generation: string;
    package_generation?: string;
    sandbox_id: string;
    slot_id: string;
    sandbox_boot_generation: string;
    lease_ms: number;
    input_packet_digest: string;
    capacity: CapacityDimension[];
}
export declare function parseClaim(value: unknown): ClaimRequest;
export declare function requireMilestone(tx: PrimaryTransaction, scope: SchedulerScope, task_id: string, milestone: 'QUALIFIED' | 'INTEGRATED' | 'RELEASED', pin?: {
    repository_id: string | null;
    integration_ref: string | null;
}): Promise<void>;
export declare function requireTaskBarriers(tx: PrimaryTransaction, scope: SchedulerScope, task_id: string, wave: number): Promise<void>;
export declare function requirePacketAdmission(tx: PrimaryTransaction, input: ClaimRequest, task: {
    id: string;
    feature_package_id: string;
    spec_revision_id: string;
    spec_generation: string;
    criteria_digest: string;
}): Promise<PacketResourceRequirements>;
export declare function jobPolicy(tx: PrimaryTransaction, scope: SchedulerScope, task_id: string, operation?: 'ADMISSION' | 'ADVANCE'): Promise<PacketResourceRequirements>;
export declare function allocateReservations(tx: PrimaryTransaction, input: SchedulerScope & {
    reservation_ids: string[];
}): Promise<void>;
export declare function assertJobReservation(tx: PrimaryTransaction, input: SchedulerScope & {
    task_id: string;
    job_kind: string;
    reservation_id: string;
}): Promise<{
    request_id: string;
    pool_id: string;
    reservations: unknown[];
    resource_requirements: PacketResourceRequirements;
    spec_revision_id: string;
    spec_generation: string;
    criteria_digest: string;
    resource_policy_digest: string;
}>;
export declare function validateResourceVector(tx: PrimaryTransaction, input: SchedulerScope & {
    pool_id: string;
    attempt_id: string;
    dimensions: CapacityDimension[];
    job_class?: string;
}): Promise<{
    resource_requirements: PacketResourceRequirements;
    dimensions: CapacityDimension[];
}>;
export interface JobAllocation extends SchedulerScope {
    allocation_id: string;
    request_id: string;
    task_id: string;
    job_kind: string;
    reservation_id: string;
    slot_id: string;
    sandbox_id: string;
    sandbox_boot_generation: string;
    assignee_session_id: string;
    generation: string;
    expires_at: string;
    primary_now: string;
}
export declare function bindJobReservation(tx: PrimaryTransaction, input: SchedulerScope & {
    task_id: string;
    job_kind: string;
    reservation_id: string;
    slot_id: string;
    sandbox_id: string;
    sandbox_boot_generation: string;
    assignee_session_id: string;
}): Promise<JobAllocation>;
export declare function readJobAllocation(tx: PrimaryTransaction, input: SchedulerScope & {
    reservation_id: string;
}): Promise<JobAllocation>;
export interface JobLeaseRequest extends SchedulerScope {
    reservation_id: string;
    allocation_id: string;
    allocation_generation: string;
    assignee_session_id: string;
}
export declare function renewJobAllocation(tx: PrimaryTransaction, input: JobLeaseRequest & {
    lease_ms: number;
}): Promise<{
    allocation_id: string;
    generation: string;
    expires_at: string;
}>;
export declare function releaseJobAllocation(tx: PrimaryTransaction, input: JobLeaseRequest): Promise<unknown>;
export declare function claimTask(tx: PrimaryTransaction, input: ClaimRequest, actor: SchedulerActor, recipients: {
    consumer_ids: string[];
}): Promise<unknown>;
export interface SandboxResourceVector {
    cpu_millis: string;
    memory_bytes: string;
    disk_bytes: string;
}
export interface SandboxExecutor extends SchedulerScope {
    sandbox_id: string;
    sandbox_boot_generation: string;
    slot_id: string;
}
export interface SandboxBudgetQualification {
    organisation_id: string;
    sandbox_id: string;
    sandbox_boot_generation: string;
    qualification_id: string;
    evidence_digest: string;
    source: 'PROVIDER_OBSERVATION' | 'OPERATOR_FIXED';
    hard_limits: SandboxResourceVector;
    headroom: SandboxResourceVector;
}
/** Trusted producer seam. Callers must retain an actual measured or operator-qualified
 * fixed envelope; a requested provider size or nominal profile is not evidence. */
export declare function qualifySandboxBudget(tx: PrimaryTransaction, input: SandboxBudgetQualification): Promise<unknown>;
export declare function lockSandboxBudget(tx: PrimaryTransaction, input: SandboxExecutor): Promise<void>;
export declare function reserveSandboxResources(tx: PrimaryTransaction, input: SandboxExecutor & {
    request_id: string;
    attempt_id?: string;
    job_kind: string;
    resources: SandboxResourceVector;
}): Promise<unknown>;
export declare function markSandboxReleasePending(tx: PrimaryTransaction, input: SchedulerScope & {
    request_id?: string;
    attempt_id?: string;
}): Promise<void>;
export declare function assertSandboxReservation(tx: PrimaryTransaction, input: SchedulerScope & {
    reservation_id: string;
}): Promise<unknown>;
export declare function readCurrentComputeToken(tx: PrimaryTransaction, input: SchedulerScope & {
    task_id: string;
}): Promise<ComputeToken | null>;
export declare function releaseSandboxCharges(tx: PrimaryTransaction, scope: SchedulerScope, request_ids: string[]): Promise<void>;
export declare function inspectSandboxCharge(tx: PrimaryTransaction, input: SchedulerScope & {
    request_id: string;
}): Promise<Record<string, unknown> | null>;
export declare function readPreparationTarget(tx: PrimaryTransaction, input: SchedulerScope & {
    target_binding_id: string;
    preparation_operation_id: string;
    reservation_id: string;
}): Promise<Record<string, any> | null>;
export declare function finishPreparationAllocation(tx: PrimaryTransaction, input: SchedulerScope & {
    operation_id: string;
}): Promise<void>;
export declare function createComponent(context: ComponentContext): Component;
