import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { PrimaryTransaction, TransactionGateway } from '../storage/transactions.js';
import type { enqueue, claimPending, acknowledge } from '../events/outbox.js';
import type { receive } from '../events/inbox.js';
import type { RevisionVector } from './results.js';
export interface Scope {
    organisation_id: string;
    run_id: string;
}
export interface DecisionPacket {
    schema_version: 1;
    id: string;
    purpose: string;
    revision: RevisionVector;
    state: unknown;
    created_at: string;
    expires_at: string;
    authority: 'NONE';
}
export interface PurposeLoader {
    load(tx: PrimaryTransaction, invocation: InvocationContext, input: unknown): Promise<{
        packet: DecisionPacket;
        request: unknown;
        rubric_version: string;
    }>;
    current(tx: PrimaryTransaction, scope: Scope, packet: DecisionPacket, invocation: InvocationContext): Promise<RevisionVector>;
}
type Outbox = {
    enqueue: typeof enqueue;
    claimPending: typeof claimPending;
    acknowledge: typeof acknowledge;
};
type Inbox = {
    receive: typeof receive;
};
export declare class DecisionJobs {
    private readonly g;
    private readonly outbox;
    private readonly inbox;
    private readonly env;
    private readonly shutdown;
    private readonly purposes;
    private readonly controllers;
    private closed;
    constructor(g: TransactionGateway, outbox: Outbox, inbox: Inbox, env: Readonly<NodeJS.ProcessEnv>, shutdown: AbortSignal);
    registerPurpose(purpose: string, loader: PurposeLoader): void;
    private loader;
    private guard;
    private tx;
    private lock;
    private row;
    private fresh;
    submit(i: InvocationContext, raw: unknown): Promise<unknown>;
    status(i: InvocationContext, raw: unknown): Promise<unknown>;
    cancel(i: InvocationContext, raw: unknown): Promise<unknown>;
    private attempts;
    private receipt;
    replay(i: InvocationContext, raw: unknown): Promise<unknown>;
    private finish;
    process(i: InvocationContext, raw: unknown): Promise<unknown>;
    completedAudit(tx: PrimaryTransaction, s: Scope, input: {
        decision_id: string;
        packet_hash: string;
    }, i: InvocationContext): Promise<unknown>;
    close(): Promise<void>;
}
export declare function createComponent(ctx: ComponentContext): Component;
export {};
