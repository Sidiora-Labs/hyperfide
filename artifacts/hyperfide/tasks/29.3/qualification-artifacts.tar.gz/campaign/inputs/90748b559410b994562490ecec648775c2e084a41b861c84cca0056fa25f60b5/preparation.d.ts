import type { PrimaryTransaction } from '../storage/transactions.js';
import type { ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { RunnerEnvironmentRequest } from '../runner/bridge.js';
import type { EffectiveResultSource, EffectiveProfileInput } from '../preparation/effective.js';
import type { Data, PrimaryClient } from './submission.js';
export interface ResultPreparationContext {
    organisation_id: string;
    run_id: string;
    job_id: string;
    custody_id: string;
    job_state: string;
    job_lease_generation: string;
    result: Data;
    parent_profile_id: string;
    parent_preparation_digest: string;
    parent_profile_digest: string;
    parent_preparation_manifest: EffectiveProfileInput['parent']['preparation_manifest'];
    repository_binding: EffectiveProfileInput['repository_binding'];
    baseline_packet_digest: string;
    baseline_input_manifest: Data;
    accepted_context: Data;
    context_digest: string;
}
export declare function effectiveResultProjection(result: Data): EffectiveResultSource;
/** This context permits preparation of an admitted result before semantic proof.
 * Parent profile ownership is established on primary state; the pure11 helper
 * cannot establish it from caller metadata. No new coding packet is created. */
export declare function loadResultPreparationContext(tx: PrimaryTransaction, scope: {
    organisation_id: string;
    run_id: string;
}, query: {
    job_id: string;
}): Promise<ResultPreparationContext>;
/** Recompute the metadata derivation against the actual rechecked context and the
 * exact retained measurement object. The fixed remote recipe supplies measured
 * bytes; this helper never manufactures preparation or readiness. */
export declare function rederiveResultProfile(context: ResultPreparationContext, measured: EffectiveProfileInput['measured'], derived_profile_id: string, measurement_bytes: Uint8Array): {
    profile: import("../preparation/manifests.js").EnvironmentProfile;
    profile_digest: string;
    lineage: Record<string, unknown>;
    lineage_digest: string;
    dependency_inputs_changed: boolean;
    requires_preparation: true;
    readiness_granted: false;
};
/** Expected input authority only. The independently observed runner12 compares
 * this immutable ledger to actual profile, preparation, source and workspace.
 * No caller digest or old baseline environment can substitute for a missing row. */
export declare function inspectEffectiveResultInputs(tx: PrimaryClient, scope: {
    organisation_id: string;
    run_id: string;
}, query: {
    job_id: string;
}): Promise<Data>;
/** This factory-only adapter owns the QUALIFICATION namespace. The assignment and
 * execution lease remain primary authority; a prepared-input receipt grants none. */
export declare function registerQualificationInputReader(ctx: ComponentContext): () => void;
/** Only a strict policy whose bytes match the accepted recipe FilePin can supply
 * commands and preparation limits. Unsupported script recipes remain explicit. */
export declare function buildResultPreparationControl(context: ResultPreparationContext, recipe_bytes: Uint8Array, derived_profile_id: string): Promise<{
    body: Data;
    bytes: Buffer;
    raw_control_digest: string;
    semantic_input_manifest_digest: string;
}>;
/** Publish declared control metadata through actual15 before constructing a
 * preparation intent. Physical parent bytes and readiness still require native
 * validation; object receipts alone never grant either. No payload enters PG. */
export declare function retainResultPreparationControls(ctx: ComponentContext, context: ResultPreparationContext, recipe_bytes: Uint8Array, derived_profile_id: string): Promise<Data>;
export declare function planResultPreparation(ctx: ComponentContext, raw: unknown): Promise<Data>;
export declare function inspectResultPreparation(ctx: ComponentContext, raw: unknown): Promise<Data>;
/** Primary semantic authority for a retained-preparation publisher. This is the
 * initial intent, not a completed physical input receipt or readiness grant. */
export declare function inspectResultPreparationIntent(tx: PrimaryClient, scope: {
    organisation_id: string;
    run_id: string;
}, query: {
    operation_id: string;
}): Promise<Data>;
/** Initial semantic reader for the lower12 retained-preparation publisher.
 * Values remain accepted baseline pins. Actual derived profile and prepared
 * roles are admitted only after independently retained native measurements. */
export declare function qualificationPreparationAuthorityReader(ctx: ComponentContext): (tx: PrimaryTransaction, i: InvocationContext, request: RunnerEnvironmentRequest & {
    operation_id?: string;
}) => Promise<Data | null>;
