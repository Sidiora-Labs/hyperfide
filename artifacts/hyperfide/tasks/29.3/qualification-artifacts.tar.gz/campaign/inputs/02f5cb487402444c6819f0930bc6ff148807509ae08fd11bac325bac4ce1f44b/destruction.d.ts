import type { ComponentContext } from '../components/registry.js';
import type { ProviderDestructionPreflight } from '../providers/pools.js';
/** Read-only custody proof. A worked boot needs a separately sealed current
 * workspace/checkpoint closure; an older checkpoint cannot prove no later edits. */
export declare const readArtifactDestructionPreflight: ProviderDestructionPreflight;
export declare function registerArtifactDestructionPreflight(context: ComponentContext): void;
