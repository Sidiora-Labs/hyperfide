import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
type Context = ComponentContext;
export declare class ArtifactAdoption {
    private readonly context;
    constructor(context: Context);
    private targetActor;
    private authority;
    private transaction;
    private checkpoint;
    private prior;
    adopt(input: unknown, commit: boolean): Promise<unknown>;
    registerCheckpoint(input: unknown, stale: boolean): Promise<unknown>;
    inspectCheckpoint(input: unknown): Promise<unknown>;
}
export interface ArtifactAdoptionCapability {
    adopt(input: unknown, context: ComponentContext | InvocationContext): Promise<unknown>;
    validate(input: unknown, context: ComponentContext | InvocationContext): Promise<unknown>;
    registerCheckpoint(input: unknown, context: ComponentContext | InvocationContext): Promise<unknown>;
    importCheckpoint(input: unknown, context: ComponentContext | InvocationContext): Promise<unknown>;
    inspectCheckpoint(input: unknown, context: ComponentContext | InvocationContext): Promise<unknown>;
}
export declare function isArtifactAdoptionCapability(value: unknown): value is ArtifactAdoptionCapability;
export declare function createComponent(context: ComponentContext): Component;
export {};
