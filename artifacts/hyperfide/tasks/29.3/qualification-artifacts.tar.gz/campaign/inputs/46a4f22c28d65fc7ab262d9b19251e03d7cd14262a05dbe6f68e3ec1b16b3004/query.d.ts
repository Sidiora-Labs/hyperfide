import type { Component, ComponentContext } from '../components/registry.js';
import type { QuerySession } from '../storage/transactions.js';
import type { GraphScope } from './ingestion.js';
import type { JsonObject } from './extraction.js';
export interface GraphQueryDescriptor {
    kind: string;
    input: JsonObject;
    max_bytes: number;
    read_options?: unknown;
}
export type GraphQueryExecutor = <T extends JsonObject>(ctx: ComponentContext, scope: GraphScope, manifestId: string, query: GraphQueryDescriptor, operation: (session: QuerySession, manifest: JsonObject) => Promise<T>) => Promise<T>;
export declare const primaryGraphQueryExecutor: GraphQueryExecutor;
export declare function semanticInput(input: JsonObject): JsonObject;
export declare function bounded(value: unknown, base: number, min: number, max: number): number;
export declare function provenance(manifest: JsonObject): JsonObject;
export declare function budget(value: unknown): number;
export declare function packet<T extends JsonObject>(value: T, max: number): T;
export declare function decodeCursor(value: unknown, queryDigest: string): number;
export declare function encodeCursor(queryDigest: string, offset: number): string;
export declare function search(input: unknown, ctx: ComponentContext, executor?: GraphQueryExecutor): Promise<unknown>;
export declare function context(input: unknown, ctx: ComponentContext, executor?: GraphQueryExecutor): Promise<unknown>;
export declare function traverse(input: unknown, ctx: ComponentContext, executor?: GraphQueryExecutor): Promise<unknown>;
export declare function createComponent(ctx: ComponentContext): Component;
