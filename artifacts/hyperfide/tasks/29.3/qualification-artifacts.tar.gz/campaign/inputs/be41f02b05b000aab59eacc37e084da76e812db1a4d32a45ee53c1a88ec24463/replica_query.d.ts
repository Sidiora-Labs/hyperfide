import type { JsonObject } from './extraction.js';
import type { GraphQueryExecutor } from './query.js';
export interface GraphReadOptions {
    route: 'PRIMARY' | 'REPLICA';
    fallback: 'NONE' | 'PRIMARY';
    wait_ms: number;
    cache: 'BYPASS' | 'USE';
}
export declare function graphReadOptions(value: unknown): GraphReadOptions;
export declare class GraphQueryCache {
    readonly capacity: number;
    readonly maxBytes: number;
    private entries;
    private bytes;
    hits: number;
    misses: number;
    evictions: number;
    constructor(capacity: number, maxBytes?: number);
    get(key: string): JsonObject | undefined;
    set(key: string, value: JsonObject): void;
    private remove;
    describe(): JsonObject;
}
export declare function cacheCapacity(env: Readonly<NodeJS.ProcessEnv>): number;
export declare function routedGraphQueryExecutor(primary: GraphQueryExecutor, cache: GraphQueryCache): GraphQueryExecutor;
