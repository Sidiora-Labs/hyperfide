import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { PrimaryTransaction, TransactionGateway } from '../storage/transactions.js';
export interface Scope {
    organisation_id: string;
    run_id: string;
}
export interface OutboxEvent extends Scope {
    id: string;
    aggregate_type: string;
    aggregate_id: string;
    aggregate_version: string;
    event_type: string;
    payload: Record<string, unknown>;
}
export interface DeliveryClaim extends OutboxEvent {
    consumer_id: string;
    attempt_count: string;
    lease_expires_at: string;
}
export declare function fail(code: string, message: string): never;
export declare function fields(value: unknown, required: readonly string[], optional?: readonly string[]): Record<string, unknown>;
export declare function uuid(value: unknown): string;
export declare function name(value: unknown): string;
export declare function integer(value: unknown, zero?: boolean): string;
export declare function bounded(value: unknown, min: number, max: number): number;
export declare function scope(value: Record<string, unknown>): Scope;
export declare function canonical(value: unknown): string;
export declare function digest(value: unknown): string;
export declare function event(value: unknown): OutboxEvent;
export declare function eventDigest(e: OutboxEvent): string;
export declare function gateway(context: ComponentContext): TransactionGateway;
export declare function run<T>(g: TransactionGateway, operation: (tx: PrimaryTransaction) => Promise<T>): Promise<T>;
export declare function requireInvocation(context: ComponentContext, input: unknown, roles: readonly string[]): InvocationContext;
export declare function authorizedRun<T>(g: TransactionGateway, context: ComponentContext, input: unknown, roles: readonly string[], operation: (tx: PrimaryTransaction, invocation: InvocationContext) => Promise<T>): Promise<T>;
export declare function lockRun(tx: PrimaryTransaction, s: Scope, mode?: 'shared' | 'exclusive'): Promise<void>;
export declare function registerConsumer(tx: PrimaryTransaction, input: unknown): Promise<unknown>;
export declare function enqueue(tx: PrimaryTransaction, value: unknown, options?: {
    consumer_ids: readonly string[];
}): Promise<{
    event: OutboxEvent;
    replayed: boolean;
    obligations: number;
}>;
export declare function claimPending(tx: PrimaryTransaction, input: unknown): Promise<DeliveryClaim[]>;
export declare function currentClaim(tx: PrimaryTransaction, input: unknown): Promise<{
    scope: Scope;
    event_id: string;
    consumer_id: string;
    attempt_count: string;
    row: Record<string, unknown>;
}>;
export declare function acknowledge(tx: PrimaryTransaction, input: unknown): Promise<unknown>;
export declare function retry(tx: PrimaryTransaction, input: unknown): Promise<unknown>;
export type SessionConsumerNamespace = 'human_intent' | 'fleet_notification';
export interface SessionConsumerBinding extends Scope {
    consumer_id: string;
    session_id: string;
    namespace: SessionConsumerNamespace;
    consumer_key: string;
    consumer_state: string;
    session_role: string;
    session_state: string;
    registered_actor_id: string;
    registered_at: string;
}
export declare function sessionConsumerKey(session_id: string, namespace: SessionConsumerNamespace): string;
export declare function lookupConsumerBinding(tx: PrimaryTransaction, input: unknown): Promise<SessionConsumerBinding | null>;
export declare function resolveSessionConsumer(tx: PrimaryTransaction, input: unknown): Promise<SessionConsumerBinding | null>;
export declare function bindSessionConsumer(tx: PrimaryTransaction, input: unknown, invocation: InvocationContext): Promise<SessionConsumerBinding & {
    replayed: boolean;
}>;
export declare function lookupNativeLaunch(tx: PrimaryTransaction, input: unknown, invocation: InvocationContext): Promise<unknown>;
export declare function createComponent(context: ComponentContext): Component;
export interface EventOutboxCapability {
    enqueue: typeof enqueue;
    lockRun: typeof lockRun;
    registerConsumer: typeof registerConsumer;
    claimPending: typeof claimPending;
    acknowledge: typeof acknowledge;
    retry: typeof retry;
    sessionConsumerKey: typeof sessionConsumerKey;
    bindSessionConsumer: typeof bindSessionConsumer;
    resolveSessionConsumer: typeof resolveSessionConsumer;
    lookupConsumerBinding: typeof lookupConsumerBinding;
    lookupNativeLaunch: typeof lookupNativeLaunch;
}
export declare function isEventOutboxCapability(value: unknown): value is EventOutboxCapability;
