import type { ProgrammePolicy, ServiceRole } from '../policy/programme.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { ServiceResources } from '../storage/runtime.js';
export interface StartupContext {
    readonly role: ServiceRole;
    readonly policy: ProgrammePolicy;
    readonly signal: AbortSignal;
    readonly env: Readonly<NodeJS.ProcessEnv>;
}
export interface CapabilityResolver {
    require<T>(component: string, capability: string, validate: (value: unknown) => value is T): T;
}
export interface ComponentContext extends StartupContext {
    readonly invocation?: InvocationContext;
    readonly resources: ServiceResources;
    readonly dependencies: CapabilityResolver;
}
export type Action = (input: unknown, context: ComponentContext) => unknown | Promise<unknown>;
export interface Component {
    apiVersion: 1;
    actions: Record<string, Action>;
    capabilities?: Readonly<Record<string, unknown>>;
    close?: () => void | Promise<void>;
}
export declare class ComponentRegistry {
    private readonly context;
    private readonly instances;
    private readonly declarations;
    private readonly disposers;
    private order;
    private closed;
    private readonly contexts;
    private readonly resources;
    private readonly resourceView;
    constructor(context: StartupContext);
    resolveCapability<T>(id: string, capability: string, validate: (value: unknown) => value is T): T;
    load(directory: string, moduleRoot: string): Promise<void>;
    describe(): unknown;
    hasComponent(id: string): boolean;
    private invocationAuthorizer;
    installInvocationAuthorizer(authorize: (invocation: InvocationContext) => Promise<void>): void;
    invoke(id: string, action: string, input: unknown, invocation?: InvocationContext): Promise<unknown>;
    close(): Promise<void>;
}
