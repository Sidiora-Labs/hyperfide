import type { Component, ComponentContext } from '../components/registry.js';
export declare const CAPABILITY_NAMES: readonly ['prepare', 'create', 'list', 'observe', 'attach', 'execute', 'inspect', 'stop', 'transfer', 'lifetime', 'destroy', 'stdin', 'disk_snapshot', 'memory_snapshot', 'network_isolated', 'network_private', 'public_ingress', 'persistent_storage', 'shared_storage'];
export type CapabilityName = typeof CAPABILITY_NAMES[number];
export declare const PROVIDER_METHODS: readonly ['capabilities', 'prepare', 'create', 'list', 'observe', 'attach', 'execute', 'inspect', 'stop', 'transfer', 'lifetime', 'destroy'];
export type ProviderMethod = typeof PROVIDER_METHODS[number];
type Digest = string;
type OS = {
    distribution: string;
    version: string;
    architecture: string;
};
export interface ProviderScope {
    organisation_id: string;
    pool_id: string;
    provider: 'railway' | 'blaxel';
    provider_account_id: string;
    environment_id: string;
    region: string;
    configuration_digest: Digest;
}
export interface ResourceRef {
    native_sandbox_id: string;
    sandbox_boot_generation: string;
}
export interface ResourceVector {
    cpu_millis: number;
    memory_bytes: string;
    disk_bytes: string;
    persistent_volume_bytes: string;
}
export interface CapabilityProfile {
    schema_version: 1;
    scope: ProviderScope;
    pin: {
        sdk_name: string;
        sdk_version: string;
        sdk_integrity: string;
        api_revision: string;
    };
    observed_at: string;
    expires_at: string;
    preparation_digest: Digest;
    os: OS;
    capabilities: Array<{
        name: CapabilityName;
        support: 'SUPPORTED' | 'UNSUPPORTED' | 'UNKNOWN';
        availability: 'ENABLED' | 'DISABLED' | 'UNKNOWN';
        basis: 'DOCUMENTED' | 'OBSERVED' | 'LIVE_QUALIFIED';
        evidence_digest: Digest | null;
    }>;
}
export type ProviderState = 'CREATING' | 'RUNNING' | 'STOPPED' | 'DESTROYING' | 'DESTROYED' | 'FAILED' | 'UNKNOWN';
export interface InventoryPage {
    scope: ProviderScope;
    requested_cursor: string | null;
    next_cursor: string | null;
    has_more: boolean;
    complete: boolean;
    consistency: 'BEST_EFFORT' | 'SNAPSHOT';
    snapshot_id: string | null;
    observed_at: string;
    items: Array<{
        native_sandbox_id: string;
        provider_state: ProviderState;
    }>;
}
export interface ProviderParameters {
    capabilities: Record<string, never>;
    prepare: {
        image_reference: string;
        recipe_digest: Digest;
        os: OS;
    };
    create: {
        preparation_reference: string;
        resources: ResourceVector;
        network: 'ISOLATED' | 'PRIVATE';
        stdin_required: boolean;
    };
    list: {
        cursor: string | null;
        page_size: number;
    };
    observe: Record<string, never>;
    attach: {
        process_ref: string;
        resume_cursor: string | null;
    };
    execute: {
        argv: string[];
        cwd: string;
        env_refs: Record<string, string>;
        stdin: boolean;
        durable: boolean;
        process_timeout_ms: number | null;
        wait_timeout_ms: number;
    };
    inspect: {
        process_ref: string;
    };
    stop: {
        process_ref: string;
        signal: 'TERM' | 'KILL';
    };
    transfer: {
        direction: 'UPLOAD' | 'DOWNLOAD';
        path: string;
        artifact_digest: Digest;
        byte_count: string;
    };
    lifetime: {
        policy: 'NO_IDLE_EXPIRY' | 'BOUNDED';
        timeout_ms: number | null;
    };
    destroy: {
        reason: string;
    };
}
export type ProviderOperation<K extends ProviderMethod = ProviderMethod> = {
    [M in K]: {
        schema_version: 1;
        kind: M;
        scope: ProviderScope;
        deadline_at: string;
        identity: {
            operation_id: string;
            idempotency_key: string;
            payload_digest: Digest;
            correlation_id: string;
            causation_id: string;
        };
        resource: ResourceRef | null;
        preparation_digest: Digest | null;
        parameters: ProviderParameters[M];
    };
}[K];
export interface ProcessResult {
    process_ref: string;
    phase: 'STARTED' | 'EXITED';
    exit_code: number | null;
    timed_out: boolean;
    termination_confirmed: boolean;
    output: {
        complete: boolean;
        truncated: boolean;
        byte_count: string;
        sha256: Digest | null;
    };
}
export interface ProviderResults {
    capabilities: {
        profile: CapabilityProfile;
    };
    prepare: {
        preparation_reference: string;
        preparation_digest: Digest;
    };
    create: {
        provider_state: 'CREATING' | 'RUNNING';
    };
    list: {
        page: InventoryPage;
    };
    observe: {
        provider_state: ProviderState;
        health: 'HEALTHY' | 'SUSPECT' | 'UNKNOWN' | 'ABSENT';
    };
    attach: ProcessResult;
    execute: ProcessResult;
    inspect: ProcessResult;
    stop: {
        process_ref: string;
        termination: 'CONFIRMED';
        exit_code: number;
    };
    transfer: {
        artifact_digest: Digest;
        byte_count: string;
        complete: true;
    };
    lifetime: ProviderParameters['lifetime'];
    destroy: {
        deletion: 'CONFIRMED';
    };
}
export type ErrorCode = 'AUTHENTICATION' | 'AUTHORIZATION' | 'RATE_LIMIT' | 'NOT_FOUND' | 'CONFLICT' | 'INVALID_REQUEST' | 'UNAVAILABLE' | 'TIMEOUT' | 'PROTOCOL' | 'INTERNAL' | 'UNSUPPORTED';
export interface ProviderError {
    code: ErrorCode;
    provider_code: string | null;
    message: string;
    retry_after_ms: number | null;
}
interface OutcomeIdentity {
    schema_version: 1;
    operation_id: string;
    payload_digest: Digest;
    scope: ProviderScope;
    observed_at: string;
    provider_request_id: string | null;
    resource: ResourceRef | null;
}
export type ProviderOutcome<K extends ProviderMethod = ProviderMethod> = OutcomeIdentity & ({
    status: 'SUCCEEDED';
    acceptance: 'CONFIRMED_ACCEPTED';
    result: ProviderResults[K];
    error: null;
    reconcile_required: false;
    retry: 'NEVER';
} | {
    status: 'FAILED';
    acceptance: 'CONFIRMED_REJECTED';
    result: null;
    error: ProviderError & {
        code: Exclude<ErrorCode, 'UNSUPPORTED'>;
    };
    reconcile_required: false;
    retry: 'NEVER' | 'BOUNDED';
} | {
    status: 'UNKNOWN';
    acceptance: 'UNKNOWN';
    result: null;
    error: ProviderError & {
        code: Exclude<ErrorCode, 'UNSUPPORTED'>;
    };
    reconcile_required: true;
    retry: 'AFTER_RECONCILIATION';
} | {
    status: 'UNSUPPORTED';
    acceptance: 'CONFIRMED_REJECTED';
    result: null;
    error: ProviderError & {
        code: 'UNSUPPORTED';
    };
    reconcile_required: false;
    retry: 'NEVER';
});
/**
 * Create returns at confirmed provider acceptance/CREATING, retaining the early
 * external ID before readiness polling. Later observe can report FAILED while
 * that resource remains inventoried. SUCCEEDED is an operation observation,
 * never worker readiness, successful code execution, or accepted evidence.
 * Adapters enforce the persisted deadline, retain provider request IDs when
 * available, and reconcile late responses without discarding known resources.
 * Adapter methods preserve provider observations, not database ownership.
 * Implementations must persist an intent before side effects outside this module,
 * retain early returned IDs, and resolve uncertain acceptance before replay. */
export type ProviderAdapter = {
    readonly provider: ProviderScope['provider'];
} & {
    [M in ProviderMethod]: (operation: ProviderOperation<M>, signal?: AbortSignal) => Promise<ProviderOutcome<M>>;
};
export declare function validateCapabilityProfile(value: unknown): CapabilityProfile;
export declare function evaluateCapabilities(value: unknown): unknown;
/** Identity fields are excluded from the payload digest so an idempotency key
 * can bind a stable request. Durable key-conflict enforcement belongs to storage. */
export declare function operationPayloadDigest(operation: Pick<ProviderOperation, 'kind' | 'scope' | 'deadline_at' | 'resource' | 'preparation_digest' | 'parameters'>): Digest;
export declare function validateProviderOperation(value: unknown): ProviderOperation;
export declare function validateInventory(value: unknown): unknown;
export declare function validateProviderOutcome(value: unknown): unknown;
export declare function createComponent(_context: ComponentContext): Component;
export {};
