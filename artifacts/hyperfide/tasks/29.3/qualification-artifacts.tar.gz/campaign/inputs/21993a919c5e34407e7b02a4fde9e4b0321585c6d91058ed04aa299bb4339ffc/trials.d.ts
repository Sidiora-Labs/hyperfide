import type { Component, ComponentContext } from '../components/registry.js';
import { type Obj } from './datasets.js';
import { type Profile } from './scorecard.js';
export interface Trial {
    trial_id: string;
    mode: 'shadow' | 'controlled';
    purpose: string;
    scorecard_id: string;
    dataset_id: string;
    baseline: Profile;
    candidate: Profile;
    seed: string;
    power_plan_digest: string;
    units: {
        unit_id: string;
        groups: string[];
        arm: 'baseline' | 'candidate';
    }[];
    primary: 'qualified_per_hour' | 'cost_per_qualified';
    max_primary: number;
    minimum_benefit: number;
    defect_margin: number;
    minimum_units_per_arm: number;
    max_cost_microusd: number;
    max_attempts: number;
    max_duration_ms: number;
    starts_at: string;
    ends_at: string;
    approval_digest: string | null;
    evidence_class: 'live' | 'synthetic';
}
export interface TrialReport {
    trial_id: string;
    mode: string;
    purpose: string;
    scorecard_id: string;
    dataset_id: string;
    baseline: Profile;
    candidate: Profile;
    complete: boolean;
    count: number;
    per_arm: Record<string, Obj>;
    totals: {
        retries: number;
        qualified: number;
        qualified_per_hour: number | null;
        total_cost_microusd: number;
    };
    benefit_interval: {
        lower: number;
        upper: number;
    } | null;
    defect_difference_upper: number | null;
    benefit_demonstrated: boolean;
    noninferiority_demonstrated: boolean;
    stop_required: boolean;
    stop_reasons: string[];
    evidence_class: string;
    production_eligible: boolean;
    evidence_digest: string;
}
export declare function createTrial(input: unknown, context: ComponentContext): Promise<Obj>;
export declare function reportTrial(input: unknown, context: ComponentContext): Promise<Obj>;
export declare function createComponent(_context: ComponentContext): Component;
