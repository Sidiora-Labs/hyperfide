import type { InvocationContext } from '../transport/protocol.js';
import type { ComputeToken } from '../scheduler/claim.js';
import type { Component, ComponentContext } from '../components/registry.js';
import type { PrimaryTransaction } from '../storage/transactions.js';
export declare function childRegistration(tx: PrimaryTransaction, input: {
    organisation_id: string;
    run_id: string;
    child_session_id: string;
}): Promise<Record<string, unknown>>;
/** Keeps a descendant's charged capacity expiry no earlier than its parent's current compute lease. */
export declare function alignChildCapacity(tx: PrimaryTransaction, input: {
    organisation_id: string;
    run_id: string;
    child_session_id: string;
    lease_expires_at: string;
}): Promise<number>;
export interface Descendant {
    session_id: string;
    kind: 'WORKER' | 'CHILD';
    parent_session_id: string | null;
    task_id: string;
    package_id: string;
    attempt_id: string;
    attempt_generation: string;
    sandbox_id: string | null;
    slot_id: string | null;
    sandbox_boot_generation: string | null;
    state: string;
    native_session_id: string | null;
    status: 'ACCOUNTED' | 'RELEASED' | 'STALE' | 'UNACCOUNTED';
    reason: string | null;
}
/** Hook for native binders/handoff: refuses execution authority to any worker seat not accounted for by capacity. */
export declare function assertChildExecutionAuthority(tx: PrimaryTransaction, input: {
    organisation_id: string;
    run_id: string;
    session_id: string;
}): Promise<Descendant>;
/** Current supervisory identity witness; the caller separately proves the actual MAIN host/process. */
export declare function supervisorRegistration(tx: PrimaryTransaction, input: {
    organisation_id: string;
    run_id: string;
    session_id: string;
}): Promise<{
    organisation_id: string;
    run_id: string;
    session_id: string;
    role: 'LEADER' | 'FEATURE_MANAGER';
    native_session_id: string;
    leader_generation: string;
    package_bindings: never[] | import("pg").QueryResultRow[];
    registration_receipt_digest: string;
    execution_authority: false;
}>;
export declare function createComponent(context: ComponentContext): Component;
export interface WorkerRegistrationInput {
    organisation_id: string;
    run_id: string;
    command_id: string;
    token: ComputeToken;
    packet_digest: string;
    payload_digest: string;
}
export interface WorkerRegistrationReceipt {
    session_id: string;
    registration_receipt_digest: string;
    native_session_id: string | null;
    state: string;
    execution_authority: false;
}
export interface WorkerRegistrationAuthority {
    registerWorker: (tx: PrimaryTransaction, input: WorkerRegistrationInput, invocation: InvocationContext) => Promise<WorkerRegistrationReceipt>;
}
export declare function isWorkerRegistrationAuthority(value: unknown): value is WorkerRegistrationAuthority;
export declare function createWorkerComponent(context: ComponentContext): Component;
