import type { Component, ComponentContext } from '../components/registry.js';
import type { Data, PrimaryClient } from './submission.js';
export type Queryable = PrimaryClient;
export interface CoverageScope {
    organisation_id: string;
    run_id: string;
}
/** Runs on the caller's primary transaction; never substitutes a second pool snapshot. */
export declare function inspectCoverage(db: Queryable, s: CoverageScope, custodyId: string): Promise<Data>;
export declare function createComponent(ctx: ComponentContext): Component;
