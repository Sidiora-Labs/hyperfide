import type { ProviderPersistenceHooks as RuntimeProviderPersistenceHooks, QuotaObservation } from '../pools.js';
import type { Component, ComponentContext } from '../../components/registry.js';
import { type ProviderAdapter, type ProviderScope, type ProviderOperation, type ProviderOutcome, type ResourceRef, type InventoryPage, type CapabilityProfile } from '../contract.js';
import { RailwayClient, type PreparedRailwayBase } from './preparation.js';
import { RailwaySessionSpool, type RailwayChunkSink, type RailwayArchiveBinding, type RailwayArtifactInvoke, type RailwayCaptureProof } from './processes.js';
import { type RailwayRuntimeProfile, type CredentialResolver } from './profile.js';
export declare function inventoryPage(client: RailwayClient, s: ProviderScope, cursor: string | null, pageSize: number, signal?: AbortSignal): Promise<InventoryPage>;
export declare function completeInventory(client: RailwayClient, s: ProviderScope, signal?: AbortSignal, maxPages?: number): Promise<{
    pages: InventoryPage[];
    enumeration_complete: boolean;
    absence_authorized: false;
}>;
export declare function completeSessions(client: RailwayClient, sandboxId: string, signal?: AbortSignal, maxPages?: number): Promise<{
    sessions: Array<Record<string, unknown>>;
    enumeration_complete: boolean;
    available: boolean;
}>;
export declare const RAILWAY_QUOTA_TTL_MS = 300000;
export declare function observeRailwayQuota(client: RailwayClient, s: ProviderScope, signal?: AbortSignal): Promise<QuotaObservation[]>;
/** Approved-probe input validation for networking, quota, idle policy and the 72-hour profile.
 * Inputs are untrusted and can never carry qualification; every dimension stays UNQUALIFIED
 * until a later approved live campaign records evidence, so full-scale use remains blocked. */
export declare function qualifyRailwayProfileInputs(client: RailwayClient, input: unknown, policies?: readonly {
    scope: ProviderScope;
    idle_timeout_minutes: number;
}[]): {
    mode: import("./preparation.js").RailwayConfiguration['mode'];
    sdk: typeof import("./preparation.js").RAILWAY_PIN;
    live_qualification: 'NOT_EVALUATED';
    scope: ProviderScope;
    simulated: boolean;
    checks: {
        network: {
            input: unknown;
            status: 'UNQUALIFIED';
            reason: string;
        };
        quota: {
            input: unknown;
            status: 'UNQUALIFIED';
            reason: string;
        };
        idle_policy: {
            input: unknown;
            status: 'UNQUALIFIED';
            reason: string;
        };
        lifecycle: {
            input: unknown;
            status: 'UNQUALIFIED';
            reason: string;
        };
    };
    full_scale_use: 'BLOCKED';
    create_replay: 'NEVER';
    authority: 'NONE';
};
export type ProviderPersistenceHooks = RuntimeProviderPersistenceHooks;
export interface RailwayAdapterDependencies {
    persistence: ProviderPersistenceHooks;
    boundScope?: ProviderScope;
    artifactSink?: RailwayChunkSink;
    archive?: {
        invoke: RailwayArtifactInvoke;
        binding(operation: ProviderOperation<'execute'>): Promise<RailwayArchiveBinding>;
    };
    requireTrustedBindings?: true;
    runtimeProfile(operation: ProviderOperation<'create'>): Promise<RailwayRuntimeProfile>;
    preparedBase(reference: string, scope: ProviderScope): Promise<PreparedRailwayBase>;
    allowSeedPreparation?(operation: ProviderOperation<'create'>, profile: RailwayRuntimeProfile): Promise<boolean>;
    allowFreshPreparation?(operation: ProviderOperation<'create'>, profile: RailwayRuntimeProfile): Promise<boolean>;
    verifyForkSource?(operation: ProviderOperation<'create'>, profile: RailwayRuntimeProfile, base: PreparedRailwayBase): Promise<boolean>;
    credentials: CredentialResolver;
    sessions: RailwaySessionSpool;
    capabilities?(operation: ProviderOperation<'capabilities'>): Promise<CapabilityProfile>;
    prepare?(operation: ProviderOperation<'prepare'>, signal: AbortSignal): Promise<{
        preparation_reference: string;
        preparation_digest: string;
    }>;
    transfer?(operation: ProviderOperation<'transfer'>, client: RailwayClient, signal: AbortSignal): Promise<{
        artifact_digest: string;
        byte_count: string;
        complete: true;
    }>;
}
export type RailwayAdapter = ProviderAdapter & {
    sealCapturedOutput(operation: ProviderOperation<'execute'>): Promise<Awaited<ReturnType<RailwaySessionSpool['sealStreams']>> & {
        custody: {
            archive_id: string;
            evidence_digest: string;
        };
    }>;
    reconcileCapturedOutput(operation: ProviderOperation<'execute'>): Promise<boolean>;
    readCapturedOutput(scope: ProviderScope, resource: ResourceRef, processRef: string, maxBytes: number): Promise<{
        stdout: Uint8Array;
        stderr: Uint8Array;
        exit_code: number;
        complete: true;
        spool_digest: string;
        capture: RailwayCaptureProof;
    }>;
};
export declare function createRailwayAdapter(client: RailwayClient, dependencies: RailwayAdapterDependencies): RailwayAdapter;
export type RailwayRegistrar = (provider: 'railway', factory: (scope: ProviderScope, hooks: ProviderPersistenceHooks) => ProviderAdapter) => () => void;
export declare function registerRailwayProvider(registrar: RailwayRegistrar, client: RailwayClient, dependencies: (scope: ProviderScope, hooks: ProviderPersistenceHooks) => RailwayAdapterDependencies): () => void;
export declare function reconcileCreate(input: unknown): {
    decision: 'ADOPT_CANDIDATE' | 'QUARANTINE' | 'NO_MATCH';
    candidate_id: string | null;
    retry_create: false;
    authority: 'NONE';
};
export declare function createComponent(context: ComponentContext): Component;
/** This transport is reachable only through8.4's guarded isolation registry.
 * The caller supplies real14 isolation authority; no worker invocation is fabricated. */
export interface RailwayIsolationTransport {
    destroy(operation: ProviderOperation<'destroy'>, signal?: AbortSignal): Promise<ProviderOutcome<'destroy'>>;
    observe(operation: ProviderOperation<'observe'>, signal?: AbortSignal): Promise<ProviderOutcome<'observe'>>;
}
export declare function createRailwayIsolationTransport(client: RailwayClient, fixedScope: ProviderScope): RailwayIsolationTransport;
/** Pure provisioner boot seam.08/24 supply the independently trusted topology scope.
 * Construction creates no database connection, worker identity or provider effect. */
export declare function configuredRailwayIsolationTransport(config: Pick<ComponentContext, 'env'>, fixedScope: ProviderScope): RailwayIsolationTransport;
/** Trusted deployment policy, never populated from a component action input. */
interface RailwayPoolPolicy {
    scope: ProviderScope;
    seed_reference: string;
    seed_source: {
        kind: 'FRESH' | 'CHECKPOINT';
        reference: string | null;
    };
    idle_timeout_minutes: number;
    domains: RailwayRuntimeProfile['domains'];
    runtime_variables: RailwayRuntimeProfile['runtime_variables'];
    build_variables: Record<string, string>;
    retention: {
        retention_class: 'EPHEMERAL' | 'RUN' | 'RELEASE' | 'LEGAL_HOLD';
        retention_until: string | null;
        retention_hold: boolean;
    };
}
export declare function railwayRuntimePolicyDigest(policy: Omit<RailwayPoolPolicy, 'scope'> | RailwayPoolPolicy): string;
export {};
