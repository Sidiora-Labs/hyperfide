import type { Component, ComponentContext } from '../components/registry.js';
import type { Session, Principal } from './views.js';
export declare const DIMENSIONS: readonly ['SANDBOX', 'AGENT_SESSION', 'CPU_MILLIS', 'MEMORY_BYTES', 'DISK_BYTES', 'BUILD', 'LINK', 'TEST', 'EXCLUSIVE_SERVICE', 'INDEX', 'MODEL_REQUEST', 'MODEL_TOKEN', 'PROVIDER_API'];
export declare function decimal(value: unknown): string;
export declare function micros(value: string): bigint;
export declare function putProfile(tx: Session, p: Principal, input: unknown): Promise<unknown>;
export declare function recordSamples(tx: Session, p: Principal, input: unknown, allowReplay: boolean): Promise<unknown>;
export declare function resourceSnapshot(tx: Session, p: Principal, input: unknown): Promise<unknown>;
interface Utilisation {
    profile_id: string;
    dimension: string;
    subjects: string;
    current: string;
    stale: string;
    saturated: string;
    max_current_value: string | null;
    simulated: string;
}
export declare function executionAccounting(tx: Session, scope: unknown[], profile: string | null): Promise<{
    utilisation: Utilisation[];
    reservations: import("pg").QueryResultRow[];
    reservations_status: string;
    queue: {
        waiting: string;
        progress_state: string;
        dimension: string;
    }[];
    queue_status: string;
    queue_reason: string | null;
    stalled: {
        progress_state: string;
    }[];
    progress_states: {
        [k: string]: number;
    };
    provider: {
        declared_reservation_source: string;
        measured_capacity_claim: boolean;
    }[];
    provider_status: string;
    provider_reason: string | null;
    agents: {
        sessions: {
            parent_session_id: string | null;
            cpu_millis: string;
            memory_bytes: string;
            disk_bytes: string;
            accounting: string;
        }[];
        parents: {
            parent_session_id: string;
            children: number;
            charged_children: number;
            unaccounted_children: number;
            charged_cpu_millis: string;
            charged_memory_bytes: string;
            charged_disk_bytes: string;
        }[];
        unaccounted_spawns: number;
        hidden_spawn_status: string;
        unregistered_processes: string;
    };
    agents_status: string;
    agents_reason: string | null;
}>;
export declare function sandboxBudgets(input: unknown, ctx: ComponentContext): Promise<unknown>;
export declare function createComponent(_startup: ComponentContext): Component;
export {};
