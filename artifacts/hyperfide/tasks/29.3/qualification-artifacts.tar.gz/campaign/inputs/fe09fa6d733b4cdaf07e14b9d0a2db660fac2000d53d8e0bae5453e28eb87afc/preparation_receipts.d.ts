import type { PrimaryTransaction } from '../storage/transactions.js';
import type { InvocationContext } from '../transport/protocol.js';
export declare const PREPARATION_STAGE_ROOT = "/run/hyperfide-stage/";
export interface PreparationStageReceipt {
    stage_root: string;
    context_path: string;
    context_digest: string;
    out_root: string;
    diagnostics_root: string;
    workspace_path: string;
    node_path: string;
    node_digest: string;
    recipe_path: string;
    recipe_digest: string;
    uid: number;
    gid: number;
}
export interface PreparationReceiptPlan {
    operation_id: string;
    plan_digest: string;
    argv: readonly string[];
    executable_digest: string;
    workspace_path?: string;
    uid?: number;
    gid?: number;
}
export interface VerifiedPreparationReceipt {
    receipt: Record<string, unknown>;
    stage: PreparationStageReceipt;
    receipt_digest: string;
}
/** Pure verification shared by the 12.4 preparation capability and the receipt store. */
export declare function verifyPreparationReceipt(bytes: Buffer, plan: PreparationReceiptPlan): VerifiedPreparationReceipt;
/** Persist a verified receipt for an existing committed PREPARATION operation. Idempotent by digest. */
export declare function recordPreparationReceipt(tx: PrimaryTransaction, i: InvocationContext, v: unknown): Promise<Record<string, unknown>>;
export declare function readPreparationReceipt(tx: PrimaryTransaction, scope: {
    organisation_id: string;
    run_id: string;
    operation_id: string;
}): Promise<Record<string, unknown> | null>;
