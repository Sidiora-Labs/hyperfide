import type { ServiceRole } from '../policy/programme.js';
import { ComponentRegistry } from './registry.js';
import type { InvocationContext } from '../transport/protocol.js';
export type ProtocolResponse = {
    id: string | number;
    ok: true;
    result: unknown;
} | {
    id: string | number | null;
    ok: false;
    error: {
        code: string;
        message: string;
    };
};
export declare function handleRequest(registry: ComponentRegistry, request: unknown, responseLimit?: number, invocation?: InvocationContext): Promise<ProtocolResponse>;
export declare function runService(role: ServiceRole, args?: string[]): Promise<void>;
