import { createHash, randomUUID } from 'node:crypto';
import fs from 'node:fs/promises';
import { constants } from 'node:fs';
import path from 'node:path';
import { FoundationError, object } from '../policy/programme.js';
import { assertInvocation } from '../transport/protocol.js';
import { assertIsolationPermit, assertWriterObservationPermit } from '../identity/credentials.js';
import { assertPrimaryTransaction } from '../storage/transactions.js';
export function bindProviderIsolation(capability, authority) {
    if (!capability || typeof capability.isolateConfiguredResource !== 'function')
        fail('EXTERNAL_FENCE_BACKEND_UNAVAILABLE', 'Actual provisioner isolation capability is required');
    return Object.freeze({ isolateConfiguredResource: (key, id, signal, journal) => capability.isolateConfiguredResource(key, id, authority, signal, journal) });
}
function coreBinding(v) { return { deployment_id: v.deployment_id, operation_id: v.operation_id, source_epoch: v.source_epoch, topology_digest: v.topology_digest }; }
function fail(code, message) { throw new FoundationError(code, message); }
function canonical(v) { if (v === null || typeof v !== 'object')
    return JSON.stringify(v); if (Array.isArray(v))
    return '[' + v.map(canonical).join(',') + ']'; return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + canonical(v[k])).join(',') + '}'; }
function hash(v) { return 'sha256:' + createHash('sha256').update(canonical(v)).digest('hex'); }
function uuid(v) { return typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(v); }
function digest(v) { return typeof v === 'string' && /^sha256:[0-9a-f]{64}$/.test(v); }
function name(v) { return typeof v === 'string' && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(v); }
function time(v) { if (typeof v !== 'string')
    fail('EXTERNAL_FENCE_INVALID', 'Missing observation timestamp'); const n = Date.parse(v); if (!Number.isFinite(n) || new Date(n).toISOString() !== v)
    fail('EXTERNAL_FENCE_INVALID', 'Canonical UTC observation timestamp required'); return n; }
function checkBinding(v) { if (!uuid(v.deployment_id) || !uuid(v.operation_id) || v.source_epoch !== null && !uuid(v.source_epoch) || !digest(v.topology_digest) || !digest(v.authority_digest) || v.authority_nonce !== null && !uuid(v.authority_nonce))
    fail('EXTERNAL_FENCE_INVALID', 'Invalid durable fence identity'); }
function checkResourceBinding(v) { if (v.schema_version !== 1 || !uuid(v.operation_id) || !name(v.reference_key) || !digest(v.topology_digest) || !digest(v.resource_identity_digest) || !digest(v.authority_digest) || !digest(v.custody_evidence_digest) || typeof v.custody_expires_at !== 'string' || !object(v.destroy_operation) || Buffer.byteLength(canonical(v.destroy_operation)) > 196608)
    fail('EXTERNAL_FENCE_INVALID', 'Invalid immutable provider resource binding'); }
function checkReceipt(v, b, r) {
    if (!object(v) || v.reference_key !== r.reference_key || v.operation_id !== b.operation_id || v.topology_digest !== r.topology_digest || v.resource_identity_digest !== r.resource_identity_digest || !digest(v.evidence_digest) || !['LIVE_PROVIDER', 'COMPONENT_FIXTURE'].includes(v.evidence_scope) || !['ISOLATED', 'UNKNOWN'].includes(v.status) || !['DESTROYED', 'ABSENT', 'UNKNOWN'].includes(v.observed_state))
        fail('EXTERNAL_FENCE_INVALID', 'Provider observation is not bound to the trusted resource');
    time(v.observed_at);
    time(v.expires_at);
    if (v.status === 'ISOLATED' && !['DESTROYED', 'ABSENT'].includes(v.observed_state))
        fail('EXTERNAL_FENCE_INVALID', 'Accepted deletion is not physical isolation');
}
function checkFresh(observed, expires, now) {
    const at = time(observed), until = time(expires);
    if (at > now + 1000 || until <= now || until - at > 30000 || until <= at)
        fail('EXTERNAL_FENCE_STALE', 'Physical isolation evidence is expired or outside the permitted interval');
}
/** Private fsynced custody survives a control restart independently of the database being fenced.
 * A crashed operation lock is deliberately not age-reclaimed: operator reconciliation must establish ownership.
 */
export class FileExternalFenceJournal {
    directory;
    constructor(directory) {
        this.directory = directory;
    }
    async readCompleted(input) {
        if (!uuid(input.deployment_id) || !uuid(input.operation_id) || input.source_epoch !== null && !uuid(input.source_epoch) || !digest(input.topology_digest))
            fail('EXTERNAL_FENCE_INVALID', 'Exact completed operation identity is required');
        if (!path.isAbsolute(this.directory) || path.resolve(this.directory) !== this.directory)
            fail('EXTERNAL_FENCE_JOURNAL_UNSAFE', 'Canonical private journal required');
        const rootInfo = await fs.lstat(this.directory);
        if (!rootInfo.isDirectory() || rootInfo.isSymbolicLink() || rootInfo.uid !== process.getuid?.() || (rootInfo.mode & 0o077) !== 0 || await fs.realpath(this.directory) !== this.directory)
            fail('EXTERNAL_FENCE_JOURNAL_UNSAFE', 'Private owned journal required');
        const root = await fs.open(this.directory, constants.O_RDONLY | constants.O_DIRECTORY | constants.O_NOFOLLOW);
        try {
            const opened = await root.stat();
            if (opened.dev !== rootInfo.dev || opened.ino !== rootInfo.ino)
                fail('EXTERNAL_FENCE_JOURNAL_UNSAFE', 'Journal root changed');
            const file = await fs.open('/proc/self/fd/' + root.fd + '/' + input.operation_id + '.json', constants.O_RDONLY | constants.O_NOFOLLOW);
            try {
                const info = await file.stat();
                if (!info.isFile() || info.nlink !== 1 || info.uid !== process.getuid?.() || (info.mode & 0o077) !== 0 || info.size > 1048576)
                    fail('EXTERNAL_FENCE_JOURNAL_UNSAFE', 'Private bounded completion record required');
                const doc = JSON.parse(await file.readFile('utf8'));
                if (doc.schema_version !== 1 || !object(doc.binding) || canonical(coreBinding(doc.binding)) !== canonical({ deployment_id: input.deployment_id, operation_id: input.operation_id, source_epoch: input.source_epoch, topology_digest: input.topology_digest }) || !object(doc.completion_receipt))
                    fail('EXTERNAL_FENCE_COMPLETION_UNVERIFIED', 'No matching durable completed physical fence');
                if (typeof doc.completion_receipt_json !== 'string' || doc.completion_receipt_json.length > 16384)
                    fail('EXTERNAL_FENCE_COMPLETION_UNVERIFIED', 'Exact completed receipt bytes are absent');
                const history = doc.completion_receipts ?? [{ json: doc.completion_receipt_json, digest: 'sha256:' + createHash('sha256').update(doc.completion_receipt_json).digest('hex') }];
                if (!Array.isArray(history) || history.length < 1 || history.length > 16 || history.some(v => !object(v) || typeof v.json !== 'string' || v.json.length > 16384 || v.digest !== 'sha256:' + createHash('sha256').update(v.json).digest('hex')) || history.at(-1)?.json !== doc.completion_receipt_json)
                    fail('EXTERNAL_FENCE_COMPLETION_UNVERIFIED', 'Completed receipt history is invalid');
                const candidate = input.expected_proof_digest === undefined ? history.at(-1) : history.find(v => v.digest === input.expected_proof_digest);
                if (!candidate)
                    fail('EXTERNAL_FENCE_COMPLETION_UNVERIFIED', 'Exact accepted completion proof is absent from retained history');
                const receipt = JSON.parse(candidate.json);
                if (canonical(JSON.parse(doc.completion_receipt_json)) !== canonical(doc.completion_receipt))
                    fail('EXTERNAL_FENCE_COMPLETION_UNVERIFIED', 'Completed receipt bytes differ from journal value');
                if (receipt.deployment_id !== input.deployment_id || receipt.operation_id !== input.operation_id || receipt.source_epoch !== input.source_epoch || receipt.fence_id !== input.operation_id || receipt.isolated_writer !== 'topology:' + input.topology_digest.slice(7) || !digest(receipt.evidence_digest))
                    fail('EXTERNAL_FENCE_COMPLETION_UNVERIFIED', 'Completed physical fence scope mismatch');
                time(receipt.observed_at);
                time(receipt.expires_at);
                return Object.freeze(structuredClone(receipt));
            }
            finally {
                await file.close();
            }
        }
        finally {
            await root.close();
        }
    }
    async withOperation(binding, body) {
        return this.operate(binding, body, false);
    }
    async withObservation(binding, body) {
        return this.operate(binding, (_resource, _completion, observations) => body(observations), true);
    }
    async operate(binding, body, existingOnly) {
        checkBinding(binding);
        if (!path.isAbsolute(this.directory) || path.resolve(this.directory) !== this.directory)
            fail('EXTERNAL_FENCE_JOURNAL_UNSAFE', 'Canonical absolute private journal directory required');
        const info = await fs.lstat(this.directory);
        if (!info.isDirectory() || info.isSymbolicLink() || (info.mode & 0o077) !== 0 || typeof process.getuid !== 'function' || info.uid !== process.getuid() || await fs.realpath(this.directory) !== this.directory)
            fail('EXTERNAL_FENCE_JOURNAL_UNSAFE', 'Fence journal must be a private owned real directory');
        const root = await fs.open(this.directory, constants.O_RDONLY | constants.O_DIRECTORY | constants.O_NOFOLLOW);
        const opened = await root.stat();
        if (opened.dev !== info.dev || opened.ino !== info.ino) {
            await root.close();
            fail('EXTERNAL_FENCE_JOURNAL_UNSAFE', 'Fence journal directory changed during validation');
        }
        const anchor = '/proc/self/fd/' + root.fd, filename = path.join(anchor, binding.operation_id + '.json'), lockname = path.join(anchor, binding.operation_id + '.lock');
        let lock;
        let active = true;
        let queue = Promise.resolve();
        try {
            try {
                lock = await fs.open(lockname, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 0o600);
                await lock.writeFile(canonical({ binding, pid: process.pid }));
                await lock.sync();
                await root.sync();
            }
            catch (e) {
                if (e.code === 'EEXIST')
                    fail('EXTERNAL_FENCE_IN_PROGRESS', 'An existing durable operation lock requires ownership reconciliation');
                throw e;
            }
            let document = { schema_version: 1, binding, authorizations: [{ authority_digest: binding.authority_digest, authority_nonce: binding.authority_nonce }], resources: {} };
            try {
                const source = await fs.open(filename, constants.O_RDONLY | constants.O_NOFOLLOW);
                try {
                    const stat = await source.stat();
                    if (!stat.isFile() || stat.nlink !== 1 || (stat.mode & 0o077) !== 0 || stat.uid !== process.getuid() || stat.size > 1048576)
                        fail('EXTERNAL_FENCE_JOURNAL_UNSAFE', 'Fence journal record is not a bounded private regular file');
                    document = JSON.parse(await source.readFile('utf8'));
                }
                finally {
                    await source.close();
                }
                if (document.schema_version !== 1 || !object(document.binding) || canonical(coreBinding(document.binding)) !== canonical(coreBinding(binding)) || !Array.isArray(document.authorizations) || document.authorizations.length < 1 || document.authorizations.length > 16 || document.authorizations.some(a => !object(a) || !digest(a.authority_digest) || a.authority_nonce !== null && !uuid(a.authority_nonce)) || !document.authorizations.some(a => a.authority_digest === document.binding.authority_digest && a.authority_nonce === document.binding.authority_nonce) || !object(document.resources))
                    fail('EXTERNAL_FENCE_JOURNAL_CONFLICT', 'Fence operation already has a different immutable topology or epoch');
                for (const [key, row] of Object.entries(document.resources)) {
                    if (!object(row) || !object(row.binding) || key !== row.binding.reference_key || !['PREPARED', 'UNKNOWN', 'ISOLATED'].includes(row.state))
                        fail('EXTERNAL_FENCE_JOURNAL_INVALID', 'Invalid durable isolation record');
                    checkResourceBinding(row.binding);
                    if (!Array.isArray(row.observations) || row.observations.length > 8 || row.observations.some(o => !object(o) || !object(o.operation) || !object(o.outcome)))
                        fail('EXTERNAL_FENCE_JOURNAL_INVALID', 'Invalid persisted provider observations');
                    if (row.receipt)
                        checkReceipt(row.receipt, binding, row.binding);
                    if (row.state === 'ISOLATED' && row.receipt?.status !== 'ISOLATED')
                        fail('EXTERNAL_FENCE_JOURNAL_INVALID', 'Isolation record has no physical receipt');
                }
            }
            catch (e) {
                if (e.code !== 'ENOENT')
                    throw e;
                if (existingOnly)
                    fail('EXTERNAL_FENCE_OBSERVATION_UNPREPARED', 'Observation requires an existing durable isolation operation');
            }
            if (binding.authority_nonce !== null) {
                const noncePath = path.join(anchor, 'nonce-' + binding.authority_nonce + '.json');
                let nonce;
                try {
                    nonce = await fs.open(noncePath, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 0o600);
                    await nonce.writeFile(canonical(binding));
                    await nonce.sync();
                    await root.sync();
                }
                catch (error) {
                    if (error.code !== 'EEXIST')
                        throw error;
                    const prior = await fs.open(noncePath, constants.O_RDONLY | constants.O_NOFOLLOW);
                    try {
                        const stat = await prior.stat();
                        if (!stat.isFile() || stat.nlink !== 1 || stat.uid !== process.getuid() || (stat.mode & 0o077) !== 0 || stat.size > 8192 || await prior.readFile('utf8') !== canonical(binding))
                            fail('EXTERNAL_FENCE_NONCE_CONFLICT', 'Isolation permit nonce already belongs to another durable operation');
                    }
                    finally {
                        await prior.close();
                    }
                }
                finally {
                    await nonce?.close();
                }
            }
            if (!document.authorizations.some(a => a.authority_digest === binding.authority_digest && a.authority_nonce === binding.authority_nonce)) {
                if (document.authorizations.length >= 16)
                    fail('EXTERNAL_FENCE_AUTHORIZATION_LIMIT', 'Isolation operation exhausted its bounded renewed authorization history');
                document.authorizations.push({ authority_digest: binding.authority_digest, authority_nonce: binding.authority_nonce });
            }
            const save = async () => { const text = canonical(document); if (Buffer.byteLength(text) > 1048576)
                fail('EXTERNAL_FENCE_JOURNAL_LIMIT', 'Fence journal exceeds its bounded record size'); const temp = filename + '.' + randomUUID() + '.tmp'; const target = await fs.open(temp, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 0o600); try {
                await target.writeFile(text);
                await target.sync();
            }
            finally {
                await target.close();
            } try {
                await fs.rename(temp, filename);
                await root.sync();
            }
            catch (e) {
                try {
                    await fs.unlink(temp);
                }
                catch { }
                throw e;
            } };
            const serialize = (fn) => { const result = queue.then(() => { if (!active)
                fail('EXTERNAL_FENCE_JOURNAL_CLOSED', 'Fence journal capability has expired'); return fn(); }); queue = result.then(() => { }, () => { }); return result; };
            const resource = (key) => {
                if (!name(key))
                    fail('EXTERNAL_FENCE_INVALID', 'Invalid configured resource reference');
                return Object.freeze({
                    read: () => serialize(async () => Object.hasOwn(document.resources, key) ? structuredClone(document.resources[key]) : null),
                    prepare: (value) => serialize(async () => {
                        checkResourceBinding(value);
                        if (value.reference_key !== key || value.operation_id !== binding.operation_id)
                            fail('EXTERNAL_FENCE_JOURNAL_CONFLICT', 'Resource journal reference does not match');
                        const old = Object.hasOwn(document.resources, key) ? document.resources[key] : undefined;
                        if (old) {
                            if (canonical(old.binding) !== canonical(value))
                                fail('EXTERNAL_FENCE_JOURNAL_CONFLICT', 'Provider resource identity changed under an existing fence operation');
                            return { created: false, state: structuredClone(old) };
                        }
                        if (Object.keys(document.resources).length >= 256)
                            fail('EXTERNAL_FENCE_JOURNAL_LIMIT', 'Too many configured isolation resources');
                        const row = { binding: structuredClone(value), state: 'PREPARED', receipt: null, observations: [] };
                        document.resources = { ...document.resources, [key]: row };
                        await save();
                        return { created: true, state: structuredClone(row) };
                    }),
                    record: (outcome) => serialize(async () => {
                        const row = Object.hasOwn(document.resources, key) ? document.resources[key] : undefined;
                        if (!row)
                            fail('EXTERNAL_FENCE_JOURNAL_UNPREPARED', 'Persist exact resource identity before any external effect');
                        checkResourceBinding(outcome.binding);
                        if (canonical(outcome.binding) !== canonical(row.binding))
                            fail('EXTERNAL_FENCE_JOURNAL_CONFLICT', 'Observation cannot change an immutable resource identity');
                        if (!Array.isArray(outcome.observations) || outcome.observations.length > 8 || outcome.observations.some(o => !object(o) || !object(o.operation) || !object(o.outcome)))
                            fail('EXTERNAL_FENCE_INVALID', 'Actual bounded provider operation observations required');
                        const observations = [...row.observations, ...outcome.observations].filter((v, i, all) => all.findIndex(other => canonical(other) === canonical(v)) === i);
                        if (observations.length > 8)
                            fail('EXTERNAL_FENCE_JOURNAL_LIMIT', 'Observation history exceeds its immutable bounded record');
                        if (outcome.receipt)
                            checkReceipt(outcome.receipt, binding, row.binding);
                        document.resources = { ...document.resources, [key]: { ...row, binding: row.binding, state: outcome.receipt?.status === 'ISOLATED' ? 'ISOLATED' : 'UNKNOWN', receipt: outcome.receipt ? structuredClone(outcome.receipt) : null, observations: structuredClone(observations) } };
                        await save();
                    })
                });
            };
            const observations = (key) => {
                const original = resource(key);
                return Object.freeze({ read: original.read, recordObservation: (value) => serialize(async () => {
                        const row = Object.hasOwn(document.resources, key) ? document.resources[key] : undefined;
                        if (!row || canonical(row.binding) !== canonical(value.binding))
                            fail('EXTERNAL_FENCE_OBSERVATION_UNPREPARED', 'Observation cannot create or substitute a resource binding');
                        const observed = value.observation;
                        if (!object(observed) || observed.reference_key !== key || observed.operation_id !== binding.operation_id || observed.topology_digest !== row.binding.topology_digest || observed.resource_identity_digest !== row.binding.resource_identity_digest || observed.authority !== 'OBSERVATION_ONLY' || !['OBSERVED', 'UNKNOWN'].includes(observed.status) || !['ABSENT', 'PRESENT', 'UNKNOWN'].includes(observed.observed_state) || !['LIVE_PROVIDER', 'COMPONENT_FIXTURE'].includes(observed.evidence_scope) || !digest(observed.evidence_digest) || value.authorization_digest !== binding.authority_digest || !object(value.provider_observation) || !object(value.provider_observation.operation) || !object(value.provider_observation.outcome))
                            fail('EXTERNAL_FENCE_OBSERVATION_INVALID', 'Only attributable fresh read evidence may extend the existing operation');
                        checkFresh(observed.observed_at, observed.expires_at, Date.now());
                        if (time(value.authorization_expires_at) <= Date.now())
                            fail('EXTERNAL_FENCE_OBSERVATION_INVALID', 'Observation authorization expired before persistence');
                        const history = [...(row.writer_observations ?? []), structuredClone(value)];
                        if (history.length > 8)
                            fail('EXTERNAL_FENCE_JOURNAL_LIMIT', 'Observation-only history exhausted its bounded record');
                        document.resources = { ...document.resources, [key]: { ...row, writer_observations: history } };
                        await save();
                    }) });
            };
            await save();
            return await body(resource, receipt => serialize(async () => {
                if (receipt.deployment_id !== binding.deployment_id || receipt.operation_id !== binding.operation_id || receipt.source_epoch !== binding.source_epoch || receipt.fence_id !== binding.operation_id || !digest(receipt.evidence_digest) || receipt.isolated_writer !== 'topology:' + binding.topology_digest.slice(7))
                    fail('EXTERNAL_FENCE_JOURNAL_CONFLICT', 'Completed fence receipt differs from its immutable topology');
                checkFresh(receipt.observed_at, receipt.expires_at, Date.now());
                const json = JSON.stringify(receipt), proofDigest = 'sha256:' + createHash('sha256').update(json).digest('hex');
                const history = document.completion_receipts ?? (document.completion_receipt_json ? [{ json: document.completion_receipt_json, digest: 'sha256:' + createHash('sha256').update(document.completion_receipt_json).digest('hex') }] : []);
                if (!history.some(v => v.digest === proofDigest)) {
                    if (history.length >= 16)
                        fail('EXTERNAL_FENCE_JOURNAL_LIMIT', 'Completed proof history exhausted its bounded retention');
                    history.push({ json, digest: proofDigest });
                }
                document.completion_receipts = history;
                document.completion_receipt_json = history.at(-1).json;
                document.completion_receipt = JSON.parse(document.completion_receipt_json);
                await save();
            }), observations);
        }
        finally {
            await queue;
            active = false;
            try {
                if (lock) {
                    await lock.close();
                    await fs.unlink(lockname);
                    await root.sync();
                }
            }
            finally {
                await root.close();
            }
        }
    }
}
function topology(value) {
    if (!object(value) || value.schema_version !== 1 || !uuid(value.deployment_id) || !uuid(value.organisation_id) || !uuid(value.run_id) || !['LIVE_PROVIDER', 'COMPONENT_FIXTURE'].includes(value.evidence_scope) || value.source_epoch !== null && !uuid(value.source_epoch) || !digest(value.legacy_topology_digest) || !/^pid:\[[0-9]+\]$/.test(value.legacy_pid_namespace) || !/^mnt:\[[0-9]+\]$/.test(value.legacy_mount_namespace) || !Array.isArray(value.required_writer_ids) || value.required_writer_ids.length === 0 || value.required_writer_ids.length > 256 || !value.required_writer_ids.every(name) || new Set(value.required_writer_ids).size !== value.required_writer_ids.length || !Array.isArray(value.resources) || value.resources.length === 0 || value.resources.length > 256)
        fail('EXTERNAL_FENCE_CONFIG_INVALID', 'Trusted complete writer topology and namespace pins are required');
    const references = new Set(), covered = new Set();
    for (const r of value.resources) {
        if (!object(r) || !name(r.reference_key) || references.has(r.reference_key) || !digest(r.topology_digest) || !['PROVIDER', 'OWNED_HOST'].includes(r.backend) || !Array.isArray(r.writer_ids) || r.writer_ids.length === 0 || !r.writer_ids.every(name))
            fail('EXTERNAL_FENCE_CONFIG_INVALID', 'Trusted resource topology contains an invalid or duplicate reference');
        references.add(r.reference_key);
        for (const id of r.writer_ids) {
            if (!value.required_writer_ids.includes(id) || covered.has(id))
                fail('EXTERNAL_FENCE_CONFIG_INVALID', 'Every writer must have exactly one declared isolation boundary');
            covered.add(id);
        }
    }
    if (covered.size !== value.required_writer_ids.length)
        fail('EXTERNAL_FENCE_CONFIG_INCOMPLETE', 'Every configured writer route must have an actual isolation backend');
    return structuredClone(value);
}
/** Construct only in trusted deployment code. Request JSON cannot choose topology, backends, or journal paths. */
export function externalFenceTopologyDigest(config) { return hash(topology(config)); }
export function createExternalWriterFence(config, providers, legacy, journal, authority, ownedHost) {
    const trusted = topology(config), configDigest = hash(trusted);
    if (trusted.evidence_scope !== 'LIVE_PROVIDER')
        fail('EXTERNAL_FENCE_EVIDENCE_SCOPE_MISMATCH', 'Production authority activation requires live provider isolation evidence');
    if (!authority || !['INVOCATION', 'ISOLATION_PERMIT'].includes(authority.kind))
        fail('EXTERNAL_FENCE_AUTHORITY_REQUIRED', 'Actual invocation or verified isolation-only permit is required');
    const authorize = async (input) => {
        if (authority.kind === 'ISOLATION_PERMIT') {
            const expected = { deployment_id: input.deployment_id, operation_id: input.operation_id, organisation_id: trusted.organisation_id, run_id: trusted.run_id, source_epoch: input.source_epoch, topology_digest: configDigest };
            assertIsolationPermit(authority.permit, expected);
            const allowed = authority.permit.resources.map(r => ({ reference_key: r.reference_key, topology_digest: r.topology_digest })).sort((a, b) => a.reference_key.localeCompare(b.reference_key));
            const required = trusted.resources.map(r => ({ reference_key: r.reference_key, topology_digest: r.topology_digest })).sort((a, b) => a.reference_key.localeCompare(b.reference_key));
            if (canonical(allowed) !== canonical(required))
                fail('EXTERNAL_FENCE_AUTHORITY_DENIED', 'Isolation permit resource coverage must exactly match trusted topology');
            return { authority_digest: authority.permit.permit_digest, authority_nonce: authority.permit.nonce };
        }
        const i = authority.invocation;
        assertInvocation(i);
        if (!['OPERATOR', 'COORDINATOR', 'LEADER'].includes(i.principal.role) || i.principal.organisation_id !== trusted.organisation_id || i.principal.run_id !== trusted.run_id || i.principal.deployment_epoch !== input.source_epoch || i.operation.idempotency_key !== input.operation_id || i.payload.component !== '25.2' || i.payload.action !== 'cutover.activate' || !object(i.payload.input) || i.payload.input.operation_id !== input.operation_id || i.payload.input.scope_id !== trusted.run_id)
            fail('EXTERNAL_FENCE_AUTHORITY_DENIED', 'Physical isolation must be bound to the genuine authorised activation invocation');
        await authority.gateway.withPrimaryTransaction({ timeoutMs: 10000, maxRetries: 0, ...(input.signal ? { signal: input.signal } : {}) }, async (tx) => { assertPrimaryTransaction(tx); await i.guard(tx); });
        return { authority_digest: i.operation.payload_digest, authority_nonce: null };
    };
    if (!providers || typeof providers.isolateConfiguredResource !== 'function' || !legacy || typeof legacy.disableAdmission !== 'function' || typeof legacy.observeIsolation !== 'function' || !(journal instanceof FileExternalFenceJournal))
        fail('EXTERNAL_FENCE_BACKEND_UNAVAILABLE', 'Actual provider, legacy observer, and durable journal are required');
    if (trusted.resources.some(r => r.backend === 'OWNED_HOST') && (!ownedHost || typeof ownedHost.isolateConfiguredResource !== 'function'))
        fail('EXTERNAL_FENCE_BACKEND_UNAVAILABLE', 'Owned main host or network writer routes need their actual isolation backend');
    const checkLegacy = (v, input, isolated) => {
        if (!object(v) || v.deployment_id !== input.deployment_id || v.operation_id !== input.operation_id || v.source_epoch !== input.source_epoch || v.topology_digest !== trusted.legacy_topology_digest || !digest(v.evidence_digest) || v.visibility?.scope !== 'CONFIGURED_PID_NAMESPACE' || v.visibility.pid_namespace !== trusted.legacy_pid_namespace || v.visibility.mount_namespace !== trusted.legacy_mount_namespace || v.status !== (isolated ? 'ISOLATED' : 'ADMISSION_DISABLED'))
            fail('EXTERNAL_FENCE_LEGACY_UNVERIFIED', 'Legacy observation does not cover the configured namespace and source');
        time(v.observed_at);
        if (isolated) {
            if (v.admission_disabled !== true || v.writable_fds !== 0 || v.writable_shared_mappings !== 0 || !Number.isSafeInteger(v.read_only_aliases) || v.read_only_aliases < 1 || !name(v.isolated_writer) || !v.expires_at)
                fail('EXTERNAL_FENCE_LEGACY_UNVERIFIED', 'Read-only storage and writer quiescence were not actually observed');
            checkFresh(v.observed_at, v.expires_at, Date.now());
            if (!trusted.required_writer_ids.includes(v.isolated_writer) || !trusted.resources.some(r => r.writer_ids.includes(v.isolated_writer)))
                fail('EXTERNAL_FENCE_CONFIG_INCOMPLETE', 'Legacy namespace observations require an actual declared physical isolation boundary for that writer');
        }
    };
    return Object.freeze({ isolate: async (input) => {
            if (input.deployment_id !== trusted.deployment_id || input.source_epoch !== trusted.source_epoch || !uuid(input.operation_id))
                fail('EXTERNAL_FENCE_SCOPE_MISMATCH', 'Activation does not match the trusted deployment source epoch');
            input.signal?.throwIfAborted();
            const authorization = await authorize(input);
            return journal.withOperation({ deployment_id: input.deployment_id, operation_id: input.operation_id, source_epoch: input.source_epoch, topology_digest: configDigest, ...authorization }, async (resource, recordCompletion) => {
                await authorize(input);
                const admission = await legacy.disableAdmission(input);
                checkLegacy(admission, input, false);
                const isolate = async (r) => {
                    input.signal?.throwIfAborted();
                    const custody = resource(r.reference_key), backend = r.backend === 'PROVIDER' ? providers : ownedHost;
                    let observed;
                    try {
                        observed = await backend.isolateConfiguredResource(r.reference_key, input.operation_id, input.signal ?? new AbortController().signal, custody);
                    }
                    catch (e) {
                        const row = await custody.read();
                        if (row?.state === 'PREPARED')
                            await custody.record({ binding: row.binding, receipt: null, observations: [] });
                        throw e;
                    }
                    const persisted = await custody.read();
                    if (!persisted || persisted.state !== 'ISOLATED' || persisted.binding.topology_digest !== r.topology_digest || canonical(persisted.receipt) !== canonical(observed))
                        fail('EXTERNAL_FENCE_OUTCOME_UNKNOWN', 'Actual provider isolation must be durably observed before activation');
                    checkReceipt(observed, { deployment_id: input.deployment_id, operation_id: input.operation_id, source_epoch: input.source_epoch, topology_digest: configDigest, ...authorization }, persisted.binding);
                    if (observed.evidence_scope !== trusted.evidence_scope)
                        fail('EXTERNAL_FENCE_EVIDENCE_SCOPE_MISMATCH', 'Component fixture evidence cannot establish live provider isolation');
                    if (observed.status !== 'ISOLATED')
                        fail('EXTERNAL_FENCE_OUTCOME_UNKNOWN', 'Unknown provider resources cannot establish isolation');
                    return observed;
                };
                // First complete potentially slow destructive isolation; then refresh exact known resources without replaying effects.
                for (const r of trusted.resources)
                    await isolate(r);
                const receipts = [];
                for (let index = 0; index < trusted.resources.length; index += 8)
                    receipts.push(...await Promise.all(trusted.resources.slice(index, index + 8).map(isolate)));
                const legacyReceipt = await legacy.observeIsolation(input);
                checkLegacy(legacyReceipt, input, true);
                await authorize(input);
                const now = Date.now();
                for (const receipt of receipts)
                    checkFresh(receipt.observed_at, receipt.expires_at, now);
                const observedAt = Math.max(...receipts.map(r => time(r.observed_at)), time(legacyReceipt.observed_at)), expiresAt = Math.min(...receipts.map(r => time(r.expires_at)), time(legacyReceipt.expires_at), observedAt + 30000);
                if (expiresAt <= now)
                    fail('EXTERNAL_FENCE_STALE', 'Full writer coverage was not observed within one proof interval');
                const completed = { deployment_id: input.deployment_id, operation_id: input.operation_id, source_epoch: input.source_epoch, fence_id: input.operation_id, isolated_writer: 'topology:' + configDigest.slice(7), observed_at: new Date(observedAt).toISOString(), expires_at: new Date(expiresAt).toISOString(), evidence_digest: hash({ topology_digest: configDigest, required_writer_ids: trusted.required_writer_ids, admission, resources: receipts, legacy: legacyReceipt }) };
                await recordCompletion(completed);
                return completed;
            });
        } });
}
/** Observation has separate identity and capability. It cannot prepare or repeat isolation. */
export function createExternalWriterObserver(config, providers, legacy, journal, ownedHost) {
    const trusted = topology(config), topologyDigest = hash(trusted);
    if (trusted.evidence_scope !== 'LIVE_PROVIDER')
        fail('EXTERNAL_FENCE_EVIDENCE_SCOPE_MISMATCH', 'Production observation requires live configured resources');
    if (!providers || typeof providers.observeConfiguredResource !== 'function' || !legacy || typeof legacy.observeIsolation !== 'function' || !(journal instanceof FileExternalFenceJournal))
        fail('EXTERNAL_FENCE_BACKEND_UNAVAILABLE', 'Actual read-only provider observer and existing journal are required');
    return Object.freeze({ observe: async (permit, signal) => {
            const expected = { deployment_id: trusted.deployment_id, operation_id: permit?.operation_id, organisation_id: trusted.organisation_id, run_id: trusted.run_id, source_epoch: trusted.source_epoch, topology_digest: topologyDigest };
            const authorize = () => {
                assertWriterObservationPermit(permit, expected);
                const allowed = permit.resources.map(r => ({ reference_key: r.reference_key, topology_digest: r.topology_digest })).sort((a, b) => a.reference_key.localeCompare(b.reference_key));
                const required = trusted.resources.map(r => ({ reference_key: r.reference_key, topology_digest: r.topology_digest })).sort((a, b) => a.reference_key.localeCompare(b.reference_key));
                if (canonical(allowed) !== canonical(required))
                    fail('EXTERNAL_FENCE_AUTHORITY_DENIED', 'Observation permit must cover exactly the configured resources');
                signal.throwIfAborted();
            };
            authorize();
            return journal.withObservation({ deployment_id: trusted.deployment_id, operation_id: permit.operation_id, source_epoch: trusted.source_epoch, topology_digest: topologyDigest, authority_digest: permit.permit_digest, authority_nonce: permit.nonce }, async (resource) => {
                const results = [];
                for (let index = 0; index < trusted.resources.length; index += 8) {
                    results.push(...await Promise.all(trusted.resources.slice(index, index + 8).map(async (target) => {
                        authorize();
                        const backend = target.backend === 'PROVIDER' ? providers : ownedHost;
                        if (!backend)
                            return { reference_key: target.reference_key, observation: null, code: 'EXTERNAL_FENCE_BACKEND_UNAVAILABLE' };
                        const slot = resource(target.reference_key);
                        const before = await slot.read();
                        if (!before)
                            return { reference_key: target.reference_key, observation: null, code: 'EXTERNAL_FENCE_OBSERVATION_UNPREPARED' };
                        try {
                            const observed = await backend.observeConfiguredResource(target.reference_key, permit.operation_id, permit, signal, slot);
                            const after = await slot.read(), last = after?.writer_observations?.at(-1);
                            if (!last || canonical(last.observation) !== canonical(observed) || last.authorization_digest !== permit.permit_digest || observed.topology_digest !== target.topology_digest || observed.resource_identity_digest !== before.binding.resource_identity_digest || observed.evidence_scope !== 'LIVE_PROVIDER' || observed.authority !== 'OBSERVATION_ONLY')
                                fail('EXTERNAL_FENCE_OBSERVATION_INVALID', 'New provider observation must be durably attributable to the exact resource and current read permit');
                            checkFresh(observed.observed_at, observed.expires_at, Date.now());
                            return { reference_key: target.reference_key, observation: observed, code: null };
                        }
                        catch (error) {
                            return { reference_key: target.reference_key, observation: null, code: error instanceof FoundationError ? error.code : 'EXTERNAL_FENCE_OBSERVATION_UNKNOWN' };
                        }
                    })));
                }
                authorize();
                let legacyReceipt = null, legacyStatus = 'UNKNOWN';
                try {
                    const observed = await legacy.observeIsolation({ deployment_id: trusted.deployment_id, operation_id: permit.operation_id, source_epoch: trusted.source_epoch, signal });
                    if (observed.deployment_id !== trusted.deployment_id || observed.operation_id !== permit.operation_id || observed.source_epoch !== trusted.source_epoch || observed.topology_digest !== trusted.legacy_topology_digest || observed.status !== 'ISOLATED' || observed.visibility?.scope !== 'CONFIGURED_PID_NAMESPACE' || observed.visibility.pid_namespace !== trusted.legacy_pid_namespace || observed.visibility.mount_namespace !== trusted.legacy_mount_namespace || observed.admission_disabled !== true || observed.writable_fds !== 0 || observed.writable_shared_mappings !== 0 || !Number.isSafeInteger(observed.read_only_aliases) || observed.read_only_aliases < 1 || !name(observed.isolated_writer) || !trusted.required_writer_ids.includes(observed.isolated_writer) || !digest(observed.evidence_digest) || !observed.expires_at)
                        fail('EXTERNAL_FENCE_LEGACY_UNVERIFIED', 'Legacy read evidence differs from trusted namespace and source');
                    checkFresh(observed.observed_at, observed.expires_at, Date.now());
                    legacyReceipt = observed;
                    legacyStatus = 'ISOLATED';
                }
                catch { /* A missing legacy read is explicit uncertainty, never isolation. */ }
                authorize();
                const now = Date.now(), isolated = results.filter(r => r.observation?.status === 'OBSERVED' && r.observation.observed_state === 'ABSENT').length;
                const expiries = results.flatMap(r => r.observation ? [time(r.observation.expires_at)] : []);
                if (legacyReceipt?.expires_at)
                    expiries.push(time(legacyReceipt.expires_at));
                const expires = Math.min(now + 30000, time(permit.expires_at), ...expiries);
                if (expires <= now)
                    fail('EXTERNAL_FENCE_STALE', 'Observation evidence expired during aggregate collection');
                return { schema_version: 1, deployment_id: trusted.deployment_id, operation_id: permit.operation_id, source_epoch: trusted.source_epoch, topology_digest: topologyDigest,
                    status: isolated === trusted.resources.length && legacyStatus === 'ISOLATED' ? 'OBSERVED' : 'UNKNOWN', observed_at: new Date(now).toISOString(), expires_at: new Date(expires).toISOString(),
                    evidence_digest: hash({ topology_digest: topologyDigest, authorization_digest: permit.permit_digest, resources: results, legacy: legacyReceipt }), journal_operation_id: permit.operation_id,
                    resource_count: trusted.resources.length, isolated_count: isolated, unknown_count: trusted.resources.length - isolated, legacy_status: legacyStatus, destruction_authority: false, activation_authority: false };
            });
        } });
}
//# sourceMappingURL=fencing.js.map