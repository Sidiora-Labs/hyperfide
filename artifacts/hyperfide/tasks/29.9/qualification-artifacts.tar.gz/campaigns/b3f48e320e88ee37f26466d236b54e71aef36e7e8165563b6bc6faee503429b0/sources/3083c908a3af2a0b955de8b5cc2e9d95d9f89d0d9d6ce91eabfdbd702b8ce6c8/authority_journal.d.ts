export interface ExternalAuthorityAttestation {
    deployment_id: string;
    epoch: string;
    sequence: string;
    evidence_digest: string;
    observed_at: string;
    expires_at: string;
}
export interface AuthorityJournalPreparation {
    deployment_id: string;
    operation_id: string;
    expected_previous_epoch: string | null;
    expected_database_epoch?: string | null;
    fence_evidence_digest: string;
    signal?: AbortSignal;
}
export interface AuthorityJournalPublication {
    deployment_id: string;
    operation_id: string;
    expected_previous_epoch: string | null;
    database_predecessor_epoch?: string | null;
    epoch: string;
    signal?: AbortSignal;
}
export interface CommittedAuthorityEvidence {
    deployment_id: string;
    operation_id: string;
    previous_epoch: string | null;
    database_predecessor_epoch: string | null;
    epoch: string;
    evidence_digest: string;
}
export type VerifyCommittedAuthority = (input: AuthorityJournalPublication) => Promise<CommittedAuthorityEvidence>;
export interface PreparedAuthorityActivation {
    deployment_id: string;
    operation_id: string;
    expected_previous_epoch: string | null;
    expected_database_epoch: string | null;
    epoch: string;
    sequence: string;
    replayed: boolean;
}
export interface ExternalAuthorityJournal {
    current(input: {
        deployment_id: string;
        signal?: AbortSignal;
    }): Promise<ExternalAuthorityAttestation>;
    prepareActivation(input: AuthorityJournalPreparation): Promise<PreparedAuthorityActivation>;
    publishCommitted(input: AuthorityJournalPublication): Promise<ExternalAuthorityAttestation>;
}
/** Store on an independently retained private local volume, outside every database restore.
 * This backend establishes the PostgreSQL-restore boundary. It does not claim whole-host recovery.
 */
export declare class FileExternalAuthorityJournal implements ExternalAuthorityJournal {
    private readonly directory;
    private readonly verifyCommitted;
    constructor(directory: string, verifyCommitted: VerifyCommittedAuthority);
    private root;
    private read;
    private write;
    private lock;
    private attestation;
    current(input: {
        deployment_id: string;
        signal?: AbortSignal;
    }): Promise<ExternalAuthorityAttestation>;
    /** Operator-delivered copy of the activating journal; never reconstruct from database rows. */
    adoptCommitted(input: {
        deployment_id: string;
        document: string;
        signal?: AbortSignal;
    }): Promise<ExternalAuthorityAttestation>;
    prepareActivation(input: AuthorityJournalPreparation): Promise<PreparedAuthorityActivation>;
    publishCommitted(input: AuthorityJournalPublication): Promise<ExternalAuthorityAttestation>;
}
