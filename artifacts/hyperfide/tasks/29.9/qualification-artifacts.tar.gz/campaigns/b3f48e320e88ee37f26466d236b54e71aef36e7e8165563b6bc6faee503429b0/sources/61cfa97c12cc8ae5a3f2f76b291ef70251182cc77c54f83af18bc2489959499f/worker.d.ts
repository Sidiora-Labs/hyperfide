import type { IdentityAuthority } from '../identity/enrollment.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { DeploymentConfig, ProviderDatabase } from './pools.js';
/** Persistent provisioner-role worker. It owns no state of its own: durable
 * provisioning intents are the only work queue, claims are short SKIP LOCKED
 * transactions, and every effect goes through the 8.3 execute/reconcile paths
 * under the authenticated provisioner credential that started it. */
export interface ProvisionerWorkerSettings {
    concurrency: number;
    poll_ms: number;
    retry_ms: number;
    lease_ms: number;
}
export interface ProvisionerWorkerDriver {
    execute(database: ProviderDatabase, config: DeploymentConfig, id: string, signal: AbortSignal): Promise<unknown>;
    reconcile(database: ProviderDatabase, config: DeploymentConfig, id: string, signal: AbortSignal): Promise<unknown>;
}
export interface PoolAdapterReadiness {
    pool_id: string;
    provider: string;
    configuration_current: boolean;
    adapter_registered: boolean;
    adapter_compatible: boolean;
    ownership_probe_registered: boolean;
    operational_ready: boolean;
    reason: string | null;
}
export declare function workerSettings(env: Readonly<NodeJS.ProcessEnv>): ProvisionerWorkerSettings;
/** Adapter compatibility is measured by instantiating the registered factory
 * with hooks that refuse every persistence effect; no provider method is called. */
export declare function poolAdapterReadiness(database: ProviderDatabase, config: DeploymentConfig, invocation: InvocationContext, running: boolean): Promise<PoolAdapterReadiness[]>;
export declare class ProvisionerWorker {
    private readonly database;
    private readonly env;
    private readonly signal;
    private readonly driver;
    private booting;
    private starting;
    boot(authority: IdentityAuthority): Promise<unknown>;
    private invocation;
    private controller;
    private loop;
    private readonly active;
    private readonly errors;
    private readonly backoff;
    private counters;
    private stoppedReason;
    private lastTick;
    constructor(database: ProviderDatabase, env: Readonly<NodeJS.ProcessEnv>, signal: AbortSignal, driver: ProvisionerWorkerDriver);
    get running(): boolean;
    start(invocation: InvocationContext): Promise<unknown>;
    private startOnce;
    private run;
    private tick;
    private process;
    status(invocation: InvocationContext): Promise<Record<string, unknown>>;
    stop(timeoutMs?: number): Promise<void>;
}
export declare function createProvisionerWorker(database: ProviderDatabase, env: Readonly<NodeJS.ProcessEnv>, signal: AbortSignal, driver: ProvisionerWorkerDriver): ProvisionerWorker;
