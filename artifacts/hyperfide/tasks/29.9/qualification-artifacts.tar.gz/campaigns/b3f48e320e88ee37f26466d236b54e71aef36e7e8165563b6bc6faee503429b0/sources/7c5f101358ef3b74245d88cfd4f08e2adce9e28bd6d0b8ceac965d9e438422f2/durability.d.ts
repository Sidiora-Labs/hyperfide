import type { Component, ComponentContext } from '../components/registry.js';
import type { ServiceResources } from './runtime.js';
import type { ExternalAuthorityJournal, ExternalAuthorityAttestation } from './authority_journal.js';
import type { PrimaryTransaction, TransactionOptions } from './transactions.js';
import { createExternalWriterFence } from '../recovery/fencing.js';
export interface MigrationDefinition {
    version: number;
    name: string;
    checksum: string;
    sql: string;
}
export declare function discoverMigrations(directory?: string): Promise<readonly MigrationDefinition[]>;
export declare function assertMigrationSource(sql: string): void;
interface Applied {
    version: number;
    name: string;
    checksum: string;
}
export declare class MigrationCoordinator {
    private readonly resources;
    private readonly directory;
    constructor(resources: ServiceResources, directory?: string);
    inspect(): Promise<{
        ready: boolean;
        applied: Applied[];
        pending: number[];
    }>;
    apply(options?: {
        timeoutMs?: number;
        signal?: AbortSignal;
    }): Promise<{
        applied: number[];
        alreadyApplied: number[];
    }>;
}
export declare function assertMigrationReady(resources: ServiceResources, version: number, name: string, checksum: string): Promise<void>;
export interface AuthorityScope {
    organisation_id: string;
    run_id: string;
    authority_epoch: string;
}
export interface FenceReceipt {
    deployment_id: string;
    operation_id: string;
    fence_id: string;
    source_epoch: string | null;
    isolated_writer: string;
    observed_at: string;
    expires_at: string;
    evidence_digest: string;
}
export interface ExternalWriterFence {
    isolate(input: {
        deployment_id: string;
        operation_id: string;
        source_epoch: string | null;
        signal?: AbortSignal;
    }): Promise<FenceReceipt>;
}
export declare function assertCurrentAuthority(tx: PrimaryTransaction, scope: AuthorityScope & {
    deployment_id: string;
}): Promise<void>;
export declare function lookupAuthorityActivation(resources: ServiceResources, input: {
    deployment_id: string;
    operation_id: string;
    expected_previous_epoch: string | null;
    epoch?: string;
    database_predecessor_epoch?: string | null;
    signal?: AbortSignal;
    timeoutMs?: number;
}): Promise<{
    deployment_id: string;
    operation_id: string;
    previous_epoch: string | null;
    database_predecessor_epoch: string | null;
    epoch: string;
    evidence_digest: string;
}>;
export declare function assertExternalAuthorityCurrent(resources: ServiceResources, journal: ExternalAuthorityJournal, input: {
    deployment_id: string;
    timeoutMs?: number;
    signal?: AbortSignal;
}): Promise<ExternalAuthorityAttestation>;
export declare class AuthorityStore {
    private readonly resources;
    private readonly deploymentId;
    private readonly journal?;
    constructor(resources: ServiceResources, deploymentId: string, journal?: ExternalAuthorityJournal | undefined);
    assertCurrent(tx: PrimaryTransaction, scope: AuthorityScope): Promise<void>;
    activate(input: {
        operation_id: string;
        expected_previous_epoch: string | null;
    }, fencer: ExternalWriterFence, options?: TransactionOptions, journal?: ExternalAuthorityJournal | undefined): Promise<{
        epoch: string;
        replayed: boolean;
    }>;
    activateRestored(input: {
        operation_id: string;
        expected_external_epoch: string;
        expected_database_epoch: string | null;
    }, fencer: ExternalWriterFence, options?: TransactionOptions, journal?: ExternalAuthorityJournal | undefined): Promise<{
        epoch: string;
        replayed: boolean;
    }>;
    private activateInternal;
}
/** Trusted operator code supplies backends and authority; wire requests cannot select these. */
export declare function activateBootstrapAuthority(resources: ServiceResources, deploymentId: string, journal: ExternalAuthorityJournal, operationId: string, fence: Parameters<typeof createExternalWriterFence>, options?: TransactionOptions): Promise<{
    epoch: string;
    replayed: boolean;
}>;
export declare function readAuthorityActivated(resources: ServiceResources, deploymentId: string): Promise<boolean>;
export declare function inspectDurability(resources: ServiceResources): Promise<unknown>;
export declare function assertRuntimePrivileges(resources: ServiceResources): Promise<void>;
export declare function createComponent(context: ComponentContext): Promise<Component>;
export {};
