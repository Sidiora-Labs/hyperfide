import fs from 'node:fs/promises';
import path from 'node:path';
import { constants } from 'node:fs';
import { createPrivateKey, createPublicKey, randomUUID, sign } from 'node:crypto';
import { exact, hash, signingBytes, strictJSON, uuid } from '../transport/protocol.js';
import { assertInvocation } from '../transport/protocol.js';
import { FoundationError } from '../policy/programme.js';
import { PROVIDER_METHODS } from './contract.js';
import { bindProviderInvocation, configuredScope, currentPool, fail, readDeployment, transaction } from './pools.js';
function bounded(env, name, fallback, min, max) {
    const raw = env[name];
    if (raw === undefined || raw === '')
        return fallback;
    const value = Number(raw);
    if (!/^\d+$/.test(raw) || !Number.isSafeInteger(value) || value < min || value > max)
        fail('WORKER_CONFIG_INVALID', name + ' is outside its approved bound');
    return value;
}
export function workerSettings(env) {
    const settings = { concurrency: bounded(env, 'HYPERFIDE_PROVISIONER_CONCURRENCY', 4, 1, 64), poll_ms: bounded(env, 'HYPERFIDE_PROVISIONER_POLL_MS', 1000, 50, 60000),
        retry_ms: bounded(env, 'HYPERFIDE_PROVISIONER_RETRY_MS', 5000, 100, 3600000), lease_ms: bounded(env, 'HYPERFIDE_PROVISIONER_LEASE_MS', 60000, 1000, 3600000) };
    if (settings.lease_ms < settings.poll_ms)
        fail('WORKER_CONFIG_INVALID', 'Reconciliation lease must exceed the poll interval');
    return settings;
}
/** Adapter compatibility is measured by instantiating the registered factory
 * with hooks that refuse every persistence effect; no provider method is called. */
export async function poolAdapterReadiness(database, config, invocation, running) {
    const refuse = async () => fail('PROVIDER_READINESS_PROBE', 'Readiness probing cannot persist provider effects');
    const hooks = { invocation, persistOutputArchive: refuse, assertResourceBinding: refuse, resolveResourceBinding: refuse, resolvePreparation: refuse,
        claimProcess: refuse, resolveProcess: refuse, persistEarlyProcess: refuse, assignedBootGeneration: refuse, persistEarlyResource: refuse, recordObservation: refuse };
    const result = [];
    for (const pool of config.pools) {
        const scope = configuredScope(config, pool), factory = database.runtime.adapters.get(pool.provider);
        let current = false, compatible = false, reason = null;
        try {
            await currentPool(database, config, pool.id);
            current = true;
        }
        catch (error) {
            reason = error instanceof FoundationError ? error.code : 'POOL_CONFIG_UNAVAILABLE';
        }
        if (!factory)
            reason ??= 'PROVIDER_ADAPTER_MISSING';
        else
            try {
                const adapter = factory(scope, hooks);
                compatible = !!adapter && typeof adapter === 'object' && adapter.provider === pool.provider && PROVIDER_METHODS.every(m => typeof adapter[m] === 'function');
                if (!compatible)
                    reason ??= 'PROVIDER_ADAPTER_INCOMPATIBLE';
            }
            catch {
                reason ??= 'PROVIDER_ADAPTER_INCOMPATIBLE';
            }
        if (!running)
            reason ??= 'PROVISIONER_WORKER_STOPPED';
        result.push({ pool_id: pool.id, provider: pool.provider, configuration_current: current, adapter_registered: !!factory, adapter_compatible: compatible,
            ownership_probe_registered: database.runtime.probes.has(pool.provider), operational_ready: running && current && compatible, reason });
    }
    return result;
}
// Claimable work, all scoped to the authenticated run:
//  RECORDED with a live deadline -> execute (its own FOR UPDATE transition is the submission claim);
//  SUBMITTING / ID_KNOWN without outcome only after the submitter's deadline (it can no longer be in flight);
//  ID_KNOWN with a create outcome, UNKNOWN and acknowledged DESTROY after the retry interval;
//  RECONCILING only once its lease lapsed (a crashed reconciler).
const CLAIM = `SELECT id,state FROM hyperfide.provisioning_intents
 WHERE organisation_id=$1 AND run_id=$2 AND NOT (id=ANY($3::uuid[])) AND operation->'scope'->>'provider'=ANY($4::text[]) AND (
  (state='RECORDED' AND (operation->>'deadline_at')::timestamptz>clock_timestamp())
  OR (state='SUBMITTING' AND (operation->>'deadline_at')::timestamptz<=clock_timestamp())
  OR (state='ID_KNOWN' AND (last_outcome IS NOT NULL OR (operation->>'deadline_at')::timestamptz<=clock_timestamp()) AND updated_at<=clock_timestamp()-make_interval(secs=>$5::double precision/1000))
  OR (state='UNKNOWN' AND updated_at<=clock_timestamp()-make_interval(secs=>$5::double precision/1000))
  OR (state='ACKNOWLEDGED' AND kind='DESTROY' AND updated_at<=clock_timestamp()-make_interval(secs=>$5::double precision/1000))
  OR (state='RECONCILING' AND updated_at<=clock_timestamp()-make_interval(secs=>$6::double precision/1000)))
 ORDER BY updated_at,id LIMIT $7 FOR UPDATE SKIP LOCKED`;
async function privateBytes(filename, limit) {
    try {
        return await checkedPrivateBytes(filename, limit);
    }
    catch {
        fail('PROVISIONER_EXECUTOR_CONFIG_INVALID', 'Private owned bounded single-link non-symlink credential required');
    }
}
async function checkedPrivateBytes(filename, limit) {
    if (typeof filename !== 'string' || !path.isAbsolute(filename) || path.normalize(filename) !== filename || await fs.realpath(filename) !== filename)
        fail('PROVISIONER_EXECUTOR_CONFIG_INVALID', 'Absolute non-symlink trusted file required');
    const fd = await fs.open(filename, constants.O_RDONLY | constants.O_NOFOLLOW);
    try {
        const before = await fd.stat();
        if (!before.isFile() || before.nlink !== 1 || before.uid !== process.getuid?.() || (before.mode & 0o777) !== 0o600 || before.size > limit)
            fail('PROVISIONER_EXECUTOR_CONFIG_INVALID', 'Private owned bounded regular file required');
        const bytes = await fd.readFile();
        const after = await fd.stat();
        if (before.dev !== after.dev || before.ino !== after.ino || before.size !== after.size || before.mtimeMs !== after.mtimeMs || bytes.length !== before.size)
            fail('PROVISIONER_EXECUTOR_CONFIG_INVALID', 'Trusted file changed during read');
        return bytes;
    }
    finally {
        await fd.close();
    }
}
async function configuration(env) {
    const value = strictJSON(await privateBytes(env.HF_PROVISIONER_EXECUTOR_CONFIG_FILE, 65536));
    exact(value, ['schema_version', 'principals', 'concurrency']);
    if (value.schema_version !== 1 || !Array.isArray(value.principals) || value.principals.length < 1 || value.principals.length > 64 || !Number.isSafeInteger(value.concurrency) || Number(value.concurrency) < 1 || Number(value.concurrency) > 16)
        fail('PROVISIONER_EXECUTOR_CONFIG_INVALID', 'Bounded executor identity list and concurrency required');
    const signers = [];
    for (const item of value.principals) {
        exact(item, ['credential_id', 'key_path']);
        if (!uuid(item.credential_id) || signers.some(s => s.credential_id === item.credential_id))
            fail('PROVISIONER_EXECUTOR_CONFIG_INVALID', 'Unique credential identity required');
        const raw = await privateBytes(item.key_path, 16384);
        let key;
        try {
            key = raw[0] === 45 ? createPrivateKey(raw) : createPrivateKey({ key: raw, format: 'der', type: 'pkcs8' });
        }
        finally {
            raw.fill(0);
        }
        if (key.asymmetricKeyType !== 'ed25519')
            fail('PROVISIONER_EXECUTOR_CONFIG_INVALID', 'Ed25519 service key required');
        const der = createPublicKey(key).export({ format: 'der', type: 'spki' });
        if (der.length !== 44 || !der.subarray(0, 12).equals(Buffer.from('302a300506032b6570032100', 'hex')))
            fail('PROVISIONER_EXECUTOR_CONFIG_INVALID', 'Canonical Ed25519 public key required');
        signers.push({ credential_id: item.credential_id, key, public_key_b64: der.subarray(12).toString('base64url') });
    }
    return { signers, concurrency: Number(value.concurrency) };
}
export class ProvisionerWorker {
    database;
    env;
    signal;
    driver;
    booting = null;
    starting = null;
    boot(authority) {
        return this.booting ??= (async () => {
            let config;
            try {
                config = await configuration(this.env);
            }
            catch {
                fail('PROVISIONER_EXECUTOR_CONFIG_INVALID', 'Valid private provisioner executor configuration required');
            }
            if (config.signers.length !== 1)
                fail('PROVISIONER_EXECUTOR_CONFIG_INVALID', 'Exactly one worker owner required');
            const signer = config.signers[0];
            const row = (await this.database.query('SELECT p.*,r.authority_epoch FROM hyperfide.identity_principals p JOIN hyperfide.runs r ON r.organisation_id=p.organisation_id AND r.id=p.run_id WHERE p.credential_id=$1', [signer.credential_id])).rows[0];
            if (!row || row.role !== 'PROVISIONER' || row.public_key_b64 !== signer.public_key_b64 || row.deployment_epoch !== row.authority_epoch)
                fail('PROVISIONER_EXECUTOR_IDENTITY_MISMATCH', 'Current matching provisioner identity required');
            const payload = Buffer.from(JSON.stringify({ run_id: row.run_id, component: '8.3', action: 'provider.worker.start', input: {}, expected_version: null, authority: null }));
            const operation = randomUUID(), body = Buffer.from(JSON.stringify({ protocol_version: 1, operation_id: operation, idempotency_key: operation, payload_digest: hash(payload), correlation_id: operation, causation_id: null, payload_b64: payload.toString('base64url') }));
            const proof = { id: signer.credential_id, time: String(Math.floor(Date.now() / 1000)), nonce: randomUUID() };
            const signature = sign(null, signingBytes(authority.origin, '/v1/invoke', proof, body), signer.key).toString('base64url');
            const invocation = await authority.authenticate(body, ['hf-credential-id', proof.id, 'hf-request-time', proof.time, 'hf-request-nonce', proof.nonce, 'hf-request-signature', signature], this.signal);
            await authority.authorize(invocation);
            assertInvocation(invocation);
            if (invocation.principal.role !== 'PROVISIONER' || invocation.principal.credential_id !== signer.credential_id || invocation.principal.run_id !== row.run_id || invocation.principal.deployment_epoch !== row.authority_epoch)
                fail('PROVISIONER_EXECUTOR_IDENTITY_MISMATCH', 'Authenticated worker owner differs');
            return this.start(invocation);
        })();
    }
    invocation = null;
    controller = null;
    loop = null;
    active = new Map();
    errors = new Map();
    backoff = new Map();
    counters = { claimed: 0, executed: 0, reconciled: 0, failed: 0 };
    stoppedReason = null;
    lastTick = null;
    constructor(database, env, signal, driver) {
        this.database = database;
        this.env = env;
        this.signal = signal;
        this.driver = driver;
    }
    get running() { return !!this.loop && !!this.controller && !this.controller.signal.aborted; }
    async start(invocation) {
        // Serialize starts before any asynchronous configuration read can create a second loop.
        while (this.starting)
            await this.starting;
        const pending = this.startOnce(invocation);
        this.starting = pending;
        try {
            return await pending;
        }
        finally {
            if (this.starting === pending)
                this.starting = null;
        }
    }
    async startOnce(invocation) {
        assertInvocation(invocation);
        if (invocation.principal.role !== 'PROVISIONER')
            fail('AUTH_SCOPE_DENIED', 'Only the provisioner principal can own provider effects');
        if (this.signal.aborted)
            fail('PROVIDER_CLOSED', 'Provisioner is shutting down');
        const settings = workerSettings(this.env), config = await readDeployment(this.env);
        bindProviderInvocation(this.database, config, invocation, ['PROVISIONER']);
        if (this.running) {
            if (this.invocation.principal.credential_id !== invocation.principal.credential_id || this.invocation.principal.run_id !== invocation.principal.run_id)
                fail('WORKER_ALREADY_RUNNING', 'Another provisioner credential owns this worker');
            return { started: false, ...await this.status(invocation) };
        }
        await this.stop();
        this.invocation = invocation;
        this.controller = new AbortController();
        this.stoppedReason = null;
        this.errors.clear();
        const signal = AbortSignal.any([this.signal, this.controller.signal]);
        this.loop = this.run(settings, signal);
        return { started: true, ...await this.status(invocation) };
    }
    async run(settings, signal) {
        while (!signal.aborted) {
            try {
                await this.tick(settings, signal);
            }
            catch (error) {
                const code = error instanceof FoundationError ? error.code : 'WORKER_TICK_FAILED';
                this.errors.set('tick', code);
                // A revoked or expired credential ends provider authority; never continue under it.
                if (code.startsWith('AUTH_')) {
                    this.stoppedReason = code;
                    this.controller?.abort();
                    break;
                }
            }
            await new Promise(resolve => { const timer = setTimeout(done, settings.poll_ms); function done() { clearTimeout(timer); signal.removeEventListener('abort', done); resolve(); } signal.addEventListener('abort', done, { once: true }); });
        }
    }
    async tick(settings, signal) {
        this.lastTick = new Date().toISOString();
        const free = settings.concurrency - this.active.size;
        if (free <= 0)
            return;
        const providers = [...this.database.runtime.adapters.keys()];
        if (!providers.length)
            return;
        const config = await readDeployment(this.env), db = bindProviderInvocation(this.database, config, this.invocation, ['PROVISIONER']), run = this.invocation.principal.run_id;
        const claimed = await transaction(db, async (c) => {
            const now = Date.now();
            for (const [id, until] of this.backoff)
                if (until <= now)
                    this.backoff.delete(id);
            const rows = (await c.query(CLAIM, [config.organisation_id, run, [...this.active.keys(), ...this.backoff.keys()], providers, settings.retry_ms, settings.lease_ms, free])).rows;
            const reconcile = rows.filter(r => r.state !== 'RECORDED').map(r => r.id);
            // RECONCILING plus updated_at is the reconciliation lease; an acknowledged destroy keeps its state.
            if (reconcile.length)
                await c.query("UPDATE hyperfide.provisioning_intents SET state=CASE WHEN state='ACKNOWLEDGED' THEN state ELSE 'RECONCILING' END,updated_at=clock_timestamp(),state_version=state_version+1 WHERE organisation_id=$1 AND run_id=$2 AND id=ANY($3::uuid[])", [config.organisation_id, run, reconcile]);
            return rows;
        });
        for (const row of claimed) {
            if (signal.aborted || this.active.has(row.id))
                continue;
            this.counters.claimed++;
            const task = this.process(db, config, row, settings, signal).finally(() => this.active.delete(row.id));
            this.active.set(row.id, task);
        }
    }
    async process(db, config, row, settings, signal) {
        let heartbeat;
        try {
            if (row.state === 'RECORDED') {
                await this.driver.execute(db, config, row.id, signal);
                this.counters.executed++;
            }
            else {
                heartbeat = setInterval(() => { void db.query("UPDATE hyperfide.provisioning_intents SET updated_at=clock_timestamp(),state_version=state_version+1 WHERE organisation_id=$1 AND id=$2 AND state='RECONCILING'", [config.organisation_id, row.id]).catch(() => { }); }, Math.max(250, Math.floor(settings.lease_ms / 3)));
                await this.driver.reconcile(db, config, row.id, signal);
                this.counters.reconciled++;
            }
            this.errors.delete(row.id);
            this.backoff.delete(row.id);
        }
        catch (error) {
            // The intent keeps its durable uncertain state; the error is surfaced, never retried blindly.
            this.counters.failed++;
            this.errors.set(row.id, error instanceof FoundationError ? error.code : 'WORKER_INTENT_FAILED');
            if (this.errors.size > 256)
                this.errors.delete(this.errors.keys().next().value);
            // A refused submission stays RECORDED; back off instead of re-claiming it every poll.
            this.backoff.set(row.id, Date.now() + settings.retry_ms);
            if (this.backoff.size > 4096)
                this.backoff.delete(this.backoff.keys().next().value);
        }
        finally {
            if (heartbeat)
                clearInterval(heartbeat);
        }
    }
    async status(invocation) {
        assertInvocation(invocation);
        const config = await readDeployment(this.env), db = bindProviderInvocation(this.database, config, invocation);
        const settings = workerSettings(this.env), running = this.running;
        const pools = await poolAdapterReadiness(db, config, invocation, running);
        const counts = (await db.query('SELECT state,count(*)::int AS n FROM hyperfide.provisioning_intents WHERE organisation_id=$1 AND run_id=$2 GROUP BY state ORDER BY state', [config.organisation_id, invocation.principal.run_id])).rows;
        return { running, role: 'provisioner', owner_credential_id: running ? this.invocation.principal.credential_id : null, settings, active: [...this.active.keys()].sort(),
            counters: { ...this.counters }, errors: Object.fromEntries(this.errors), stopped_reason: this.stoppedReason, last_tick_at: this.lastTick,
            intents: Object.fromEntries(counts.map(r => [r.state, r.n])), pools, operational_ready: running && pools.length > 0 && pools.every(p => p.operational_ready) };
    }
    async stop(timeoutMs = 5000) {
        this.controller?.abort();
        const pending = [...(this.loop ? [this.loop] : []), ...this.active.values()];
        if (pending.length) {
            let timer;
            await Promise.race([Promise.allSettled(pending), new Promise(resolve => { timer = setTimeout(resolve, timeoutMs); })]);
            if (timer)
                clearTimeout(timer);
        }
        this.loop = null;
    }
}
export function createProvisionerWorker(database, env, signal, driver) {
    return new ProvisionerWorker(database, env, signal, driver);
}
//# sourceMappingURL=worker.js.map