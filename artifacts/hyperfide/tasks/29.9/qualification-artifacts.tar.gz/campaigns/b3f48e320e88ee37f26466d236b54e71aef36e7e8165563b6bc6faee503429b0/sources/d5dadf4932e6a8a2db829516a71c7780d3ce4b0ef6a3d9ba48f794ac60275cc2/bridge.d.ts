import type { Component, ComponentContext } from '../components/registry.js';
import type { PrimaryTransaction } from '../storage/transactions.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { ArtifactStoreCapability } from '../artifacts/objects.js';
import type { PreparationReceiptPlan, VerifiedPreparationReceipt } from './preparation_receipts.js';
export interface RunnerRemotePlan {
    session_id: string;
    operation_id: string;
    repository_id: string;
    reservation_id: string;
    job_id?: string;
    task_id?: string;
    job_kind?: string;
    argv: string[];
    cwd: string;
    environment: Record<string, string>;
    stdin?: string;
    timeout_ms: number;
    preparation?: RunnerPreparationInput;
    source_digest: string;
    source_provenance_digest?: string;
    policy_digest: string;
    executable_digest: string;
    environment_digest: string;
    artifact_paths: string[];
}
export interface RunnerStagingReference {
    role: string;
    artifact_id: string;
    storage_kind: 'object' | 'manifest';
    digest: string;
    manifest_digest?: string;
    size_bytes: string;
}
export interface RunnerPreparationInput {
    recipe_id: 'environment.prepare.v1' | 'checkpoint.restore.v1';
    input_manifest_artifact_id: string;
    input_manifest_digest: string;
    source: {
        repository_key: string;
        source_object_id: string;
        source_tree_id: string | null;
        source_manifest_digest: string;
    };
    job_binding: RunnerPreparationJobBinding;
    staging: RunnerStagingReference[];
    target_binding?: Record<string, unknown>;
}
export interface RunnerPreparationPlan extends RunnerPreparationInput {
    operation_id: string;
    session_id: string;
    reservation_id: string;
    repository_id: string;
    timeout_ms: number;
    target_binding_id: string;
}
declare const permitBrand: unique symbol;
export interface RunnerRemotePermit {
    readonly [permitBrand]: true;
}
export interface CapturedBytes {
    bytes: Uint8Array;
    digest: string;
    size_bytes: string;
    complete: boolean;
}
export interface RunnerRemoteResult {
    execution_plane: 'REMOTE';
    truncated: boolean;
    started_at: string;
    ended_at: string;
    duration_ms: number;
    source_manifest_digest: string;
    source_state_digest: string;
    source_object_id: string;
    source_tree_id: string;
    source_provenance_digest?: string;
    workspace_path: string;
    outcome: 'SUCCEEDED' | 'FAILED' | 'UNKNOWN';
    status: 'COMPLETED' | 'TIMED_OUT' | 'UNKNOWN';
    operation_id: string;
    session_id: string;
    organisation_id: string;
    run_id: string;
    repository_id: string;
    sandbox_id: string;
    boot_id: string;
    boot_generation: string;
    sandbox_boot_generation: string;
    slot_id: string;
    slot_generation: string;
    provider: string;
    native_resource_id: string;
    process_ref: string;
    start_identity: unknown;
    argv: string[];
    cwd: string;
    source_digest: string;
    policy_digest: string;
    executable_digest: string;
    environment_digest: string;
    exit_code: number | null;
    signal: number | null;
    timed_out: boolean;
    interrupted: boolean;
    stdout: CapturedBytes;
    stderr: CapturedBytes;
    stdout_digest: string;
    stderr_digest: string;
    spool_digest: string;
    output_complete: boolean;
    artifacts: Array<{
        path: string;
        bytes: Uint8Array;
        digest: string;
        size_bytes: string;
        complete: boolean;
    }>;
    cleanup_status: 'CONFIRMED' | 'UNKNOWN';
    cleanup: {
        complete: boolean;
        observed_process_absent: boolean;
        receipt_digest: string;
    };
}
export interface RunnerRemote {
    prepare(tx: PrimaryTransaction, invocation: InvocationContext, plan: RunnerRemotePlan): Promise<RunnerRemotePermit>;
    execute(permit: RunnerRemotePermit, signal: AbortSignal): Promise<RunnerRemoteResult>;
    recover(tx: PrimaryTransaction, i: InvocationContext, plan: RunnerRemotePlan): Promise<RunnerRemotePermit>;
}
interface Binding extends Record<string, any> {
    organisation_id: string;
    run_id: string;
    session_id: string;
    credential_id: string;
    sandbox_id: string;
    boot_generation: string;
    boot_id: string;
    slot_id: string;
    preparation_digest: string;
    source_digest: string;
    workspace_path: string;
}
export interface RunnerPreparation {
    prepare(tx: PrimaryTransaction, i: InvocationContext, plan: RunnerPreparationPlan): Promise<RunnerRemotePermit>;
    execute(permit: RunnerRemotePermit, signal: AbortSignal): Promise<RunnerRemoteResult>;
    assertJobAdmission(tx: PrimaryTransaction, i: InvocationContext, plan: RunnerPreparationPlan): Promise<void>;
    /** Native preparation-stage receipts (12.4): verify against the committed plan, persist idempotently, read back. */
    verifyReceipt(bytes: Buffer, plan: PreparationReceiptPlan): VerifiedPreparationReceipt;
    recordReceipt(tx: PrimaryTransaction, i: InvocationContext, input: {
        operation_id: string;
        receipt_base64: string;
    }): Promise<Record<string, unknown>>;
    readReceipt(tx: PrimaryTransaction, scope: {
        organisation_id: string;
        run_id: string;
        operation_id: string;
    }): Promise<Record<string, unknown> | null>;
}
export declare function requireRunnerPreparation(ctx: ComponentContext): RunnerPreparation;
export declare function requireRunnerRemote(ctx: ComponentContext): RunnerRemote;
export declare function runnerCanonical(v: unknown): string;
export declare function readRunnerBinding(tx: PrimaryTransaction, scope: {
    organisation_id: string;
    run_id: string;
    session_id: string;
}): Promise<Binding>;
export declare function readRunnerPreparationBinding(tx: PrimaryTransaction, scope: {
    organisation_id: string;
    run_id: string;
    session_id: string;
}): Promise<Binding>;
export declare function readRunnerReadiness(tx: PrimaryTransaction, r: Binding): Promise<Record<string, any>>;
export type RunnerJobNamespace = 'QUALIFICATION' | 'REPRODUCTION' | 'CANDIDATE' | 'CHECKPOINT' | 'PREWARM';
export interface RunnerPreparationJobBinding {
    namespace: RunnerJobNamespace;
    job_id: string;
    lease_generation: string;
    reservation_id: string;
    input_packet_digest: string;
    input_manifest_digest: string;
}
export interface RunnerPreparationAdmission {
    authority: 'EXPECTED_JOB_AUTHORITY';
    job_binding: RunnerPreparationJobBinding;
    source: RunnerPreparationInput['source'];
    repository_id: string;
    job_kind: 'PREPARATION' | 'CHECKPOINT';
}
export type RunnerPreparationAdmissionReader = (tx: PrimaryTransaction, i: InvocationContext, request: RunnerPreparationPlan) => Promise<RunnerPreparationAdmission | null>;
export interface RunnerEnvironmentRequest {
    job_namespace?: RunnerJobNamespace;
    job_id: string;
    lease_generation?: string;
    reservation_id: string;
    input_manifest_digest?: string;
    environment_digest: string;
}
export interface RunnerExpectedInputs {
    authority: 'EXPECTED_AUTHORITY';
    namespace: RunnerJobNamespace;
    organisation_id: string;
    run_id: string;
    job_id: string;
    lease_generation?: string;
    reservation_id: string;
    runner_session_id: string;
    input_manifest_digest: string;
    input_packet_digest: string;
    input_manifest: Record<string, unknown>;
    profile_id: string;
    profile_digest: string;
    preparation_digest: string;
    repository_id: string;
    source_manifest_digest: string;
    source_object_id: string;
    source_tree_id: string;
    source_state_digest: string;
    workspace_digest: string;
    environment_digest: string;
    receipt_digest: string;
    baseline_packet_digest?: string;
    effective_result_input_receipt_digest?: string;
    custody_id?: string;
    custody_generation?: string;
}
export type RunnerInputReader = (tx: PrimaryTransaction, i: InvocationContext, request: RunnerEnvironmentRequest) => Promise<RunnerExpectedInputs | null>;
export declare function createComponent(ctx: ComponentContext): Promise<Component>;
export declare function runnerResultSigningBytes(org: string, run: string, op: string, plan: string, result: string): Buffer;
/** Read immutable15 payloads only after the SQL observation transaction closes.
 * Every child and concatenated content digest is checked again at this boundary. */
export declare function resolveRunnerCapturedReference(store: ArtifactStoreCapability, i: InvocationContext, ref: unknown): Promise<CapturedBytes>;
/** Recovery reads the authenticated reports retained by the native control path.
 * Missing commands or reports remain unknown; database session state is not a
 * physical process observation. Issuance/delivery remains owned by runner control. */
export declare function createRunnerSupervisors(ctx: ComponentContext): Readonly<{
    observe: (input: unknown) => Promise<{
        status: "CONFIRMED_STOPPED" | "IDENTITY_MISMATCH" | "UNKNOWN";
        evidence_digest: string;
        observed_at: string;
    }>;
    stop: (input: unknown) => Promise<{
        status: "CONFIRMED_STOPPED" | "IDENTITY_MISMATCH" | "UNKNOWN";
        evidence_digest: string;
        observed_at: string;
    }>;
    verifyStop: (input: unknown) => Promise<{
        cleanup_complete: boolean;
        processes_stopped: boolean;
        artifacts_preserved: boolean;
        credentials_cleared: boolean;
        resources_reconciled: boolean;
        observed_at: string;
        evidence_digest: string;
    }>;
}>;
export declare function readReproductionPreparationReceipt(tx: PrimaryTransaction, i: InvocationContext, request: RunnerEnvironmentRequest): Promise<import("./reproduction_jobs.js").ReproductionPreparedInputs | null>;
export declare function createRemoteComponent(ctx: ComponentContext): Promise<Component>;
export {};
