import type { Component, ComponentContext } from '../components/registry.js';
export interface MainStartupBudget {
    schema_version: 1;
    host_id: string;
    pool_id: string;
    allowance: {
        cpu_millis: string;
        memory_bytes: string;
        agent_slots: string;
    };
    headroom: {
        cpu_millis: string;
        memory_bytes: string;
    };
}
export interface MainHostObservation {
    cpu_available_millis: string;
    memory_available_bytes: string;
    observed_at: string;
    source: 'LINUX_PROCFS_CGROUP';
}
export declare function validateSupervisorStartupBudget(declared: unknown, observation: unknown): {
    schema_version: 1;
    sizing: 'WITHIN_OBSERVED_HEADROOM';
    budget_digest: string;
    host_id: string;
    pool_id: string;
    observed_at: string;
    capacity_admitted: false;
    execution_started: false;
};
export declare function createComponent(ctx: ComponentContext): Component;
