import type pg from 'pg';
import type { PrimaryTransaction, TransactionGateway } from '../storage/transactions.js';
import type { Component, ComponentContext } from '../components/registry.js';
import type { InvocationContext } from '../transport/protocol.js';
import type { ProviderAdapter, ProviderOperation, ProviderOutcome, ProviderScope, ResourceRef } from './contract.js';
export interface ProviderPreparationBinding {
    purpose: 'PREPARATION' | 'EXECUTION';
    scope: ProviderScope;
    preparation_digest: string;
    parameters: ProviderOperation<'create'>['parameters'];
    adapter_policy_digest: string | null;
    prepared_base: Record<string, unknown> | null;
}
export interface ProviderProcessRecord {
    native_process_ref?: string | null;
    process_ref: string;
    payload_digest: string;
    resource: ResourceRef;
    state: 'SUBMITTED' | 'RUNNING' | 'EXITED' | 'UNKNOWN';
    provider_metadata: Record<string, unknown>;
}
export interface ProviderResourceBinding {
    organisation_id: string;
    run_id: string;
    sandbox_id: string;
    boot_id: string;
    boot_generation: string;
}
export interface ProviderArtifactReference {
    artifact_id: string;
    receipt_id: string;
    digest: string;
    size_bytes: string;
}
export type ProviderArtifactReferenceReader = (tx: PrimaryTransaction, scope: {
    organisation_id: string;
    run_id: string;
}, references: readonly ProviderArtifactReference[]) => Promise<readonly unknown[]>;
export interface ProviderOutputArchive {
    index_reference: ProviderArtifactReference;
    segment_references: ProviderArtifactReference[];
}
export interface ProviderPersistenceHooks {
    readonly invocation: InvocationContext;
    persistOutputArchive(operation: ProviderOperation<'execute'>, archive: ProviderOutputArchive): Promise<{
        archive_id: string;
        evidence_digest: string;
    }>;
    assertResourceBinding(operation: ProviderOperation): Promise<void>;
    resolveResourceBinding(operation: ProviderOperation): Promise<ProviderResourceBinding>;
    resolvePreparation(operation: ProviderOperation<'create'>): Promise<ProviderPreparationBinding>;
    claimProcess(operation: ProviderOperation<'execute'>, record: ProviderProcessRecord): Promise<{
        disposition: 'NEW' | 'EXISTING';
        record: ProviderProcessRecord;
    }>;
    resolveProcess(operation: ProviderOperation, processRef: string): Promise<ProviderProcessRecord | null>;
    persistEarlyProcess(operation: ProviderOperation<'execute'>, nativeProcessRef: string): Promise<void>;
    assignedBootGeneration(operation: ProviderOperation<'create'>): Promise<string>;
    persistEarlyResource(operation: ProviderOperation<'create'>, nativeSandboxId: string): Promise<ResourceRef>;
    recordObservation(operation: ProviderOperation, outcome: ProviderOutcome): Promise<void>;
}
export type ProviderAdapterFactory = (scope: ProviderScope, hooks: ProviderPersistenceHooks) => ProviderAdapter;
export declare const QUOTA_DIMENSIONS: readonly ['SANDBOX', 'PROVISIONING', 'CPU_MILLIS', 'MEMORY_BYTES', 'DISK_BYTES', 'AGENT', 'BUILD', 'TEST', 'INDEX'];
export type QuotaDimension = typeof QUOTA_DIMENSIONS[number];
export interface QuotaObservation {
    scope_kind: 'ACCOUNT' | 'ENVIRONMENT' | 'POOL';
    scope_key: string;
    dimension: QuotaDimension;
    limit: string;
    observed_at: string;
    expires_at: string;
    evidence_digest: string;
    basis: 'PROVIDER_API' | 'VERIFIED_OPERATOR_ATTESTATION' | 'OPERATOR_DECLARED_CAPACITY';
    evidence_reference: string;
}
export type ProviderQuotaObserver = (scope: ProviderScope, signal: AbortSignal) => Promise<QuotaObservation[]>;
export interface OwnershipObservation {
    matches: boolean;
    operation_id: string;
    native_sandbox_id: string;
    evidence_digest: string;
}
export type ProviderOwnershipProbe = (scope: ProviderScope, operationId: string, nativeId: string, signal: AbortSignal) => Promise<OwnershipObservation>;
export interface ProviderRunnerBinding extends Record<string, unknown> {
    organisation_id: string;
    run_id: string;
    session_id: string;
    pool_id: string;
    sandbox_id: string;
    external_sandbox_id: string;
    boot_generation: string;
    preparation_digest: string;
}
export interface ProviderRunnerBindingProof {
    evidence_digest: string;
    observed_at: string;
}
export type ProviderRunnerBindingVerifier = (tx: PrimaryTransaction, binding: ProviderRunnerBinding, request: unknown) => Promise<ProviderRunnerBindingProof | null>;
export interface ProviderIsolationTransport {
    destroy(operation: ProviderOperation<'destroy'>, signal?: AbortSignal): Promise<ProviderOutcome<'destroy'>>;
    observe(operation: ProviderOperation<'observe'>, signal?: AbortSignal): Promise<ProviderOutcome<'observe'>>;
}
export type ProviderIsolationFactory = (scope: ProviderScope) => ProviderIsolationTransport | Promise<ProviderIsolationTransport>;
export interface ProviderDestructionRequest {
    organisation_id: string;
    run_id: string;
    sandbox_id: string;
    boot_generation: string;
    operation_id: string;
}
export interface ProviderDestructionProof {
    evidence_digest: string;
    observed_at: string;
}
export type ProviderDestructionPreflight = (tx: PrimaryTransaction, input: ProviderDestructionRequest) => Promise<ProviderDestructionProof | null>;
export interface ProviderRuntimeRegistry {
    connectivityProbe?: Readonly<{
        component: "8.4-probe";
        state: "CONFIGURED";
    }>;
    publicationVerifier?: RuntimeReadinessPublicationVerifier;
    artifactReferenceReader?: ProviderArtifactReferenceReader;
    destructionPreflight?: ProviderDestructionPreflight;
    isolation: Map<string, ProviderIsolationFactory>;
    runnerBindingVerifier?: ProviderRunnerBindingVerifier;
    adapters: Map<string, ProviderAdapterFactory>;
    observers: Map<string, ProviderQuotaObserver>;
    probes: Map<string, ProviderOwnershipProbe>;
}
export interface ProviderDatabase {
    query<R extends pg.QueryResultRow = pg.QueryResultRow>(text: string, values?: readonly unknown[]): Promise<pg.QueryResult<R>>;
    gateway: Pick<TransactionGateway, 'withPrimaryTransaction'>;
    runtime: ProviderRuntimeRegistry;
    readonly invocation?: InvocationContext;
    readonly deployment?: DeploymentConfig;
}
export declare function providerDeployment(database: ProviderDatabase): DeploymentConfig;
export declare function providerInvocation(database: ProviderDatabase): InvocationContext;
export declare function bindProviderInvocation(database: ProviderDatabase, config: DeploymentConfig, invocation: InvocationContext, roles?: readonly string[]): ProviderDatabase;
export declare function assertInvocationRun(database: ProviderDatabase, run: string): void;
export declare function resolveSandboxBinding(database: ProviderDatabase, config: DeploymentConfig, run: string, sandbox: string, op: ProviderOperation): Promise<ProviderResourceBinding>;
export declare function createProviderRuntimeRegistry(): ProviderRuntimeRegistry;
export declare function createProviderDatabase(context: ComponentContext): ProviderDatabase;
export declare function registerArtifactReferenceReader(runtime: ProviderRuntimeRegistry, reader: ProviderArtifactReferenceReader): () => void;
export declare function registerIsolationTransport(runtime: ProviderRuntimeRegistry, provider: 'railway' | 'blaxel', factory: ProviderIsolationFactory): () => void;
export declare function registerProviderAdapter(runtime: ProviderRuntimeRegistry, provider: 'railway' | 'blaxel', factory: ProviderAdapterFactory): () => void;
export declare function registerProviderQuotaObserver(runtime: ProviderRuntimeRegistry, provider: 'railway' | 'blaxel', observer: ProviderQuotaObserver): () => void;
export declare function registerProviderOwnershipProbe(runtime: ProviderRuntimeRegistry, provider: 'railway' | 'blaxel', probe: ProviderOwnershipProbe): () => void;
export declare const hasProviderAdapter: (provider: string, runtime: ProviderRuntimeRegistry) => boolean;
export declare function providerAdapter(scope: ProviderScope, hooks: ProviderPersistenceHooks, runtime: ProviderRuntimeRegistry): ProviderAdapter;
export declare function providerOwnershipProbe(provider: string, runtime: ProviderRuntimeRegistry): ProviderOwnershipProbe;
export declare function providerDatabase(context: ComponentContext): ProviderDatabase;
export declare function fail(code: string, message: string): never;
export declare function obj(value: unknown, keys?: readonly string[]): Record<string, unknown>;
export declare function str(value: unknown, max?: number): string;
export declare function uuid(value: unknown): string;
export declare function dec(value: unknown): string;
export declare function dg(value: unknown): string;
export declare function utc(value: unknown): string;
export declare const digestDocument: (value: unknown) => string;
export declare function transaction<T>(pool: ProviderDatabase, body: (client: PrimaryTransaction) => Promise<T>): Promise<T>;
type Limits = Partial<Record<QuotaDimension, string>>;
export interface PoolConfig {
    id: string;
    provider: 'railway' | 'blaxel';
    account_key: string;
    environment_key: string;
    region: string;
    profile_id: string | null;
    preparation_digest: string;
    approved_limits: Limits;
    planning_limits: Limits;
    scheduling_policy?: {
        aging_seconds: number;
        max_bypass_seconds: number;
        rate_window_ms: number;
        max_waiters: number;
    };
    create_policy: {
        seed_reference: string;
        network: 'ISOLATED' | 'PRIVATE';
        stdin_required: boolean;
        adapter_policy_digest?: string;
    };
}
export interface DeploymentConfig {
    schema_version: 1;
    organisation_id: string;
    revision: string;
    accounts: Array<{
        provider: 'railway' | 'blaxel';
        account_key: string;
        approved_limits: Limits;
        planning_limits: Limits;
    }>;
    pools: PoolConfig[];
    maximum_operation_ms: number;
}
export declare function validateDeployment(value: unknown): DeploymentConfig;
export declare function readDeployment(env: Readonly<NodeJS.ProcessEnv>): Promise<DeploymentConfig>;
export declare function inspectProviderSchema(pool: ProviderDatabase): Promise<unknown>;
export declare function configuredPool(config: DeploymentConfig, id: string): PoolConfig;
export declare function configuredScope(config: DeploymentConfig, p: PoolConfig): ProviderScope;
export declare function validateQuotaObservation(value: unknown, scope: ProviderScope): QuotaObservation;
export declare function currentPool(client: Pick<PrimaryTransaction, 'query'>, config: DeploymentConfig, id: string): Promise<{
    pool: PoolConfig;
    scope: ProviderScope;
}>;
export declare function poolCapacity(client: Pick<PrimaryTransaction, 'query'>, config: DeploymentConfig, id: string): Promise<unknown>;
export declare function assertPoolCapacity(client: PrimaryTransaction, config: DeploymentConfig, id: string, requested: Partial<Record<QuotaDimension, string>>, alreadyReserved?: boolean): Promise<void>;
export declare function approvedProfilePolicyDigest(value: unknown): string;
export interface SelectedEnvironmentInput {
    organisation_id: string;
    pool_id: string;
    configuration_digest: string;
    parent_profile_id: string;
    parent_preparation_digest: string;
    profile_id: string;
    preparation_digest: string;
    source_manifest_digest?: string;
}
export declare function readSelectedEnvironmentProfile(tx: PrimaryTransaction, input: SelectedEnvironmentInput): Promise<{
    manifest: Record<string, unknown>;
    lineage: Record<string, unknown> | null;
} | null>;
export declare function sourceBindingsMatchProfile(profile: unknown, bindings: unknown): boolean;
export interface RuntimeReadinessInput {
    organisation_id: string;
    run_id: string;
    sandbox_id: string;
    boot_generation: string;
    slot_id: string;
    boot_preparation_digest: string;
    preparation_digest: string;
    source_digest: string;
}
export interface RuntimeReadinessRecord extends Record<string, unknown> {
    readiness_digest: string;
    profile_digest: string;
    boot_preparation_digest: string;
    preparation_digest: string;
    source_digest: string;
    source_manifest_digest: string;
    source_state_digest: string;
    source_object_id: string;
    source_tree_id: string;
    source_repository_id: string;
    source_repository_key: string;
    execution_receipt_artifact_digest: string;
    verification_receipt_artifact_digest: string;
    source_bindings: Array<{
        id: string;
        commit: string;
        tree: string;
    }>;
    execution_receipt_digest: string;
    verification_receipt_digest: string;
    observed_at: string;
    expires_at: string;
    readiness_input: Record<string, unknown>;
    readiness_input_digest: string;
}
export declare function readRuntimeReadiness(tx: PrimaryTransaction, input: RuntimeReadinessInput): Promise<RuntimeReadinessRecord | null>;
export interface VerifiedRuntimeReadinessPublication {
    observation: {
        id: string;
        sandbox_id: string;
        boot_generation: string;
        boot_id: string;
        slot_id: string;
        profile_id: string;
        boot_preparation_digest: string;
        preparation_digest: string;
        source_manifest_digest: string;
        source_repository_id: string;
        source_repository_key: string;
        source_object_id: string;
        source_tree_id: string;
        source_bindings: Array<{
            id: string;
            commit: string;
            tree: string;
        }>;
        workspace_digest: string | null;
        native_operation_id: string;
        input_digest: string;
        command_digest: string;
        readiness_input: Record<string, unknown>;
        execution_receipt_digest: string;
        verification_receipt_digest: string;
        state: 'READY' | 'NOT_READY';
        failure_code: string | null;
        observed_at: string;
        expires_at: string;
    };
    manifest: Record<string, unknown>;
    lineage_id: string | null;
    artifacts: {
        stdout: ProviderArtifactReference;
        manifest: ProviderArtifactReference;
        source_manifest: ProviderArtifactReference;
        execution_receipt: ProviderArtifactReference;
        verification_receipt: ProviderArtifactReference;
    };
}
/** This digest identifies the retained publication envelope, not the native
 * checker, a Git tree, or the full preparation manifest. Those remain explicit. */
export declare function runtimeReadinessDigest(value: Record<string, unknown>): string;
export type RuntimeReadinessPublicationVerifier = (tx: PrimaryTransaction, invocation: InvocationContext, input: VerifiedRuntimeReadinessPublication, producerProof: unknown) => Promise<void>;
export declare function registerPublicationVerifier(runtime: ProviderRuntimeRegistry, verifier: RuntimeReadinessPublicationVerifier): () => void;
export interface ProviderReadinessCapability {
    registerPublicationVerifier(verifier: RuntimeReadinessPublicationVerifier): () => void;
    registerArtifactReferenceReader(reader: ProviderArtifactReferenceReader): () => void;
    readRuntimeReadiness: typeof readRuntimeReadiness;
    publishVerifiedRuntimeReadiness(tx: PrimaryTransaction, invocation: InvocationContext, input: VerifiedRuntimeReadinessPublication, producerProof: unknown): Promise<{
        created: boolean;
        id: string;
        readiness_digest: string;
        state: string;
        authority: 'OBSERVATION_ONLY';
    }>;
}
export declare function isProviderReadinessCapability(value: unknown): value is ProviderReadinessCapability;
/** Private transaction-bound producer API. The actual12 retained-receipt
 * publisher must first verify the signed/root-sealed result, stored artifact
 * bytes and independently measured source. No JSON action exposes this method.
 * Lower08 revalidates its own authority, immutable profile/source identities,
 * retained metadata and current physical binding in the caller's transaction. */
export declare function publishVerifiedRuntimeReadiness(tx: PrimaryTransaction, invocation: InvocationContext, raw: VerifiedRuntimeReadinessPublication, producerProof: unknown, reader: ProviderArtifactReferenceReader, verifier: RuntimeReadinessPublicationVerifier): Promise<{
    created: boolean;
    id: string;
    readiness_digest: string;
    state: string;
    authority: 'OBSERVATION_ONLY';
}>;
export declare function createComponent(context: ComponentContext): Component;
export {};
